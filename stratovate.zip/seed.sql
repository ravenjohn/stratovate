insert into users (name, type, contact_number) values('raven', 'client', '9351282147');
insert into users (name, type, contact_number) values('john', 'client', '9351282148');
insert into users (name, type, contact_number) values('martin', 'client', '9351282149');
insert into users (name, type, contact_number) values('nez', 'client', '9351282146');
insert into users (name, type, contact_number) values('lag', 'client', '9351282145');
insert into users (name, type, contact_number) values('rim', 'client', '9351282144');
insert into users (name, type, contact_number) values('mas', 'client', '9351282143');
insert into users (name, type, contact_number) values('lagrimas', 'client', '9351282142');
insert into users (name, type, contact_number) values('martinez', 'client', '9351282141');

insert into users (name, type, password) values('ravenjohn', 'admin', md5(sha1('ravenjohn')));

insert into users (name, type) values('ravens', 'establishment');