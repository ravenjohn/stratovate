<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-09-03 12:28:26 --> Config Class Initialized
DEBUG - 2013-09-03 12:28:26 --> Hooks Class Initialized
DEBUG - 2013-09-03 12:28:26 --> Utf8 Class Initialized
DEBUG - 2013-09-03 12:28:26 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 12:28:27 --> URI Class Initialized
DEBUG - 2013-09-03 12:28:27 --> Router Class Initialized
DEBUG - 2013-09-03 12:28:27 --> No URI present. Default controller set.
DEBUG - 2013-09-03 12:28:28 --> Output Class Initialized
DEBUG - 2013-09-03 12:28:28 --> Security Class Initialized
DEBUG - 2013-09-03 12:28:28 --> Input Class Initialized
DEBUG - 2013-09-03 12:28:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-03 12:28:28 --> Language Class Initialized
DEBUG - 2013-09-03 12:28:28 --> Loader Class Initialized
DEBUG - 2013-09-03 12:28:29 --> Database Driver Class Initialized
ERROR - 2013-09-03 12:28:29 --> Severity: Warning  --> mysql_pconnect(): MySQL server has gone away C:\xampp2\htdocs\bigas2hack\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2013-09-03 12:28:30 --> Controller Class Initialized
DEBUG - 2013-09-03 12:28:30 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-03 12:28:30 --> Helper loaded: inflector_helper
DEBUG - 2013-09-03 12:28:30 --> Model Class Initialized
DEBUG - 2013-09-03 12:28:30 --> Helper loaded: date_helper
DEBUG - 2013-09-03 12:28:30 --> Model Class Initialized
DEBUG - 2013-09-03 12:28:30 --> File loaded: application/views/index.php
DEBUG - 2013-09-03 12:28:30 --> Final output sent to browser
DEBUG - 2013-09-03 12:28:30 --> Total execution time: 4.4303
DEBUG - 2013-09-03 12:29:11 --> Config Class Initialized
DEBUG - 2013-09-03 12:29:11 --> Hooks Class Initialized
DEBUG - 2013-09-03 12:29:11 --> Utf8 Class Initialized
DEBUG - 2013-09-03 12:29:11 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 12:29:11 --> URI Class Initialized
DEBUG - 2013-09-03 12:29:11 --> Router Class Initialized
DEBUG - 2013-09-03 12:29:11 --> Output Class Initialized
DEBUG - 2013-09-03 12:29:11 --> Security Class Initialized
DEBUG - 2013-09-03 12:29:11 --> Input Class Initialized
DEBUG - 2013-09-03 12:29:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-03 12:29:11 --> Language Class Initialized
DEBUG - 2013-09-03 12:29:11 --> Loader Class Initialized
DEBUG - 2013-09-03 12:29:11 --> Database Driver Class Initialized
DEBUG - 2013-09-03 12:29:11 --> Controller Class Initialized
DEBUG - 2013-09-03 12:29:11 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-03 12:29:11 --> Helper loaded: inflector_helper
DEBUG - 2013-09-03 12:29:11 --> Model Class Initialized
DEBUG - 2013-09-03 12:29:11 --> Helper loaded: date_helper
DEBUG - 2013-09-03 12:29:11 --> Model Class Initialized
DEBUG - 2013-09-03 12:29:11 --> Model Class Initialized
DEBUG - 2013-09-03 12:29:11 --> XSS Filtering completed
DEBUG - 2013-09-03 12:29:11 --> XSS Filtering completed
DEBUG - 2013-09-03 12:29:11 --> XSS Filtering completed
DEBUG - 2013-09-03 12:29:11 --> XSS Filtering completed
DEBUG - 2013-09-03 12:29:11 --> XSS Filtering completed
DEBUG - 2013-09-03 12:29:11 --> XSS Filtering completed
DEBUG - 2013-09-03 12:29:34 --> Config Class Initialized
DEBUG - 2013-09-03 12:29:34 --> Hooks Class Initialized
DEBUG - 2013-09-03 12:29:34 --> Utf8 Class Initialized
DEBUG - 2013-09-03 12:29:34 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 12:29:34 --> URI Class Initialized
DEBUG - 2013-09-03 12:29:34 --> Router Class Initialized
DEBUG - 2013-09-03 12:29:34 --> Output Class Initialized
DEBUG - 2013-09-03 12:29:34 --> Security Class Initialized
DEBUG - 2013-09-03 12:29:34 --> Input Class Initialized
DEBUG - 2013-09-03 12:29:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-03 12:29:34 --> Language Class Initialized
DEBUG - 2013-09-03 12:29:34 --> Loader Class Initialized
DEBUG - 2013-09-03 12:29:34 --> Database Driver Class Initialized
DEBUG - 2013-09-03 12:29:34 --> Controller Class Initialized
DEBUG - 2013-09-03 12:29:34 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-03 12:29:34 --> Helper loaded: inflector_helper
DEBUG - 2013-09-03 12:29:34 --> Model Class Initialized
DEBUG - 2013-09-03 12:29:34 --> Helper loaded: date_helper
DEBUG - 2013-09-03 12:29:34 --> Model Class Initialized
DEBUG - 2013-09-03 12:29:34 --> File loaded: application/views/admin.php
DEBUG - 2013-09-03 12:29:34 --> Final output sent to browser
DEBUG - 2013-09-03 12:29:34 --> Total execution time: 0.0910
DEBUG - 2013-09-03 12:29:40 --> Config Class Initialized
DEBUG - 2013-09-03 12:29:40 --> Hooks Class Initialized
DEBUG - 2013-09-03 12:29:40 --> Utf8 Class Initialized
DEBUG - 2013-09-03 12:29:40 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 12:29:40 --> URI Class Initialized
DEBUG - 2013-09-03 12:29:40 --> Router Class Initialized
DEBUG - 2013-09-03 12:29:40 --> Output Class Initialized
DEBUG - 2013-09-03 12:29:40 --> Security Class Initialized
DEBUG - 2013-09-03 12:29:40 --> Input Class Initialized
DEBUG - 2013-09-03 12:29:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-03 12:29:40 --> Language Class Initialized
DEBUG - 2013-09-03 12:29:40 --> Loader Class Initialized
DEBUG - 2013-09-03 12:29:40 --> Database Driver Class Initialized
ERROR - 2013-09-03 12:29:40 --> Severity: Warning  --> mysql_pconnect(): MySQL server has gone away C:\xampp2\htdocs\bigas2hack\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2013-09-03 12:29:40 --> Controller Class Initialized
DEBUG - 2013-09-03 12:29:40 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-03 12:29:40 --> Helper loaded: inflector_helper
DEBUG - 2013-09-03 12:29:40 --> Model Class Initialized
DEBUG - 2013-09-03 12:29:40 --> Helper loaded: date_helper
DEBUG - 2013-09-03 12:29:40 --> Model Class Initialized
DEBUG - 2013-09-03 12:29:40 --> File loaded: application/views/admin.php
DEBUG - 2013-09-03 12:29:40 --> Final output sent to browser
DEBUG - 2013-09-03 12:29:40 --> Total execution time: 0.2210
DEBUG - 2013-09-03 12:29:44 --> Config Class Initialized
DEBUG - 2013-09-03 12:29:44 --> Hooks Class Initialized
DEBUG - 2013-09-03 12:29:44 --> Utf8 Class Initialized
DEBUG - 2013-09-03 12:29:44 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 12:29:44 --> URI Class Initialized
DEBUG - 2013-09-03 12:29:44 --> Router Class Initialized
DEBUG - 2013-09-03 12:29:44 --> Output Class Initialized
DEBUG - 2013-09-03 12:29:44 --> Security Class Initialized
DEBUG - 2013-09-03 12:29:44 --> Input Class Initialized
DEBUG - 2013-09-03 12:29:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-03 12:29:44 --> Language Class Initialized
DEBUG - 2013-09-03 12:29:44 --> Loader Class Initialized
DEBUG - 2013-09-03 12:29:44 --> Database Driver Class Initialized
DEBUG - 2013-09-03 12:29:44 --> Controller Class Initialized
DEBUG - 2013-09-03 12:29:44 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-03 12:29:44 --> Helper loaded: inflector_helper
DEBUG - 2013-09-03 12:29:44 --> Model Class Initialized
DEBUG - 2013-09-03 12:29:44 --> Helper loaded: date_helper
DEBUG - 2013-09-03 12:29:44 --> Model Class Initialized
DEBUG - 2013-09-03 12:29:44 --> File loaded: application/views/admin.php
DEBUG - 2013-09-03 12:29:44 --> Final output sent to browser
DEBUG - 2013-09-03 12:29:44 --> Total execution time: 0.0610
DEBUG - 2013-09-03 12:29:46 --> Config Class Initialized
DEBUG - 2013-09-03 12:29:46 --> Hooks Class Initialized
DEBUG - 2013-09-03 12:29:46 --> Utf8 Class Initialized
DEBUG - 2013-09-03 12:29:46 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 12:29:46 --> URI Class Initialized
DEBUG - 2013-09-03 12:29:46 --> Router Class Initialized
DEBUG - 2013-09-03 12:29:46 --> Output Class Initialized
DEBUG - 2013-09-03 12:29:46 --> Security Class Initialized
DEBUG - 2013-09-03 12:29:46 --> Input Class Initialized
DEBUG - 2013-09-03 12:29:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-03 12:29:46 --> Language Class Initialized
DEBUG - 2013-09-03 12:29:46 --> Loader Class Initialized
DEBUG - 2013-09-03 12:29:46 --> Database Driver Class Initialized
DEBUG - 2013-09-03 12:29:46 --> Controller Class Initialized
DEBUG - 2013-09-03 12:29:46 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-03 12:29:46 --> Helper loaded: inflector_helper
DEBUG - 2013-09-03 12:29:46 --> Model Class Initialized
DEBUG - 2013-09-03 12:29:46 --> Helper loaded: date_helper
DEBUG - 2013-09-03 12:29:46 --> Model Class Initialized
DEBUG - 2013-09-03 12:29:46 --> File loaded: application/views/admin.php
DEBUG - 2013-09-03 12:29:46 --> Final output sent to browser
DEBUG - 2013-09-03 12:29:46 --> Total execution time: 0.0590
DEBUG - 2013-09-03 12:29:47 --> Config Class Initialized
DEBUG - 2013-09-03 12:29:47 --> Hooks Class Initialized
DEBUG - 2013-09-03 12:29:47 --> Utf8 Class Initialized
DEBUG - 2013-09-03 12:29:47 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 12:29:47 --> URI Class Initialized
DEBUG - 2013-09-03 12:29:47 --> Router Class Initialized
DEBUG - 2013-09-03 12:29:47 --> Output Class Initialized
DEBUG - 2013-09-03 12:29:47 --> Security Class Initialized
DEBUG - 2013-09-03 12:29:47 --> Input Class Initialized
DEBUG - 2013-09-03 12:29:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-03 12:29:47 --> Language Class Initialized
DEBUG - 2013-09-03 12:29:47 --> Loader Class Initialized
DEBUG - 2013-09-03 12:29:47 --> Database Driver Class Initialized
DEBUG - 2013-09-03 12:29:47 --> Controller Class Initialized
DEBUG - 2013-09-03 12:29:47 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-03 12:29:47 --> Helper loaded: inflector_helper
DEBUG - 2013-09-03 12:29:47 --> Model Class Initialized
DEBUG - 2013-09-03 12:29:47 --> Helper loaded: date_helper
DEBUG - 2013-09-03 12:29:47 --> Model Class Initialized
DEBUG - 2013-09-03 12:29:47 --> File loaded: application/views/admin.php
DEBUG - 2013-09-03 12:29:47 --> Final output sent to browser
DEBUG - 2013-09-03 12:29:47 --> Total execution time: 0.0580
DEBUG - 2013-09-03 12:30:09 --> Config Class Initialized
DEBUG - 2013-09-03 12:30:09 --> Hooks Class Initialized
DEBUG - 2013-09-03 12:30:09 --> Utf8 Class Initialized
DEBUG - 2013-09-03 12:30:09 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 12:30:09 --> URI Class Initialized
DEBUG - 2013-09-03 12:30:09 --> Router Class Initialized
DEBUG - 2013-09-03 12:30:09 --> No URI present. Default controller set.
DEBUG - 2013-09-03 12:30:09 --> Output Class Initialized
DEBUG - 2013-09-03 12:30:09 --> Security Class Initialized
DEBUG - 2013-09-03 12:30:09 --> Input Class Initialized
DEBUG - 2013-09-03 12:30:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-03 12:30:09 --> Language Class Initialized
DEBUG - 2013-09-03 12:30:09 --> Loader Class Initialized
DEBUG - 2013-09-03 12:30:09 --> Database Driver Class Initialized
DEBUG - 2013-09-03 12:30:09 --> Controller Class Initialized
DEBUG - 2013-09-03 12:30:09 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-03 12:30:09 --> Helper loaded: inflector_helper
DEBUG - 2013-09-03 12:30:09 --> Model Class Initialized
DEBUG - 2013-09-03 12:30:09 --> Helper loaded: date_helper
DEBUG - 2013-09-03 12:30:09 --> Model Class Initialized
DEBUG - 2013-09-03 12:30:09 --> File loaded: application/views/index.php
DEBUG - 2013-09-03 12:30:09 --> Final output sent to browser
DEBUG - 2013-09-03 12:30:09 --> Total execution time: 0.0600
DEBUG - 2013-09-03 12:30:24 --> Config Class Initialized
DEBUG - 2013-09-03 12:30:24 --> Hooks Class Initialized
DEBUG - 2013-09-03 12:30:24 --> Utf8 Class Initialized
DEBUG - 2013-09-03 12:30:24 --> UTF-8 Support Enabled
DEBUG - 2013-09-03 12:30:24 --> URI Class Initialized
DEBUG - 2013-09-03 12:30:24 --> Router Class Initialized
DEBUG - 2013-09-03 12:30:24 --> Output Class Initialized
DEBUG - 2013-09-03 12:30:24 --> Security Class Initialized
DEBUG - 2013-09-03 12:30:24 --> Input Class Initialized
DEBUG - 2013-09-03 12:30:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-03 12:30:24 --> Language Class Initialized
DEBUG - 2013-09-03 12:30:24 --> Loader Class Initialized
DEBUG - 2013-09-03 12:30:24 --> Database Driver Class Initialized
DEBUG - 2013-09-03 12:30:24 --> Controller Class Initialized
DEBUG - 2013-09-03 12:30:24 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-03 12:30:24 --> Helper loaded: inflector_helper
DEBUG - 2013-09-03 12:30:24 --> Model Class Initialized
DEBUG - 2013-09-03 12:30:24 --> Helper loaded: date_helper
DEBUG - 2013-09-03 12:30:24 --> Model Class Initialized
DEBUG - 2013-09-03 12:30:24 --> File loaded: application/views/admin.php
DEBUG - 2013-09-03 12:30:24 --> Final output sent to browser
DEBUG - 2013-09-03 12:30:24 --> Total execution time: 0.0620
