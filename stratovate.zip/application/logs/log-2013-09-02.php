<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-09-02 19:03:39 --> Config Class Initialized
DEBUG - 2013-09-02 19:03:39 --> Hooks Class Initialized
DEBUG - 2013-09-02 19:03:39 --> Utf8 Class Initialized
DEBUG - 2013-09-02 19:03:39 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 19:03:39 --> URI Class Initialized
DEBUG - 2013-09-02 19:03:39 --> Router Class Initialized
DEBUG - 2013-09-02 19:03:39 --> No URI present. Default controller set.
DEBUG - 2013-09-02 19:03:40 --> Output Class Initialized
DEBUG - 2013-09-02 19:03:40 --> Security Class Initialized
DEBUG - 2013-09-02 19:03:40 --> Input Class Initialized
DEBUG - 2013-09-02 19:03:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 19:03:40 --> Language Class Initialized
DEBUG - 2013-09-02 19:03:40 --> Loader Class Initialized
DEBUG - 2013-09-02 19:03:40 --> Database Driver Class Initialized
DEBUG - 2013-09-02 19:03:40 --> Controller Class Initialized
DEBUG - 2013-09-02 19:03:40 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-02 19:03:40 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 19:03:41 --> Model Class Initialized
DEBUG - 2013-09-02 19:03:41 --> Helper loaded: date_helper
DEBUG - 2013-09-02 19:03:41 --> Model Class Initialized
DEBUG - 2013-09-02 19:03:41 --> File loaded: application/views/index.php
DEBUG - 2013-09-02 19:03:41 --> Final output sent to browser
DEBUG - 2013-09-02 19:03:41 --> Total execution time: 2.3441
DEBUG - 2013-09-02 19:04:06 --> Config Class Initialized
DEBUG - 2013-09-02 19:04:06 --> Hooks Class Initialized
DEBUG - 2013-09-02 19:04:06 --> Utf8 Class Initialized
DEBUG - 2013-09-02 19:04:06 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 19:04:06 --> URI Class Initialized
DEBUG - 2013-09-02 19:04:06 --> Router Class Initialized
DEBUG - 2013-09-02 19:04:06 --> No URI present. Default controller set.
DEBUG - 2013-09-02 19:04:06 --> Output Class Initialized
DEBUG - 2013-09-02 19:04:06 --> Security Class Initialized
DEBUG - 2013-09-02 19:04:06 --> Input Class Initialized
DEBUG - 2013-09-02 19:04:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 19:04:06 --> Language Class Initialized
DEBUG - 2013-09-02 19:04:06 --> Loader Class Initialized
DEBUG - 2013-09-02 19:04:06 --> Database Driver Class Initialized
DEBUG - 2013-09-02 19:04:06 --> Controller Class Initialized
DEBUG - 2013-09-02 19:04:06 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-02 19:04:06 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 19:04:06 --> Model Class Initialized
DEBUG - 2013-09-02 19:04:06 --> Helper loaded: date_helper
DEBUG - 2013-09-02 19:04:06 --> Model Class Initialized
DEBUG - 2013-09-02 19:04:06 --> File loaded: application/views/index.php
DEBUG - 2013-09-02 19:04:06 --> Final output sent to browser
DEBUG - 2013-09-02 19:04:06 --> Total execution time: 0.1580
DEBUG - 2013-09-02 19:04:26 --> Config Class Initialized
DEBUG - 2013-09-02 19:04:26 --> Hooks Class Initialized
DEBUG - 2013-09-02 19:04:26 --> Utf8 Class Initialized
DEBUG - 2013-09-02 19:04:26 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 19:04:26 --> URI Class Initialized
DEBUG - 2013-09-02 19:04:26 --> Router Class Initialized
ERROR - 2013-09-02 19:04:26 --> 404 Page Not Found --> files
DEBUG - 2013-09-02 19:04:37 --> Config Class Initialized
DEBUG - 2013-09-02 19:04:37 --> Hooks Class Initialized
DEBUG - 2013-09-02 19:04:37 --> Utf8 Class Initialized
DEBUG - 2013-09-02 19:04:37 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 19:04:37 --> URI Class Initialized
DEBUG - 2013-09-02 19:04:37 --> Router Class Initialized
DEBUG - 2013-09-02 19:04:37 --> Output Class Initialized
DEBUG - 2013-09-02 19:04:37 --> Security Class Initialized
DEBUG - 2013-09-02 19:04:37 --> Input Class Initialized
DEBUG - 2013-09-02 19:04:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 19:04:37 --> Language Class Initialized
DEBUG - 2013-09-02 19:04:37 --> Loader Class Initialized
DEBUG - 2013-09-02 19:04:37 --> Database Driver Class Initialized
DEBUG - 2013-09-02 19:04:37 --> Controller Class Initialized
DEBUG - 2013-09-02 19:04:37 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-02 19:04:37 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 19:04:37 --> Model Class Initialized
DEBUG - 2013-09-02 19:04:37 --> Helper loaded: date_helper
DEBUG - 2013-09-02 19:04:37 --> Model Class Initialized
DEBUG - 2013-09-02 19:04:37 --> Model Class Initialized
DEBUG - 2013-09-02 19:04:37 --> XSS Filtering completed
DEBUG - 2013-09-02 19:04:37 --> XSS Filtering completed
DEBUG - 2013-09-02 19:04:37 --> XSS Filtering completed
DEBUG - 2013-09-02 19:04:37 --> XSS Filtering completed
DEBUG - 2013-09-02 19:04:37 --> XSS Filtering completed
DEBUG - 2013-09-02 19:04:37 --> XSS Filtering completed
DEBUG - 2013-09-02 19:05:03 --> Config Class Initialized
DEBUG - 2013-09-02 19:05:03 --> Hooks Class Initialized
DEBUG - 2013-09-02 19:05:03 --> Utf8 Class Initialized
DEBUG - 2013-09-02 19:05:03 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 19:05:03 --> URI Class Initialized
DEBUG - 2013-09-02 19:05:03 --> Router Class Initialized
DEBUG - 2013-09-02 19:05:03 --> Output Class Initialized
DEBUG - 2013-09-02 19:05:03 --> Security Class Initialized
DEBUG - 2013-09-02 19:05:03 --> Input Class Initialized
DEBUG - 2013-09-02 19:05:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 19:05:03 --> Language Class Initialized
DEBUG - 2013-09-02 19:05:03 --> Loader Class Initialized
DEBUG - 2013-09-02 19:05:03 --> Database Driver Class Initialized
DEBUG - 2013-09-02 19:05:03 --> Controller Class Initialized
DEBUG - 2013-09-02 19:05:03 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-02 19:05:03 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 19:05:03 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:03 --> Helper loaded: date_helper
DEBUG - 2013-09-02 19:05:03 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:03 --> File loaded: application/views/admin.php
DEBUG - 2013-09-02 19:05:03 --> Final output sent to browser
DEBUG - 2013-09-02 19:05:03 --> Total execution time: 0.0450
DEBUG - 2013-09-02 19:05:04 --> Config Class Initialized
DEBUG - 2013-09-02 19:05:04 --> Hooks Class Initialized
DEBUG - 2013-09-02 19:05:04 --> Utf8 Class Initialized
DEBUG - 2013-09-02 19:05:04 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 19:05:04 --> URI Class Initialized
DEBUG - 2013-09-02 19:05:04 --> Router Class Initialized
DEBUG - 2013-09-02 19:05:04 --> Output Class Initialized
DEBUG - 2013-09-02 19:05:04 --> Security Class Initialized
DEBUG - 2013-09-02 19:05:04 --> Input Class Initialized
DEBUG - 2013-09-02 19:05:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 19:05:04 --> Language Class Initialized
DEBUG - 2013-09-02 19:05:04 --> Config Class Initialized
DEBUG - 2013-09-02 19:05:04 --> Hooks Class Initialized
DEBUG - 2013-09-02 19:05:04 --> Utf8 Class Initialized
DEBUG - 2013-09-02 19:05:04 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 19:05:04 --> Loader Class Initialized
DEBUG - 2013-09-02 19:05:04 --> URI Class Initialized
DEBUG - 2013-09-02 19:05:04 --> Router Class Initialized
DEBUG - 2013-09-02 19:05:04 --> Output Class Initialized
DEBUG - 2013-09-02 19:05:04 --> Security Class Initialized
DEBUG - 2013-09-02 19:05:04 --> Input Class Initialized
DEBUG - 2013-09-02 19:05:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 19:05:04 --> Database Driver Class Initialized
DEBUG - 2013-09-02 19:05:04 --> Language Class Initialized
DEBUG - 2013-09-02 19:05:04 --> Loader Class Initialized
DEBUG - 2013-09-02 19:05:04 --> Database Driver Class Initialized
DEBUG - 2013-09-02 19:05:04 --> Controller Class Initialized
DEBUG - 2013-09-02 19:05:04 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-02 19:05:04 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 19:05:04 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:04 --> Helper loaded: date_helper
DEBUG - 2013-09-02 19:05:04 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:04 --> Controller Class Initialized
DEBUG - 2013-09-02 19:05:04 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-02 19:05:04 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 19:05:04 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:04 --> Helper loaded: date_helper
DEBUG - 2013-09-02 19:05:04 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:04 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:04 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:04 --> XSS Filtering completed
DEBUG - 2013-09-02 19:05:04 --> XSS Filtering completed
DEBUG - 2013-09-02 19:05:04 --> XSS Filtering completed
DEBUG - 2013-09-02 19:05:04 --> XSS Filtering completed
DEBUG - 2013-09-02 19:05:04 --> XSS Filtering completed
ERROR - 2013-09-02 19:05:04 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 185
ERROR - 2013-09-02 19:05:04 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-02 19:05:04 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-02 19:05:04 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 195
DEBUG - 2013-09-02 19:05:06 --> Config Class Initialized
DEBUG - 2013-09-02 19:05:06 --> Hooks Class Initialized
DEBUG - 2013-09-02 19:05:06 --> Utf8 Class Initialized
DEBUG - 2013-09-02 19:05:06 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 19:05:06 --> URI Class Initialized
DEBUG - 2013-09-02 19:05:06 --> Router Class Initialized
DEBUG - 2013-09-02 19:05:06 --> Output Class Initialized
DEBUG - 2013-09-02 19:05:06 --> Security Class Initialized
DEBUG - 2013-09-02 19:05:06 --> Input Class Initialized
DEBUG - 2013-09-02 19:05:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 19:05:06 --> Language Class Initialized
DEBUG - 2013-09-02 19:05:06 --> Loader Class Initialized
DEBUG - 2013-09-02 19:05:06 --> Database Driver Class Initialized
DEBUG - 2013-09-02 19:05:06 --> Controller Class Initialized
DEBUG - 2013-09-02 19:05:06 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-02 19:05:06 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 19:05:06 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:06 --> Helper loaded: date_helper
DEBUG - 2013-09-02 19:05:06 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:06 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:13 --> Config Class Initialized
DEBUG - 2013-09-02 19:05:13 --> Hooks Class Initialized
DEBUG - 2013-09-02 19:05:13 --> Utf8 Class Initialized
DEBUG - 2013-09-02 19:05:13 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 19:05:13 --> URI Class Initialized
DEBUG - 2013-09-02 19:05:13 --> Router Class Initialized
DEBUG - 2013-09-02 19:05:13 --> Output Class Initialized
DEBUG - 2013-09-02 19:05:13 --> Security Class Initialized
DEBUG - 2013-09-02 19:05:13 --> Input Class Initialized
DEBUG - 2013-09-02 19:05:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 19:05:13 --> Language Class Initialized
DEBUG - 2013-09-02 19:05:13 --> Loader Class Initialized
DEBUG - 2013-09-02 19:05:13 --> Database Driver Class Initialized
DEBUG - 2013-09-02 19:05:13 --> Controller Class Initialized
DEBUG - 2013-09-02 19:05:13 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-02 19:05:13 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 19:05:13 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:13 --> Helper loaded: date_helper
DEBUG - 2013-09-02 19:05:13 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:13 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:13 --> XSS Filtering completed
DEBUG - 2013-09-02 19:05:13 --> XSS Filtering completed
DEBUG - 2013-09-02 19:05:17 --> Config Class Initialized
DEBUG - 2013-09-02 19:05:17 --> Hooks Class Initialized
DEBUG - 2013-09-02 19:05:17 --> Utf8 Class Initialized
DEBUG - 2013-09-02 19:05:17 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 19:05:17 --> URI Class Initialized
DEBUG - 2013-09-02 19:05:17 --> Router Class Initialized
DEBUG - 2013-09-02 19:05:17 --> Output Class Initialized
DEBUG - 2013-09-02 19:05:17 --> Security Class Initialized
DEBUG - 2013-09-02 19:05:17 --> Input Class Initialized
DEBUG - 2013-09-02 19:05:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 19:05:17 --> Language Class Initialized
DEBUG - 2013-09-02 19:05:17 --> Loader Class Initialized
DEBUG - 2013-09-02 19:05:17 --> Database Driver Class Initialized
DEBUG - 2013-09-02 19:05:17 --> Controller Class Initialized
DEBUG - 2013-09-02 19:05:17 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-02 19:05:17 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 19:05:17 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:17 --> Helper loaded: date_helper
DEBUG - 2013-09-02 19:05:17 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:17 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:17 --> XSS Filtering completed
DEBUG - 2013-09-02 19:05:17 --> XSS Filtering completed
DEBUG - 2013-09-02 19:05:17 --> Config Class Initialized
DEBUG - 2013-09-02 19:05:17 --> Hooks Class Initialized
DEBUG - 2013-09-02 19:05:17 --> Utf8 Class Initialized
DEBUG - 2013-09-02 19:05:17 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 19:05:17 --> URI Class Initialized
DEBUG - 2013-09-02 19:05:17 --> Router Class Initialized
DEBUG - 2013-09-02 19:05:17 --> Output Class Initialized
DEBUG - 2013-09-02 19:05:17 --> Security Class Initialized
DEBUG - 2013-09-02 19:05:17 --> Input Class Initialized
DEBUG - 2013-09-02 19:05:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 19:05:17 --> Language Class Initialized
DEBUG - 2013-09-02 19:05:17 --> Loader Class Initialized
DEBUG - 2013-09-02 19:05:17 --> Database Driver Class Initialized
DEBUG - 2013-09-02 19:05:17 --> Controller Class Initialized
DEBUG - 2013-09-02 19:05:17 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-02 19:05:17 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 19:05:17 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:17 --> Helper loaded: date_helper
DEBUG - 2013-09-02 19:05:17 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:17 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:17 --> XSS Filtering completed
DEBUG - 2013-09-02 19:05:17 --> XSS Filtering completed
DEBUG - 2013-09-02 19:05:17 --> XSS Filtering completed
DEBUG - 2013-09-02 19:05:17 --> Config Class Initialized
DEBUG - 2013-09-02 19:05:17 --> Hooks Class Initialized
DEBUG - 2013-09-02 19:05:17 --> Utf8 Class Initialized
DEBUG - 2013-09-02 19:05:17 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 19:05:17 --> URI Class Initialized
DEBUG - 2013-09-02 19:05:17 --> Router Class Initialized
DEBUG - 2013-09-02 19:05:17 --> Output Class Initialized
DEBUG - 2013-09-02 19:05:17 --> Security Class Initialized
DEBUG - 2013-09-02 19:05:17 --> Input Class Initialized
DEBUG - 2013-09-02 19:05:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 19:05:17 --> Language Class Initialized
DEBUG - 2013-09-02 19:05:17 --> Loader Class Initialized
DEBUG - 2013-09-02 19:05:17 --> Database Driver Class Initialized
DEBUG - 2013-09-02 19:05:17 --> Controller Class Initialized
DEBUG - 2013-09-02 19:05:17 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-02 19:05:17 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 19:05:17 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:17 --> Helper loaded: date_helper
DEBUG - 2013-09-02 19:05:17 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:17 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:17 --> XSS Filtering completed
DEBUG - 2013-09-02 19:05:17 --> XSS Filtering completed
ERROR - 2013-09-02 19:05:17 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 185
ERROR - 2013-09-02 19:05:17 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-02 19:05:17 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-02 19:05:17 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 195
DEBUG - 2013-09-02 19:05:25 --> Config Class Initialized
DEBUG - 2013-09-02 19:05:25 --> Hooks Class Initialized
DEBUG - 2013-09-02 19:05:25 --> Utf8 Class Initialized
DEBUG - 2013-09-02 19:05:25 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 19:05:25 --> URI Class Initialized
DEBUG - 2013-09-02 19:05:25 --> Router Class Initialized
DEBUG - 2013-09-02 19:05:25 --> Output Class Initialized
DEBUG - 2013-09-02 19:05:25 --> Security Class Initialized
DEBUG - 2013-09-02 19:05:25 --> Input Class Initialized
DEBUG - 2013-09-02 19:05:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 19:05:25 --> Language Class Initialized
DEBUG - 2013-09-02 19:05:25 --> Loader Class Initialized
DEBUG - 2013-09-02 19:05:25 --> Database Driver Class Initialized
DEBUG - 2013-09-02 19:05:25 --> Controller Class Initialized
DEBUG - 2013-09-02 19:05:25 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-02 19:05:25 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 19:05:25 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:25 --> Helper loaded: date_helper
DEBUG - 2013-09-02 19:05:25 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:25 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:25 --> Config Class Initialized
DEBUG - 2013-09-02 19:05:25 --> Hooks Class Initialized
DEBUG - 2013-09-02 19:05:25 --> Utf8 Class Initialized
DEBUG - 2013-09-02 19:05:25 --> XSS Filtering completed
DEBUG - 2013-09-02 19:05:25 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 19:05:25 --> XSS Filtering completed
DEBUG - 2013-09-02 19:05:25 --> URI Class Initialized
ERROR - 2013-09-02 19:05:25 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 185
ERROR - 2013-09-02 19:05:25 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-02 19:05:25 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
DEBUG - 2013-09-02 19:05:25 --> Router Class Initialized
ERROR - 2013-09-02 19:05:25 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 195
DEBUG - 2013-09-02 19:05:25 --> Output Class Initialized
DEBUG - 2013-09-02 19:05:25 --> Security Class Initialized
DEBUG - 2013-09-02 19:05:25 --> Input Class Initialized
DEBUG - 2013-09-02 19:05:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 19:05:25 --> Language Class Initialized
DEBUG - 2013-09-02 19:05:25 --> Loader Class Initialized
DEBUG - 2013-09-02 19:05:25 --> Database Driver Class Initialized
DEBUG - 2013-09-02 19:05:25 --> Controller Class Initialized
DEBUG - 2013-09-02 19:05:25 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-02 19:05:25 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 19:05:25 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:25 --> Helper loaded: date_helper
DEBUG - 2013-09-02 19:05:25 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:25 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:25 --> XSS Filtering completed
DEBUG - 2013-09-02 19:05:25 --> XSS Filtering completed
DEBUG - 2013-09-02 19:05:25 --> XSS Filtering completed
DEBUG - 2013-09-02 19:05:25 --> XSS Filtering completed
DEBUG - 2013-09-02 19:05:27 --> Config Class Initialized
DEBUG - 2013-09-02 19:05:27 --> Hooks Class Initialized
DEBUG - 2013-09-02 19:05:27 --> Utf8 Class Initialized
DEBUG - 2013-09-02 19:05:27 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 19:05:27 --> URI Class Initialized
DEBUG - 2013-09-02 19:05:27 --> Router Class Initialized
DEBUG - 2013-09-02 19:05:27 --> Config Class Initialized
DEBUG - 2013-09-02 19:05:27 --> Hooks Class Initialized
DEBUG - 2013-09-02 19:05:27 --> Utf8 Class Initialized
DEBUG - 2013-09-02 19:05:27 --> Output Class Initialized
DEBUG - 2013-09-02 19:05:27 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 19:05:27 --> Security Class Initialized
DEBUG - 2013-09-02 19:05:27 --> URI Class Initialized
DEBUG - 2013-09-02 19:05:27 --> Router Class Initialized
DEBUG - 2013-09-02 19:05:27 --> Input Class Initialized
DEBUG - 2013-09-02 19:05:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 19:05:27 --> Language Class Initialized
DEBUG - 2013-09-02 19:05:27 --> Output Class Initialized
DEBUG - 2013-09-02 19:05:27 --> Security Class Initialized
DEBUG - 2013-09-02 19:05:27 --> Input Class Initialized
DEBUG - 2013-09-02 19:05:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 19:05:27 --> Loader Class Initialized
DEBUG - 2013-09-02 19:05:27 --> Language Class Initialized
DEBUG - 2013-09-02 19:05:27 --> Loader Class Initialized
DEBUG - 2013-09-02 19:05:27 --> Database Driver Class Initialized
DEBUG - 2013-09-02 19:05:27 --> Controller Class Initialized
DEBUG - 2013-09-02 19:05:27 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-02 19:05:27 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 19:05:27 --> Database Driver Class Initialized
DEBUG - 2013-09-02 19:05:27 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:27 --> Controller Class Initialized
DEBUG - 2013-09-02 19:05:27 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-02 19:05:27 --> Helper loaded: date_helper
DEBUG - 2013-09-02 19:05:27 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:27 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 19:05:27 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:27 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:27 --> Helper loaded: date_helper
DEBUG - 2013-09-02 19:05:27 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:27 --> XSS Filtering completed
DEBUG - 2013-09-02 19:05:27 --> XSS Filtering completed
DEBUG - 2013-09-02 19:05:27 --> XSS Filtering completed
DEBUG - 2013-09-02 19:05:27 --> XSS Filtering completed
DEBUG - 2013-09-02 19:05:27 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:27 --> XSS Filtering completed
DEBUG - 2013-09-02 19:05:27 --> XSS Filtering completed
ERROR - 2013-09-02 19:05:27 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 185
ERROR - 2013-09-02 19:05:27 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-02 19:05:27 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-02 19:05:27 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 195
DEBUG - 2013-09-02 19:05:38 --> Config Class Initialized
DEBUG - 2013-09-02 19:05:38 --> Hooks Class Initialized
DEBUG - 2013-09-02 19:05:38 --> Utf8 Class Initialized
DEBUG - 2013-09-02 19:05:38 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 19:05:38 --> URI Class Initialized
DEBUG - 2013-09-02 19:05:38 --> Router Class Initialized
DEBUG - 2013-09-02 19:05:38 --> Output Class Initialized
DEBUG - 2013-09-02 19:05:38 --> Security Class Initialized
DEBUG - 2013-09-02 19:05:38 --> Input Class Initialized
DEBUG - 2013-09-02 19:05:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 19:05:38 --> Language Class Initialized
DEBUG - 2013-09-02 19:05:38 --> Loader Class Initialized
DEBUG - 2013-09-02 19:05:38 --> Database Driver Class Initialized
DEBUG - 2013-09-02 19:05:38 --> Controller Class Initialized
DEBUG - 2013-09-02 19:05:38 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-02 19:05:38 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 19:05:38 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:38 --> Helper loaded: date_helper
DEBUG - 2013-09-02 19:05:38 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:38 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:38 --> XSS Filtering completed
DEBUG - 2013-09-02 19:05:40 --> Config Class Initialized
DEBUG - 2013-09-02 19:05:40 --> Hooks Class Initialized
DEBUG - 2013-09-02 19:05:40 --> Utf8 Class Initialized
DEBUG - 2013-09-02 19:05:40 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 19:05:40 --> URI Class Initialized
DEBUG - 2013-09-02 19:05:40 --> Router Class Initialized
DEBUG - 2013-09-02 19:05:40 --> Output Class Initialized
DEBUG - 2013-09-02 19:05:40 --> Security Class Initialized
DEBUG - 2013-09-02 19:05:40 --> Input Class Initialized
DEBUG - 2013-09-02 19:05:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 19:05:40 --> Language Class Initialized
DEBUG - 2013-09-02 19:05:40 --> Loader Class Initialized
DEBUG - 2013-09-02 19:05:40 --> Database Driver Class Initialized
DEBUG - 2013-09-02 19:05:40 --> Controller Class Initialized
DEBUG - 2013-09-02 19:05:40 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-02 19:05:40 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 19:05:40 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:40 --> Helper loaded: date_helper
DEBUG - 2013-09-02 19:05:40 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:40 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:40 --> XSS Filtering completed
DEBUG - 2013-09-02 19:05:40 --> XSS Filtering completed
DEBUG - 2013-09-02 19:05:40 --> XSS Filtering completed
DEBUG - 2013-09-02 19:05:40 --> Config Class Initialized
DEBUG - 2013-09-02 19:05:40 --> Hooks Class Initialized
DEBUG - 2013-09-02 19:05:40 --> Utf8 Class Initialized
DEBUG - 2013-09-02 19:05:40 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 19:05:40 --> URI Class Initialized
DEBUG - 2013-09-02 19:05:40 --> Router Class Initialized
DEBUG - 2013-09-02 19:05:40 --> Output Class Initialized
DEBUG - 2013-09-02 19:05:40 --> Security Class Initialized
DEBUG - 2013-09-02 19:05:40 --> Input Class Initialized
DEBUG - 2013-09-02 19:05:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 19:05:40 --> Language Class Initialized
DEBUG - 2013-09-02 19:05:40 --> Loader Class Initialized
DEBUG - 2013-09-02 19:05:40 --> Database Driver Class Initialized
DEBUG - 2013-09-02 19:05:40 --> Controller Class Initialized
DEBUG - 2013-09-02 19:05:40 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-02 19:05:40 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 19:05:40 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:40 --> Helper loaded: date_helper
DEBUG - 2013-09-02 19:05:40 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:40 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:40 --> XSS Filtering completed
DEBUG - 2013-09-02 19:05:40 --> XSS Filtering completed
DEBUG - 2013-09-02 19:05:40 --> XSS Filtering completed
DEBUG - 2013-09-02 19:05:41 --> Config Class Initialized
DEBUG - 2013-09-02 19:05:41 --> Hooks Class Initialized
DEBUG - 2013-09-02 19:05:41 --> Utf8 Class Initialized
DEBUG - 2013-09-02 19:05:41 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 19:05:41 --> URI Class Initialized
DEBUG - 2013-09-02 19:05:41 --> Router Class Initialized
DEBUG - 2013-09-02 19:05:41 --> Output Class Initialized
DEBUG - 2013-09-02 19:05:41 --> Security Class Initialized
DEBUG - 2013-09-02 19:05:41 --> Input Class Initialized
DEBUG - 2013-09-02 19:05:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 19:05:41 --> Language Class Initialized
DEBUG - 2013-09-02 19:05:41 --> Loader Class Initialized
DEBUG - 2013-09-02 19:05:41 --> Database Driver Class Initialized
DEBUG - 2013-09-02 19:05:41 --> Controller Class Initialized
DEBUG - 2013-09-02 19:05:41 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-02 19:05:41 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 19:05:41 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:41 --> Helper loaded: date_helper
DEBUG - 2013-09-02 19:05:41 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:41 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:41 --> XSS Filtering completed
DEBUG - 2013-09-02 19:05:41 --> XSS Filtering completed
DEBUG - 2013-09-02 19:05:41 --> XSS Filtering completed
DEBUG - 2013-09-02 19:05:42 --> Config Class Initialized
DEBUG - 2013-09-02 19:05:42 --> Hooks Class Initialized
DEBUG - 2013-09-02 19:05:42 --> Utf8 Class Initialized
DEBUG - 2013-09-02 19:05:42 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 19:05:42 --> URI Class Initialized
DEBUG - 2013-09-02 19:05:42 --> Router Class Initialized
DEBUG - 2013-09-02 19:05:42 --> Output Class Initialized
DEBUG - 2013-09-02 19:05:42 --> Security Class Initialized
DEBUG - 2013-09-02 19:05:42 --> Input Class Initialized
DEBUG - 2013-09-02 19:05:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 19:05:42 --> Language Class Initialized
DEBUG - 2013-09-02 19:05:42 --> Loader Class Initialized
DEBUG - 2013-09-02 19:05:42 --> Database Driver Class Initialized
DEBUG - 2013-09-02 19:05:42 --> Controller Class Initialized
DEBUG - 2013-09-02 19:05:42 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-02 19:05:42 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 19:05:42 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:42 --> Helper loaded: date_helper
DEBUG - 2013-09-02 19:05:42 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:42 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:42 --> XSS Filtering completed
DEBUG - 2013-09-02 19:05:42 --> XSS Filtering completed
DEBUG - 2013-09-02 19:05:42 --> XSS Filtering completed
DEBUG - 2013-09-02 19:05:45 --> Config Class Initialized
DEBUG - 2013-09-02 19:05:45 --> Hooks Class Initialized
DEBUG - 2013-09-02 19:05:45 --> Utf8 Class Initialized
DEBUG - 2013-09-02 19:05:45 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 19:05:45 --> URI Class Initialized
DEBUG - 2013-09-02 19:05:45 --> Router Class Initialized
DEBUG - 2013-09-02 19:05:45 --> Output Class Initialized
DEBUG - 2013-09-02 19:05:45 --> Security Class Initialized
DEBUG - 2013-09-02 19:05:45 --> Input Class Initialized
DEBUG - 2013-09-02 19:05:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 19:05:45 --> Language Class Initialized
DEBUG - 2013-09-02 19:05:45 --> Loader Class Initialized
DEBUG - 2013-09-02 19:05:45 --> Database Driver Class Initialized
DEBUG - 2013-09-02 19:05:45 --> Controller Class Initialized
DEBUG - 2013-09-02 19:05:45 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-02 19:05:45 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 19:05:45 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:45 --> Helper loaded: date_helper
DEBUG - 2013-09-02 19:05:45 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:45 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:45 --> XSS Filtering completed
DEBUG - 2013-09-02 19:05:45 --> XSS Filtering completed
DEBUG - 2013-09-02 19:05:45 --> Config Class Initialized
DEBUG - 2013-09-02 19:05:45 --> Hooks Class Initialized
DEBUG - 2013-09-02 19:05:45 --> Utf8 Class Initialized
DEBUG - 2013-09-02 19:05:45 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 19:05:45 --> URI Class Initialized
DEBUG - 2013-09-02 19:05:45 --> Router Class Initialized
DEBUG - 2013-09-02 19:05:45 --> Output Class Initialized
DEBUG - 2013-09-02 19:05:45 --> Security Class Initialized
DEBUG - 2013-09-02 19:05:45 --> Input Class Initialized
DEBUG - 2013-09-02 19:05:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 19:05:45 --> Language Class Initialized
DEBUG - 2013-09-02 19:05:45 --> Loader Class Initialized
DEBUG - 2013-09-02 19:05:45 --> Database Driver Class Initialized
DEBUG - 2013-09-02 19:05:45 --> Controller Class Initialized
DEBUG - 2013-09-02 19:05:45 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-02 19:05:45 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 19:05:45 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:45 --> Helper loaded: date_helper
DEBUG - 2013-09-02 19:05:45 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:45 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:45 --> XSS Filtering completed
DEBUG - 2013-09-02 19:05:45 --> XSS Filtering completed
DEBUG - 2013-09-02 19:05:45 --> Config Class Initialized
DEBUG - 2013-09-02 19:05:45 --> Hooks Class Initialized
DEBUG - 2013-09-02 19:05:45 --> Utf8 Class Initialized
DEBUG - 2013-09-02 19:05:45 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 19:05:45 --> URI Class Initialized
DEBUG - 2013-09-02 19:05:45 --> Router Class Initialized
DEBUG - 2013-09-02 19:05:45 --> Output Class Initialized
DEBUG - 2013-09-02 19:05:45 --> Security Class Initialized
DEBUG - 2013-09-02 19:05:45 --> Input Class Initialized
DEBUG - 2013-09-02 19:05:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 19:05:45 --> Language Class Initialized
DEBUG - 2013-09-02 19:05:45 --> Loader Class Initialized
DEBUG - 2013-09-02 19:05:45 --> Database Driver Class Initialized
DEBUG - 2013-09-02 19:05:45 --> Controller Class Initialized
DEBUG - 2013-09-02 19:05:45 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-02 19:05:45 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 19:05:45 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:45 --> Helper loaded: date_helper
DEBUG - 2013-09-02 19:05:45 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:45 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:45 --> XSS Filtering completed
DEBUG - 2013-09-02 19:05:45 --> XSS Filtering completed
DEBUG - 2013-09-02 19:05:45 --> Config Class Initialized
DEBUG - 2013-09-02 19:05:45 --> Hooks Class Initialized
DEBUG - 2013-09-02 19:05:45 --> Utf8 Class Initialized
DEBUG - 2013-09-02 19:05:45 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 19:05:45 --> URI Class Initialized
DEBUG - 2013-09-02 19:05:45 --> Router Class Initialized
DEBUG - 2013-09-02 19:05:45 --> Output Class Initialized
DEBUG - 2013-09-02 19:05:45 --> Security Class Initialized
DEBUG - 2013-09-02 19:05:45 --> Input Class Initialized
DEBUG - 2013-09-02 19:05:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 19:05:45 --> Language Class Initialized
DEBUG - 2013-09-02 19:05:45 --> Loader Class Initialized
DEBUG - 2013-09-02 19:05:45 --> Database Driver Class Initialized
DEBUG - 2013-09-02 19:05:45 --> Controller Class Initialized
DEBUG - 2013-09-02 19:05:45 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-02 19:05:45 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 19:05:45 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:45 --> Helper loaded: date_helper
DEBUG - 2013-09-02 19:05:45 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:45 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:45 --> XSS Filtering completed
DEBUG - 2013-09-02 19:05:45 --> XSS Filtering completed
DEBUG - 2013-09-02 19:05:46 --> Config Class Initialized
DEBUG - 2013-09-02 19:05:46 --> Hooks Class Initialized
DEBUG - 2013-09-02 19:05:46 --> Utf8 Class Initialized
DEBUG - 2013-09-02 19:05:46 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 19:05:46 --> URI Class Initialized
DEBUG - 2013-09-02 19:05:46 --> Router Class Initialized
DEBUG - 2013-09-02 19:05:46 --> Output Class Initialized
DEBUG - 2013-09-02 19:05:46 --> Security Class Initialized
DEBUG - 2013-09-02 19:05:46 --> Input Class Initialized
DEBUG - 2013-09-02 19:05:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 19:05:46 --> Language Class Initialized
DEBUG - 2013-09-02 19:05:46 --> Loader Class Initialized
DEBUG - 2013-09-02 19:05:46 --> Database Driver Class Initialized
DEBUG - 2013-09-02 19:05:46 --> Controller Class Initialized
DEBUG - 2013-09-02 19:05:46 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-02 19:05:46 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 19:05:46 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:46 --> Helper loaded: date_helper
DEBUG - 2013-09-02 19:05:46 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:46 --> File loaded: application/views/admin.php
DEBUG - 2013-09-02 19:05:46 --> Final output sent to browser
DEBUG - 2013-09-02 19:05:46 --> Total execution time: 0.0330
DEBUG - 2013-09-02 19:05:47 --> Config Class Initialized
DEBUG - 2013-09-02 19:05:47 --> Hooks Class Initialized
DEBUG - 2013-09-02 19:05:47 --> Utf8 Class Initialized
DEBUG - 2013-09-02 19:05:47 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 19:05:47 --> URI Class Initialized
DEBUG - 2013-09-02 19:05:47 --> Router Class Initialized
DEBUG - 2013-09-02 19:05:47 --> Output Class Initialized
DEBUG - 2013-09-02 19:05:47 --> Security Class Initialized
DEBUG - 2013-09-02 19:05:47 --> Input Class Initialized
DEBUG - 2013-09-02 19:05:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 19:05:47 --> Language Class Initialized
DEBUG - 2013-09-02 19:05:47 --> Loader Class Initialized
DEBUG - 2013-09-02 19:05:47 --> Database Driver Class Initialized
DEBUG - 2013-09-02 19:05:47 --> Controller Class Initialized
DEBUG - 2013-09-02 19:05:47 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-02 19:05:47 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 19:05:47 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:47 --> Helper loaded: date_helper
DEBUG - 2013-09-02 19:05:47 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:47 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:47 --> XSS Filtering completed
DEBUG - 2013-09-02 19:05:49 --> Config Class Initialized
DEBUG - 2013-09-02 19:05:49 --> Hooks Class Initialized
DEBUG - 2013-09-02 19:05:49 --> Utf8 Class Initialized
DEBUG - 2013-09-02 19:05:49 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 19:05:49 --> URI Class Initialized
DEBUG - 2013-09-02 19:05:49 --> Router Class Initialized
DEBUG - 2013-09-02 19:05:49 --> Output Class Initialized
DEBUG - 2013-09-02 19:05:49 --> Security Class Initialized
DEBUG - 2013-09-02 19:05:49 --> Input Class Initialized
DEBUG - 2013-09-02 19:05:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 19:05:49 --> Language Class Initialized
DEBUG - 2013-09-02 19:05:49 --> Loader Class Initialized
DEBUG - 2013-09-02 19:05:49 --> Database Driver Class Initialized
DEBUG - 2013-09-02 19:05:49 --> Controller Class Initialized
DEBUG - 2013-09-02 19:05:49 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-02 19:05:49 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 19:05:49 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:49 --> Helper loaded: date_helper
DEBUG - 2013-09-02 19:05:49 --> Model Class Initialized
DEBUG - 2013-09-02 19:05:49 --> Model Class Initialized
DEBUG - 2013-09-02 20:55:33 --> Config Class Initialized
DEBUG - 2013-09-02 20:55:33 --> Hooks Class Initialized
DEBUG - 2013-09-02 20:55:33 --> Utf8 Class Initialized
DEBUG - 2013-09-02 20:55:33 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 20:55:33 --> URI Class Initialized
DEBUG - 2013-09-02 20:55:33 --> Router Class Initialized
DEBUG - 2013-09-02 20:55:33 --> No URI present. Default controller set.
DEBUG - 2013-09-02 20:55:33 --> Output Class Initialized
DEBUG - 2013-09-02 20:55:33 --> Security Class Initialized
DEBUG - 2013-09-02 20:55:33 --> Input Class Initialized
DEBUG - 2013-09-02 20:55:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 20:55:33 --> Language Class Initialized
DEBUG - 2013-09-02 20:55:33 --> Loader Class Initialized
DEBUG - 2013-09-02 20:55:33 --> Database Driver Class Initialized
DEBUG - 2013-09-02 20:55:33 --> Controller Class Initialized
DEBUG - 2013-09-02 20:55:33 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-02 20:55:33 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 20:55:33 --> Model Class Initialized
DEBUG - 2013-09-02 20:55:33 --> Helper loaded: date_helper
DEBUG - 2013-09-02 20:55:33 --> Model Class Initialized
DEBUG - 2013-09-02 20:55:33 --> File loaded: application/views/index.php
DEBUG - 2013-09-02 20:55:33 --> Final output sent to browser
DEBUG - 2013-09-02 20:55:33 --> Total execution time: 0.0750
DEBUG - 2013-09-02 20:55:35 --> Config Class Initialized
DEBUG - 2013-09-02 20:55:35 --> Hooks Class Initialized
DEBUG - 2013-09-02 20:55:35 --> Utf8 Class Initialized
DEBUG - 2013-09-02 20:55:35 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 20:55:35 --> URI Class Initialized
DEBUG - 2013-09-02 20:55:35 --> Router Class Initialized
DEBUG - 2013-09-02 20:55:35 --> Output Class Initialized
DEBUG - 2013-09-02 20:55:35 --> Security Class Initialized
DEBUG - 2013-09-02 20:55:35 --> Input Class Initialized
DEBUG - 2013-09-02 20:55:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 20:55:35 --> Language Class Initialized
DEBUG - 2013-09-02 20:55:35 --> Loader Class Initialized
DEBUG - 2013-09-02 20:55:35 --> Database Driver Class Initialized
DEBUG - 2013-09-02 20:55:35 --> Controller Class Initialized
DEBUG - 2013-09-02 20:55:35 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-02 20:55:35 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 20:55:35 --> Model Class Initialized
DEBUG - 2013-09-02 20:55:35 --> Helper loaded: date_helper
DEBUG - 2013-09-02 20:55:35 --> Model Class Initialized
DEBUG - 2013-09-02 20:55:35 --> File loaded: application/views/admin.php
DEBUG - 2013-09-02 20:55:35 --> Final output sent to browser
DEBUG - 2013-09-02 20:55:35 --> Total execution time: 0.0340
DEBUG - 2013-09-02 20:55:41 --> Config Class Initialized
DEBUG - 2013-09-02 20:55:41 --> Hooks Class Initialized
DEBUG - 2013-09-02 20:55:41 --> Utf8 Class Initialized
DEBUG - 2013-09-02 20:55:41 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 20:55:41 --> URI Class Initialized
DEBUG - 2013-09-02 20:55:41 --> Router Class Initialized
DEBUG - 2013-09-02 20:55:41 --> Output Class Initialized
DEBUG - 2013-09-02 20:55:41 --> Security Class Initialized
DEBUG - 2013-09-02 20:55:41 --> Input Class Initialized
DEBUG - 2013-09-02 20:55:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 20:55:41 --> Language Class Initialized
DEBUG - 2013-09-02 20:55:41 --> Loader Class Initialized
DEBUG - 2013-09-02 20:55:41 --> Database Driver Class Initialized
DEBUG - 2013-09-02 20:55:41 --> Controller Class Initialized
DEBUG - 2013-09-02 20:55:41 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-02 20:55:41 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 20:55:41 --> Model Class Initialized
DEBUG - 2013-09-02 20:55:41 --> Helper loaded: date_helper
DEBUG - 2013-09-02 20:55:41 --> Model Class Initialized
DEBUG - 2013-09-02 20:55:41 --> Model Class Initialized
DEBUG - 2013-09-02 20:55:41 --> XSS Filtering completed
DEBUG - 2013-09-02 20:55:41 --> XSS Filtering completed
DEBUG - 2013-09-02 20:55:43 --> Config Class Initialized
DEBUG - 2013-09-02 20:55:43 --> Hooks Class Initialized
DEBUG - 2013-09-02 20:55:43 --> Utf8 Class Initialized
DEBUG - 2013-09-02 20:55:43 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 20:55:43 --> URI Class Initialized
DEBUG - 2013-09-02 20:55:43 --> Router Class Initialized
DEBUG - 2013-09-02 20:55:43 --> Output Class Initialized
DEBUG - 2013-09-02 20:55:43 --> Security Class Initialized
DEBUG - 2013-09-02 20:55:43 --> Input Class Initialized
DEBUG - 2013-09-02 20:55:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 20:55:43 --> Language Class Initialized
DEBUG - 2013-09-02 20:55:43 --> Loader Class Initialized
DEBUG - 2013-09-02 20:55:43 --> Database Driver Class Initialized
DEBUG - 2013-09-02 20:55:43 --> Controller Class Initialized
DEBUG - 2013-09-02 20:55:43 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-02 20:55:43 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 20:55:43 --> Model Class Initialized
DEBUG - 2013-09-02 20:55:43 --> Helper loaded: date_helper
DEBUG - 2013-09-02 20:55:43 --> Model Class Initialized
DEBUG - 2013-09-02 20:55:43 --> Model Class Initialized
DEBUG - 2013-09-02 20:55:43 --> XSS Filtering completed
DEBUG - 2013-09-02 20:55:43 --> XSS Filtering completed
DEBUG - 2013-09-02 20:55:43 --> Config Class Initialized
DEBUG - 2013-09-02 20:55:43 --> Hooks Class Initialized
DEBUG - 2013-09-02 20:55:43 --> Utf8 Class Initialized
DEBUG - 2013-09-02 20:55:43 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 20:55:43 --> URI Class Initialized
DEBUG - 2013-09-02 20:55:43 --> Router Class Initialized
DEBUG - 2013-09-02 20:55:43 --> Output Class Initialized
DEBUG - 2013-09-02 20:55:43 --> Security Class Initialized
DEBUG - 2013-09-02 20:55:43 --> Input Class Initialized
DEBUG - 2013-09-02 20:55:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 20:55:43 --> Language Class Initialized
DEBUG - 2013-09-02 20:55:43 --> Loader Class Initialized
DEBUG - 2013-09-02 20:55:43 --> Database Driver Class Initialized
DEBUG - 2013-09-02 20:55:43 --> Controller Class Initialized
DEBUG - 2013-09-02 20:55:43 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-02 20:55:43 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 20:55:43 --> Model Class Initialized
DEBUG - 2013-09-02 20:55:43 --> Helper loaded: date_helper
DEBUG - 2013-09-02 20:55:43 --> Model Class Initialized
DEBUG - 2013-09-02 20:55:43 --> Model Class Initialized
DEBUG - 2013-09-02 20:55:43 --> XSS Filtering completed
DEBUG - 2013-09-02 20:55:43 --> XSS Filtering completed
DEBUG - 2013-09-02 20:55:43 --> XSS Filtering completed
DEBUG - 2013-09-02 20:55:44 --> Config Class Initialized
DEBUG - 2013-09-02 20:55:44 --> Hooks Class Initialized
DEBUG - 2013-09-02 20:55:44 --> Utf8 Class Initialized
DEBUG - 2013-09-02 20:55:44 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 20:55:44 --> URI Class Initialized
DEBUG - 2013-09-02 20:55:44 --> Router Class Initialized
DEBUG - 2013-09-02 20:55:44 --> Output Class Initialized
DEBUG - 2013-09-02 20:55:44 --> Security Class Initialized
DEBUG - 2013-09-02 20:55:44 --> Input Class Initialized
DEBUG - 2013-09-02 20:55:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 20:55:44 --> Language Class Initialized
DEBUG - 2013-09-02 20:55:44 --> Loader Class Initialized
DEBUG - 2013-09-02 20:55:44 --> Database Driver Class Initialized
DEBUG - 2013-09-02 20:55:44 --> Controller Class Initialized
DEBUG - 2013-09-02 20:55:44 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-02 20:55:44 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 20:55:44 --> Model Class Initialized
DEBUG - 2013-09-02 20:55:44 --> Helper loaded: date_helper
DEBUG - 2013-09-02 20:55:44 --> Model Class Initialized
DEBUG - 2013-09-02 20:55:44 --> Model Class Initialized
DEBUG - 2013-09-02 20:55:44 --> XSS Filtering completed
DEBUG - 2013-09-02 20:55:44 --> XSS Filtering completed
ERROR - 2013-09-02 20:55:44 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 185
ERROR - 2013-09-02 20:55:44 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-02 20:55:44 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-02 20:55:44 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 195
DEBUG - 2013-09-02 20:55:45 --> Config Class Initialized
DEBUG - 2013-09-02 20:55:45 --> Hooks Class Initialized
DEBUG - 2013-09-02 20:55:45 --> Utf8 Class Initialized
DEBUG - 2013-09-02 20:55:45 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 20:55:45 --> URI Class Initialized
DEBUG - 2013-09-02 20:55:45 --> Router Class Initialized
DEBUG - 2013-09-02 20:55:45 --> Output Class Initialized
DEBUG - 2013-09-02 20:55:45 --> Security Class Initialized
DEBUG - 2013-09-02 20:55:45 --> Input Class Initialized
DEBUG - 2013-09-02 20:55:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 20:55:45 --> Language Class Initialized
DEBUG - 2013-09-02 20:55:45 --> Loader Class Initialized
DEBUG - 2013-09-02 20:55:45 --> Database Driver Class Initialized
DEBUG - 2013-09-02 20:55:45 --> Controller Class Initialized
DEBUG - 2013-09-02 20:55:45 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-02 20:55:45 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 20:55:45 --> Model Class Initialized
DEBUG - 2013-09-02 20:55:45 --> Helper loaded: date_helper
DEBUG - 2013-09-02 20:55:45 --> Model Class Initialized
DEBUG - 2013-09-02 20:55:45 --> Model Class Initialized
DEBUG - 2013-09-02 20:55:45 --> XSS Filtering completed
DEBUG - 2013-09-02 20:55:51 --> Config Class Initialized
DEBUG - 2013-09-02 20:55:51 --> Config Class Initialized
DEBUG - 2013-09-02 20:55:51 --> Hooks Class Initialized
DEBUG - 2013-09-02 20:55:51 --> Hooks Class Initialized
DEBUG - 2013-09-02 20:55:51 --> Utf8 Class Initialized
DEBUG - 2013-09-02 20:55:51 --> Utf8 Class Initialized
DEBUG - 2013-09-02 20:55:51 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 20:55:51 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 20:55:51 --> URI Class Initialized
DEBUG - 2013-09-02 20:55:51 --> URI Class Initialized
DEBUG - 2013-09-02 20:55:51 --> Router Class Initialized
DEBUG - 2013-09-02 20:55:51 --> Router Class Initialized
DEBUG - 2013-09-02 20:55:51 --> Output Class Initialized
DEBUG - 2013-09-02 20:55:51 --> Output Class Initialized
DEBUG - 2013-09-02 20:55:51 --> Security Class Initialized
DEBUG - 2013-09-02 20:55:51 --> Security Class Initialized
DEBUG - 2013-09-02 20:55:51 --> Input Class Initialized
DEBUG - 2013-09-02 20:55:51 --> Input Class Initialized
DEBUG - 2013-09-02 20:55:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 20:55:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 20:55:51 --> Language Class Initialized
DEBUG - 2013-09-02 20:55:51 --> Language Class Initialized
DEBUG - 2013-09-02 20:55:51 --> Loader Class Initialized
DEBUG - 2013-09-02 20:55:51 --> Loader Class Initialized
DEBUG - 2013-09-02 20:55:51 --> Database Driver Class Initialized
DEBUG - 2013-09-02 20:55:51 --> Database Driver Class Initialized
DEBUG - 2013-09-02 20:55:51 --> Controller Class Initialized
DEBUG - 2013-09-02 20:55:51 --> Controller Class Initialized
DEBUG - 2013-09-02 20:55:51 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-02 20:55:51 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-02 20:55:51 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 20:55:51 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 20:55:51 --> Model Class Initialized
DEBUG - 2013-09-02 20:55:51 --> Model Class Initialized
DEBUG - 2013-09-02 20:55:51 --> Helper loaded: date_helper
DEBUG - 2013-09-02 20:55:51 --> Helper loaded: date_helper
DEBUG - 2013-09-02 20:55:51 --> Model Class Initialized
DEBUG - 2013-09-02 20:55:51 --> Model Class Initialized
DEBUG - 2013-09-02 20:55:51 --> Model Class Initialized
DEBUG - 2013-09-02 20:55:51 --> Model Class Initialized
DEBUG - 2013-09-02 20:55:51 --> XSS Filtering completed
DEBUG - 2013-09-02 20:55:51 --> XSS Filtering completed
DEBUG - 2013-09-02 20:55:51 --> XSS Filtering completed
DEBUG - 2013-09-02 20:55:51 --> XSS Filtering completed
DEBUG - 2013-09-02 20:55:51 --> XSS Filtering completed
ERROR - 2013-09-02 20:55:51 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 185
ERROR - 2013-09-02 20:55:51 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-02 20:55:51 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-02 20:55:51 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 195
DEBUG - 2013-09-02 20:55:55 --> Config Class Initialized
DEBUG - 2013-09-02 20:55:55 --> Hooks Class Initialized
DEBUG - 2013-09-02 20:55:55 --> Utf8 Class Initialized
DEBUG - 2013-09-02 20:55:55 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 20:55:55 --> URI Class Initialized
DEBUG - 2013-09-02 20:55:55 --> Router Class Initialized
DEBUG - 2013-09-02 20:55:55 --> Output Class Initialized
DEBUG - 2013-09-02 20:55:55 --> Security Class Initialized
DEBUG - 2013-09-02 20:55:55 --> Input Class Initialized
DEBUG - 2013-09-02 20:55:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 20:55:55 --> Language Class Initialized
DEBUG - 2013-09-02 20:55:55 --> Loader Class Initialized
DEBUG - 2013-09-02 20:55:55 --> Database Driver Class Initialized
DEBUG - 2013-09-02 20:55:55 --> Controller Class Initialized
DEBUG - 2013-09-02 20:55:55 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-02 20:55:55 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 20:55:55 --> Model Class Initialized
DEBUG - 2013-09-02 20:55:55 --> Helper loaded: date_helper
DEBUG - 2013-09-02 20:55:55 --> Model Class Initialized
DEBUG - 2013-09-02 20:55:55 --> File loaded: application/views/admin.php
DEBUG - 2013-09-02 20:55:55 --> Final output sent to browser
DEBUG - 2013-09-02 20:55:55 --> Total execution time: 0.0640
DEBUG - 2013-09-02 20:55:55 --> Config Class Initialized
DEBUG - 2013-09-02 20:55:55 --> Hooks Class Initialized
DEBUG - 2013-09-02 20:55:55 --> Utf8 Class Initialized
DEBUG - 2013-09-02 20:55:55 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 20:55:55 --> URI Class Initialized
DEBUG - 2013-09-02 20:55:55 --> Router Class Initialized
DEBUG - 2013-09-02 20:55:55 --> Output Class Initialized
DEBUG - 2013-09-02 20:55:55 --> Security Class Initialized
DEBUG - 2013-09-02 20:55:55 --> Input Class Initialized
DEBUG - 2013-09-02 20:55:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 20:55:55 --> Language Class Initialized
DEBUG - 2013-09-02 20:55:55 --> Loader Class Initialized
DEBUG - 2013-09-02 20:55:55 --> Database Driver Class Initialized
DEBUG - 2013-09-02 20:55:55 --> Controller Class Initialized
DEBUG - 2013-09-02 20:55:55 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-02 20:55:55 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 20:55:55 --> Model Class Initialized
DEBUG - 2013-09-02 20:55:55 --> Helper loaded: date_helper
DEBUG - 2013-09-02 20:55:55 --> Model Class Initialized
DEBUG - 2013-09-02 20:55:55 --> Table Class Initialized
DEBUG - 2013-09-02 20:56:04 --> Config Class Initialized
DEBUG - 2013-09-02 20:56:04 --> Hooks Class Initialized
DEBUG - 2013-09-02 20:56:04 --> Utf8 Class Initialized
DEBUG - 2013-09-02 20:56:04 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 20:56:04 --> URI Class Initialized
DEBUG - 2013-09-02 20:56:04 --> Router Class Initialized
DEBUG - 2013-09-02 20:56:04 --> Output Class Initialized
DEBUG - 2013-09-02 20:56:04 --> Security Class Initialized
DEBUG - 2013-09-02 20:56:04 --> Input Class Initialized
DEBUG - 2013-09-02 20:56:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 20:56:04 --> Language Class Initialized
DEBUG - 2013-09-02 20:56:04 --> Loader Class Initialized
DEBUG - 2013-09-02 20:56:04 --> Database Driver Class Initialized
DEBUG - 2013-09-02 20:56:04 --> Controller Class Initialized
DEBUG - 2013-09-02 20:56:04 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-02 20:56:04 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 20:56:04 --> Model Class Initialized
DEBUG - 2013-09-02 20:56:04 --> Helper loaded: date_helper
DEBUG - 2013-09-02 20:56:04 --> Model Class Initialized
DEBUG - 2013-09-02 20:56:04 --> File loaded: application/views/admin.php
DEBUG - 2013-09-02 20:56:04 --> Final output sent to browser
DEBUG - 2013-09-02 20:56:04 --> Total execution time: 0.0330
DEBUG - 2013-09-02 20:56:05 --> Config Class Initialized
DEBUG - 2013-09-02 20:56:05 --> Hooks Class Initialized
DEBUG - 2013-09-02 20:56:05 --> Utf8 Class Initialized
DEBUG - 2013-09-02 20:56:05 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 20:56:05 --> URI Class Initialized
DEBUG - 2013-09-02 20:56:05 --> Router Class Initialized
DEBUG - 2013-09-02 20:56:05 --> Output Class Initialized
DEBUG - 2013-09-02 20:56:05 --> Security Class Initialized
DEBUG - 2013-09-02 20:56:05 --> Input Class Initialized
DEBUG - 2013-09-02 20:56:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 20:56:05 --> Language Class Initialized
DEBUG - 2013-09-02 20:56:05 --> Loader Class Initialized
DEBUG - 2013-09-02 20:56:05 --> Database Driver Class Initialized
DEBUG - 2013-09-02 20:56:05 --> Controller Class Initialized
DEBUG - 2013-09-02 20:56:05 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-02 20:56:05 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 20:56:05 --> Model Class Initialized
DEBUG - 2013-09-02 20:56:05 --> Helper loaded: date_helper
DEBUG - 2013-09-02 20:56:05 --> Model Class Initialized
DEBUG - 2013-09-02 20:56:05 --> Model Class Initialized
DEBUG - 2013-09-02 20:56:05 --> Config Class Initialized
DEBUG - 2013-09-02 20:56:05 --> Hooks Class Initialized
DEBUG - 2013-09-02 20:56:05 --> XSS Filtering completed
DEBUG - 2013-09-02 20:56:05 --> XSS Filtering completed
DEBUG - 2013-09-02 20:56:05 --> Utf8 Class Initialized
DEBUG - 2013-09-02 20:56:05 --> UTF-8 Support Enabled
DEBUG - 2013-09-02 20:56:05 --> XSS Filtering completed
DEBUG - 2013-09-02 20:56:05 --> URI Class Initialized
DEBUG - 2013-09-02 20:56:05 --> Router Class Initialized
DEBUG - 2013-09-02 20:56:05 --> Output Class Initialized
DEBUG - 2013-09-02 20:56:05 --> Security Class Initialized
DEBUG - 2013-09-02 20:56:05 --> Input Class Initialized
DEBUG - 2013-09-02 20:56:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-02 20:56:05 --> Language Class Initialized
DEBUG - 2013-09-02 20:56:05 --> Loader Class Initialized
DEBUG - 2013-09-02 20:56:05 --> Database Driver Class Initialized
DEBUG - 2013-09-02 20:56:05 --> Controller Class Initialized
DEBUG - 2013-09-02 20:56:05 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-02 20:56:05 --> Helper loaded: inflector_helper
DEBUG - 2013-09-02 20:56:05 --> Model Class Initialized
DEBUG - 2013-09-02 20:56:05 --> Helper loaded: date_helper
DEBUG - 2013-09-02 20:56:05 --> Model Class Initialized
DEBUG - 2013-09-02 20:56:05 --> Model Class Initialized
DEBUG - 2013-09-02 20:56:05 --> XSS Filtering completed
DEBUG - 2013-09-02 20:56:05 --> XSS Filtering completed
ERROR - 2013-09-02 20:56:05 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 185
ERROR - 2013-09-02 20:56:05 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-02 20:56:05 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-02 20:56:05 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 195
