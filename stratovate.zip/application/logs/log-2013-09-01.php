<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-09-01 02:24:51 --> Config Class Initialized
DEBUG - 2013-09-01 02:24:51 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:24:51 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:24:51 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:24:51 --> URI Class Initialized
DEBUG - 2013-09-01 02:24:51 --> Router Class Initialized
DEBUG - 2013-09-01 02:24:51 --> No URI present. Default controller set.
DEBUG - 2013-09-01 02:24:51 --> Output Class Initialized
DEBUG - 2013-09-01 02:24:51 --> Security Class Initialized
DEBUG - 2013-09-01 02:24:51 --> Input Class Initialized
DEBUG - 2013-09-01 02:24:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:24:51 --> Language Class Initialized
DEBUG - 2013-09-01 02:24:51 --> Loader Class Initialized
DEBUG - 2013-09-01 02:24:51 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:24:51 --> Controller Class Initialized
DEBUG - 2013-09-01 02:24:51 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:24:51 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:24:51 --> Model Class Initialized
DEBUG - 2013-09-01 02:24:51 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:24:51 --> Model Class Initialized
DEBUG - 2013-09-01 02:24:57 --> Config Class Initialized
DEBUG - 2013-09-01 02:24:57 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:24:57 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:24:57 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:24:57 --> URI Class Initialized
DEBUG - 2013-09-01 02:24:57 --> Router Class Initialized
ERROR - 2013-09-01 02:24:57 --> 404 Page Not Found --> admin
DEBUG - 2013-09-01 02:24:59 --> Config Class Initialized
DEBUG - 2013-09-01 02:24:59 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:24:59 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:24:59 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:24:59 --> URI Class Initialized
DEBUG - 2013-09-01 02:24:59 --> Router Class Initialized
ERROR - 2013-09-01 02:24:59 --> 404 Page Not Found --> admin
DEBUG - 2013-09-01 02:25:01 --> Config Class Initialized
DEBUG - 2013-09-01 02:25:01 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:25:01 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:25:01 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:25:01 --> URI Class Initialized
DEBUG - 2013-09-01 02:25:01 --> Router Class Initialized
ERROR - 2013-09-01 02:25:01 --> 404 Page Not Found --> admin
DEBUG - 2013-09-01 02:25:02 --> Config Class Initialized
DEBUG - 2013-09-01 02:25:02 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:25:02 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:25:02 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:25:02 --> URI Class Initialized
DEBUG - 2013-09-01 02:25:02 --> Router Class Initialized
ERROR - 2013-09-01 02:25:02 --> 404 Page Not Found --> admin
DEBUG - 2013-09-01 02:25:18 --> Config Class Initialized
DEBUG - 2013-09-01 02:25:18 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:25:18 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:25:18 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:25:18 --> URI Class Initialized
DEBUG - 2013-09-01 02:25:18 --> Router Class Initialized
ERROR - 2013-09-01 02:25:18 --> 404 Page Not Found --> admin
DEBUG - 2013-09-01 02:25:19 --> Config Class Initialized
DEBUG - 2013-09-01 02:25:19 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:25:19 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:25:19 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:25:19 --> URI Class Initialized
DEBUG - 2013-09-01 02:25:19 --> Router Class Initialized
ERROR - 2013-09-01 02:25:19 --> 404 Page Not Found --> admin
DEBUG - 2013-09-01 02:25:19 --> Config Class Initialized
DEBUG - 2013-09-01 02:25:19 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:25:19 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:25:19 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:25:19 --> URI Class Initialized
DEBUG - 2013-09-01 02:25:19 --> Router Class Initialized
ERROR - 2013-09-01 02:25:19 --> 404 Page Not Found --> admin
DEBUG - 2013-09-01 02:25:19 --> Config Class Initialized
DEBUG - 2013-09-01 02:25:19 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:25:19 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:25:19 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:25:19 --> URI Class Initialized
DEBUG - 2013-09-01 02:25:19 --> Router Class Initialized
ERROR - 2013-09-01 02:25:19 --> 404 Page Not Found --> admin
DEBUG - 2013-09-01 02:25:19 --> Config Class Initialized
DEBUG - 2013-09-01 02:25:19 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:25:19 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:25:19 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:25:19 --> URI Class Initialized
DEBUG - 2013-09-01 02:25:19 --> Router Class Initialized
ERROR - 2013-09-01 02:25:19 --> 404 Page Not Found --> admin
DEBUG - 2013-09-01 02:25:20 --> Config Class Initialized
DEBUG - 2013-09-01 02:25:20 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:25:20 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:25:20 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:25:20 --> URI Class Initialized
DEBUG - 2013-09-01 02:25:20 --> Router Class Initialized
ERROR - 2013-09-01 02:25:20 --> 404 Page Not Found --> admin
DEBUG - 2013-09-01 02:25:20 --> Config Class Initialized
DEBUG - 2013-09-01 02:25:20 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:25:20 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:25:20 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:25:20 --> URI Class Initialized
DEBUG - 2013-09-01 02:25:20 --> Router Class Initialized
ERROR - 2013-09-01 02:25:20 --> 404 Page Not Found --> admin
DEBUG - 2013-09-01 02:25:24 --> Config Class Initialized
DEBUG - 2013-09-01 02:25:24 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:25:24 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:25:24 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:25:24 --> URI Class Initialized
DEBUG - 2013-09-01 02:25:24 --> Router Class Initialized
ERROR - 2013-09-01 02:25:24 --> 404 Page Not Found --> admin
DEBUG - 2013-09-01 02:25:24 --> Config Class Initialized
DEBUG - 2013-09-01 02:25:24 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:25:24 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:25:24 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:25:24 --> URI Class Initialized
DEBUG - 2013-09-01 02:25:24 --> Router Class Initialized
ERROR - 2013-09-01 02:25:24 --> 404 Page Not Found --> admin
DEBUG - 2013-09-01 02:25:24 --> Config Class Initialized
DEBUG - 2013-09-01 02:25:24 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:25:24 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:25:24 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:25:24 --> URI Class Initialized
DEBUG - 2013-09-01 02:25:24 --> Router Class Initialized
ERROR - 2013-09-01 02:25:24 --> 404 Page Not Found --> admin
DEBUG - 2013-09-01 02:25:24 --> Config Class Initialized
DEBUG - 2013-09-01 02:25:24 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:25:24 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:25:24 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:25:24 --> URI Class Initialized
DEBUG - 2013-09-01 02:25:24 --> Router Class Initialized
ERROR - 2013-09-01 02:25:24 --> 404 Page Not Found --> admin
DEBUG - 2013-09-01 02:25:56 --> Config Class Initialized
DEBUG - 2013-09-01 02:25:56 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:25:56 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:25:56 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:25:56 --> URI Class Initialized
DEBUG - 2013-09-01 02:25:56 --> Router Class Initialized
DEBUG - 2013-09-01 02:25:56 --> Output Class Initialized
DEBUG - 2013-09-01 02:25:56 --> Security Class Initialized
DEBUG - 2013-09-01 02:25:56 --> Input Class Initialized
DEBUG - 2013-09-01 02:25:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:25:56 --> Language Class Initialized
ERROR - 2013-09-01 02:25:56 --> 404 Page Not Found --> admin/index
DEBUG - 2013-09-01 02:25:56 --> Config Class Initialized
DEBUG - 2013-09-01 02:25:56 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:25:56 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:25:56 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:25:56 --> URI Class Initialized
DEBUG - 2013-09-01 02:25:56 --> Router Class Initialized
DEBUG - 2013-09-01 02:25:56 --> Output Class Initialized
DEBUG - 2013-09-01 02:25:56 --> Security Class Initialized
DEBUG - 2013-09-01 02:25:56 --> Input Class Initialized
DEBUG - 2013-09-01 02:25:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:25:56 --> Language Class Initialized
ERROR - 2013-09-01 02:25:56 --> 404 Page Not Found --> admin/index
DEBUG - 2013-09-01 02:25:56 --> Config Class Initialized
DEBUG - 2013-09-01 02:25:56 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:25:56 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:25:56 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:25:56 --> URI Class Initialized
DEBUG - 2013-09-01 02:25:56 --> Router Class Initialized
DEBUG - 2013-09-01 02:25:56 --> Output Class Initialized
DEBUG - 2013-09-01 02:25:56 --> Security Class Initialized
DEBUG - 2013-09-01 02:25:56 --> Input Class Initialized
DEBUG - 2013-09-01 02:25:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:25:56 --> Language Class Initialized
ERROR - 2013-09-01 02:25:56 --> 404 Page Not Found --> admin/index
DEBUG - 2013-09-01 02:25:59 --> Config Class Initialized
DEBUG - 2013-09-01 02:25:59 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:25:59 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:25:59 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:25:59 --> URI Class Initialized
DEBUG - 2013-09-01 02:25:59 --> Router Class Initialized
DEBUG - 2013-09-01 02:25:59 --> No URI present. Default controller set.
DEBUG - 2013-09-01 02:25:59 --> Output Class Initialized
DEBUG - 2013-09-01 02:25:59 --> Security Class Initialized
DEBUG - 2013-09-01 02:25:59 --> Input Class Initialized
DEBUG - 2013-09-01 02:25:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:25:59 --> Language Class Initialized
DEBUG - 2013-09-01 02:25:59 --> Loader Class Initialized
DEBUG - 2013-09-01 02:25:59 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:25:59 --> Controller Class Initialized
DEBUG - 2013-09-01 02:25:59 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:25:59 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:25:59 --> Model Class Initialized
DEBUG - 2013-09-01 02:25:59 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:25:59 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:00 --> Config Class Initialized
DEBUG - 2013-09-01 02:26:00 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:26:00 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:26:00 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:26:00 --> URI Class Initialized
DEBUG - 2013-09-01 02:26:00 --> Router Class Initialized
DEBUG - 2013-09-01 02:26:00 --> No URI present. Default controller set.
DEBUG - 2013-09-01 02:26:00 --> Output Class Initialized
DEBUG - 2013-09-01 02:26:00 --> Security Class Initialized
DEBUG - 2013-09-01 02:26:00 --> Input Class Initialized
DEBUG - 2013-09-01 02:26:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:26:00 --> Language Class Initialized
DEBUG - 2013-09-01 02:26:00 --> Loader Class Initialized
DEBUG - 2013-09-01 02:26:00 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:26:00 --> Controller Class Initialized
DEBUG - 2013-09-01 02:26:00 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:26:00 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:26:00 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:00 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:26:00 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:13 --> Config Class Initialized
DEBUG - 2013-09-01 02:26:13 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:26:13 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:26:13 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:26:13 --> URI Class Initialized
DEBUG - 2013-09-01 02:26:13 --> Router Class Initialized
DEBUG - 2013-09-01 02:26:13 --> Output Class Initialized
DEBUG - 2013-09-01 02:26:13 --> Security Class Initialized
DEBUG - 2013-09-01 02:26:13 --> Input Class Initialized
DEBUG - 2013-09-01 02:26:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:26:13 --> Language Class Initialized
DEBUG - 2013-09-01 02:26:13 --> Loader Class Initialized
DEBUG - 2013-09-01 02:26:13 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:26:13 --> Controller Class Initialized
DEBUG - 2013-09-01 02:26:13 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:26:13 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:26:13 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:13 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:26:13 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:13 --> File loaded: application/views/admin.php
DEBUG - 2013-09-01 02:26:13 --> Final output sent to browser
DEBUG - 2013-09-01 02:26:13 --> Total execution time: 0.0340
DEBUG - 2013-09-01 02:26:17 --> Config Class Initialized
DEBUG - 2013-09-01 02:26:17 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:26:17 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:26:17 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:26:17 --> URI Class Initialized
DEBUG - 2013-09-01 02:26:17 --> Router Class Initialized
DEBUG - 2013-09-01 02:26:17 --> Output Class Initialized
DEBUG - 2013-09-01 02:26:17 --> Security Class Initialized
DEBUG - 2013-09-01 02:26:17 --> Input Class Initialized
DEBUG - 2013-09-01 02:26:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:26:17 --> Language Class Initialized
DEBUG - 2013-09-01 02:26:17 --> Loader Class Initialized
DEBUG - 2013-09-01 02:26:17 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:26:17 --> Controller Class Initialized
DEBUG - 2013-09-01 02:26:17 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:26:17 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:26:17 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:17 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:26:17 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:17 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:17 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:17 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:17 --> Config Class Initialized
DEBUG - 2013-09-01 02:26:17 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:26:17 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:26:17 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:26:17 --> URI Class Initialized
DEBUG - 2013-09-01 02:26:17 --> Router Class Initialized
DEBUG - 2013-09-01 02:26:17 --> Config Class Initialized
DEBUG - 2013-09-01 02:26:17 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:26:17 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:26:17 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:26:17 --> Output Class Initialized
DEBUG - 2013-09-01 02:26:17 --> URI Class Initialized
DEBUG - 2013-09-01 02:26:17 --> Security Class Initialized
DEBUG - 2013-09-01 02:26:17 --> Router Class Initialized
DEBUG - 2013-09-01 02:26:17 --> Input Class Initialized
DEBUG - 2013-09-01 02:26:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:26:17 --> Language Class Initialized
DEBUG - 2013-09-01 02:26:17 --> Output Class Initialized
DEBUG - 2013-09-01 02:26:17 --> Security Class Initialized
DEBUG - 2013-09-01 02:26:17 --> Input Class Initialized
DEBUG - 2013-09-01 02:26:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:26:17 --> Language Class Initialized
DEBUG - 2013-09-01 02:26:17 --> Loader Class Initialized
DEBUG - 2013-09-01 02:26:17 --> Loader Class Initialized
DEBUG - 2013-09-01 02:26:17 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:26:17 --> Controller Class Initialized
DEBUG - 2013-09-01 02:26:17 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:26:17 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:26:17 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:26:17 --> Controller Class Initialized
DEBUG - 2013-09-01 02:26:17 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:26:17 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:17 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:26:17 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:26:17 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:17 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:17 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:26:17 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:17 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:17 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:17 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:17 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:17 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:17 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:17 --> XSS Filtering completed
ERROR - 2013-09-01 02:26:17 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 181
ERROR - 2013-09-01 02:26:17 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 186
ERROR - 2013-09-01 02:26:17 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 186
ERROR - 2013-09-01 02:26:17 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 191
DEBUG - 2013-09-01 02:26:22 --> Config Class Initialized
DEBUG - 2013-09-01 02:26:22 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:26:22 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:26:22 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:26:22 --> URI Class Initialized
DEBUG - 2013-09-01 02:26:22 --> Config Class Initialized
DEBUG - 2013-09-01 02:26:22 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:26:22 --> Router Class Initialized
DEBUG - 2013-09-01 02:26:22 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:26:22 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:26:22 --> Output Class Initialized
DEBUG - 2013-09-01 02:26:22 --> URI Class Initialized
DEBUG - 2013-09-01 02:26:22 --> Router Class Initialized
DEBUG - 2013-09-01 02:26:22 --> Security Class Initialized
DEBUG - 2013-09-01 02:26:22 --> Input Class Initialized
DEBUG - 2013-09-01 02:26:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:26:22 --> Output Class Initialized
DEBUG - 2013-09-01 02:26:22 --> Language Class Initialized
DEBUG - 2013-09-01 02:26:22 --> Security Class Initialized
DEBUG - 2013-09-01 02:26:22 --> Input Class Initialized
DEBUG - 2013-09-01 02:26:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:26:22 --> Language Class Initialized
DEBUG - 2013-09-01 02:26:22 --> Loader Class Initialized
DEBUG - 2013-09-01 02:26:22 --> Loader Class Initialized
DEBUG - 2013-09-01 02:26:22 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:26:22 --> Controller Class Initialized
DEBUG - 2013-09-01 02:26:22 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:26:22 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:26:22 --> Controller Class Initialized
DEBUG - 2013-09-01 02:26:22 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:26:22 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:26:22 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:22 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:26:22 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:26:22 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:22 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:22 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:26:22 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:22 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:22 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:22 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:22 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:22 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:22 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:22 --> XSS Filtering completed
ERROR - 2013-09-01 02:26:22 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 181
ERROR - 2013-09-01 02:26:22 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 186
ERROR - 2013-09-01 02:26:22 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 186
ERROR - 2013-09-01 02:26:22 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 191
DEBUG - 2013-09-01 02:26:25 --> Config Class Initialized
DEBUG - 2013-09-01 02:26:25 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:26:25 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:26:25 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:26:25 --> URI Class Initialized
DEBUG - 2013-09-01 02:26:25 --> Config Class Initialized
DEBUG - 2013-09-01 02:26:25 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:26:25 --> Router Class Initialized
DEBUG - 2013-09-01 02:26:25 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:26:25 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:26:25 --> Output Class Initialized
DEBUG - 2013-09-01 02:26:25 --> URI Class Initialized
DEBUG - 2013-09-01 02:26:25 --> Security Class Initialized
DEBUG - 2013-09-01 02:26:25 --> Router Class Initialized
DEBUG - 2013-09-01 02:26:25 --> Input Class Initialized
DEBUG - 2013-09-01 02:26:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:26:25 --> Output Class Initialized
DEBUG - 2013-09-01 02:26:25 --> Language Class Initialized
DEBUG - 2013-09-01 02:26:25 --> Security Class Initialized
DEBUG - 2013-09-01 02:26:25 --> Input Class Initialized
DEBUG - 2013-09-01 02:26:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:26:25 --> Language Class Initialized
DEBUG - 2013-09-01 02:26:25 --> Loader Class Initialized
DEBUG - 2013-09-01 02:26:25 --> Loader Class Initialized
DEBUG - 2013-09-01 02:26:25 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:26:25 --> Controller Class Initialized
DEBUG - 2013-09-01 02:26:25 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:26:25 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:26:25 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:26:25 --> Controller Class Initialized
DEBUG - 2013-09-01 02:26:25 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:26:25 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:25 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:26:25 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:26:25 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:25 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:25 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:26:25 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:25 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:25 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:25 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:25 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:25 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:25 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:25 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:25 --> XSS Filtering completed
ERROR - 2013-09-01 02:26:25 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 181
ERROR - 2013-09-01 02:26:25 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 186
ERROR - 2013-09-01 02:26:25 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 186
ERROR - 2013-09-01 02:26:25 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 191
DEBUG - 2013-09-01 02:26:27 --> Config Class Initialized
DEBUG - 2013-09-01 02:26:27 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:26:27 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:26:27 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:26:27 --> URI Class Initialized
DEBUG - 2013-09-01 02:26:27 --> Config Class Initialized
DEBUG - 2013-09-01 02:26:27 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:26:27 --> Router Class Initialized
DEBUG - 2013-09-01 02:26:27 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:26:27 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:26:27 --> Output Class Initialized
DEBUG - 2013-09-01 02:26:27 --> URI Class Initialized
DEBUG - 2013-09-01 02:26:27 --> Security Class Initialized
DEBUG - 2013-09-01 02:26:27 --> Router Class Initialized
DEBUG - 2013-09-01 02:26:27 --> Input Class Initialized
DEBUG - 2013-09-01 02:26:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:26:27 --> Output Class Initialized
DEBUG - 2013-09-01 02:26:27 --> Language Class Initialized
DEBUG - 2013-09-01 02:26:27 --> Security Class Initialized
DEBUG - 2013-09-01 02:26:27 --> Input Class Initialized
DEBUG - 2013-09-01 02:26:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:26:27 --> Language Class Initialized
DEBUG - 2013-09-01 02:26:27 --> Loader Class Initialized
DEBUG - 2013-09-01 02:26:27 --> Loader Class Initialized
DEBUG - 2013-09-01 02:26:27 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:26:27 --> Controller Class Initialized
DEBUG - 2013-09-01 02:26:27 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:26:27 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:26:27 --> Controller Class Initialized
DEBUG - 2013-09-01 02:26:27 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:26:27 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:26:27 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:26:27 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:27 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:26:27 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:27 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:27 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:26:27 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:27 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:27 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:27 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:27 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:27 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:27 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:27 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:27 --> XSS Filtering completed
ERROR - 2013-09-01 02:26:27 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 181
ERROR - 2013-09-01 02:26:27 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 186
ERROR - 2013-09-01 02:26:27 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 186
ERROR - 2013-09-01 02:26:27 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 191
DEBUG - 2013-09-01 02:26:28 --> Config Class Initialized
DEBUG - 2013-09-01 02:26:28 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:26:28 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:26:28 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:26:28 --> URI Class Initialized
DEBUG - 2013-09-01 02:26:28 --> Router Class Initialized
DEBUG - 2013-09-01 02:26:28 --> Config Class Initialized
DEBUG - 2013-09-01 02:26:28 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:26:28 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:26:28 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:26:28 --> Output Class Initialized
DEBUG - 2013-09-01 02:26:28 --> URI Class Initialized
DEBUG - 2013-09-01 02:26:28 --> Security Class Initialized
DEBUG - 2013-09-01 02:26:28 --> Router Class Initialized
DEBUG - 2013-09-01 02:26:28 --> Input Class Initialized
DEBUG - 2013-09-01 02:26:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:26:28 --> Output Class Initialized
DEBUG - 2013-09-01 02:26:28 --> Language Class Initialized
DEBUG - 2013-09-01 02:26:28 --> Security Class Initialized
DEBUG - 2013-09-01 02:26:28 --> Input Class Initialized
DEBUG - 2013-09-01 02:26:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:26:28 --> Language Class Initialized
DEBUG - 2013-09-01 02:26:28 --> Loader Class Initialized
DEBUG - 2013-09-01 02:26:28 --> Loader Class Initialized
DEBUG - 2013-09-01 02:26:28 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:26:28 --> Controller Class Initialized
DEBUG - 2013-09-01 02:26:28 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:26:28 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:26:28 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:26:28 --> Controller Class Initialized
DEBUG - 2013-09-01 02:26:28 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:28 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:26:28 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:26:28 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:28 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:26:28 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:28 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:28 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:26:28 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:28 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:28 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:28 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:28 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:28 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:28 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:28 --> XSS Filtering completed
ERROR - 2013-09-01 02:26:28 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 181
ERROR - 2013-09-01 02:26:28 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 186
ERROR - 2013-09-01 02:26:28 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 186
ERROR - 2013-09-01 02:26:28 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 191
DEBUG - 2013-09-01 02:26:29 --> Config Class Initialized
DEBUG - 2013-09-01 02:26:29 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:26:29 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:26:29 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:26:29 --> URI Class Initialized
DEBUG - 2013-09-01 02:26:29 --> Router Class Initialized
DEBUG - 2013-09-01 02:26:29 --> Output Class Initialized
DEBUG - 2013-09-01 02:26:29 --> Security Class Initialized
DEBUG - 2013-09-01 02:26:29 --> Input Class Initialized
DEBUG - 2013-09-01 02:26:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:26:29 --> Language Class Initialized
DEBUG - 2013-09-01 02:26:29 --> Loader Class Initialized
DEBUG - 2013-09-01 02:26:29 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:26:29 --> Controller Class Initialized
DEBUG - 2013-09-01 02:26:29 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:26:29 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:26:29 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:29 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:26:29 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:29 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:29 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:31 --> Config Class Initialized
DEBUG - 2013-09-01 02:26:31 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:26:31 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:26:31 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:26:31 --> URI Class Initialized
DEBUG - 2013-09-01 02:26:31 --> Router Class Initialized
DEBUG - 2013-09-01 02:26:31 --> Output Class Initialized
DEBUG - 2013-09-01 02:26:31 --> Security Class Initialized
DEBUG - 2013-09-01 02:26:31 --> Input Class Initialized
DEBUG - 2013-09-01 02:26:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:26:31 --> Language Class Initialized
DEBUG - 2013-09-01 02:26:31 --> Loader Class Initialized
DEBUG - 2013-09-01 02:26:31 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:26:31 --> Controller Class Initialized
DEBUG - 2013-09-01 02:26:31 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:26:31 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:26:31 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:31 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:26:31 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:31 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:31 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:31 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:31 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:33 --> Config Class Initialized
DEBUG - 2013-09-01 02:26:33 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:26:33 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:26:33 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:26:33 --> URI Class Initialized
DEBUG - 2013-09-01 02:26:33 --> Router Class Initialized
DEBUG - 2013-09-01 02:26:33 --> Output Class Initialized
DEBUG - 2013-09-01 02:26:33 --> Security Class Initialized
DEBUG - 2013-09-01 02:26:33 --> Input Class Initialized
DEBUG - 2013-09-01 02:26:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:26:33 --> Language Class Initialized
DEBUG - 2013-09-01 02:26:33 --> Loader Class Initialized
DEBUG - 2013-09-01 02:26:33 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:26:33 --> Controller Class Initialized
DEBUG - 2013-09-01 02:26:33 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:26:33 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:26:33 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:33 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:26:33 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:33 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:33 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:33 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:33 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:34 --> Config Class Initialized
DEBUG - 2013-09-01 02:26:34 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:26:34 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:26:34 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:26:34 --> URI Class Initialized
DEBUG - 2013-09-01 02:26:34 --> Router Class Initialized
DEBUG - 2013-09-01 02:26:34 --> Output Class Initialized
DEBUG - 2013-09-01 02:26:34 --> Security Class Initialized
DEBUG - 2013-09-01 02:26:34 --> Input Class Initialized
DEBUG - 2013-09-01 02:26:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:26:34 --> Language Class Initialized
DEBUG - 2013-09-01 02:26:34 --> Loader Class Initialized
DEBUG - 2013-09-01 02:26:34 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:26:34 --> Controller Class Initialized
DEBUG - 2013-09-01 02:26:34 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:26:34 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:26:34 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:34 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:26:34 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:34 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:34 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:34 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:34 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:34 --> Config Class Initialized
DEBUG - 2013-09-01 02:26:34 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:26:34 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:26:34 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:26:34 --> URI Class Initialized
DEBUG - 2013-09-01 02:26:34 --> Router Class Initialized
DEBUG - 2013-09-01 02:26:34 --> Output Class Initialized
DEBUG - 2013-09-01 02:26:34 --> Security Class Initialized
DEBUG - 2013-09-01 02:26:34 --> Input Class Initialized
DEBUG - 2013-09-01 02:26:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:26:34 --> Language Class Initialized
DEBUG - 2013-09-01 02:26:34 --> Loader Class Initialized
DEBUG - 2013-09-01 02:26:34 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:26:34 --> Controller Class Initialized
DEBUG - 2013-09-01 02:26:34 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:26:34 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:26:34 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:34 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:26:34 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:34 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:34 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:34 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:34 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:35 --> Config Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:26:35 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:26:35 --> URI Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Router Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Output Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Security Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Input Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:26:35 --> Language Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Loader Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Controller Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:26:35 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:26:35 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:26:35 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:35 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:35 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:35 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:35 --> Config Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:26:35 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:26:35 --> URI Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Router Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Output Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Security Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Input Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:26:35 --> Language Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Loader Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Controller Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:26:35 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:26:35 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:26:35 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:35 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:35 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:35 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:35 --> Config Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:26:35 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:26:35 --> URI Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Router Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Output Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Security Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Input Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:26:35 --> Language Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Loader Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Controller Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:26:35 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:26:35 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:26:35 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:35 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:35 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:35 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:35 --> Config Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:26:35 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:26:35 --> URI Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Router Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Output Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Security Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Input Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:26:35 --> Language Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Loader Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Controller Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:26:35 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:26:35 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:26:35 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:35 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:35 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:35 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:35 --> Config Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:26:35 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:26:35 --> URI Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Router Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Output Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Security Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Input Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:26:35 --> Language Class Initialized
DEBUG - 2013-09-01 02:26:35 --> Loader Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Controller Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:26:36 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:26:36 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:26:36 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:36 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:36 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:36 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:36 --> Config Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:26:36 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:26:36 --> URI Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Router Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Output Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Security Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Input Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:26:36 --> Language Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Loader Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Controller Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:26:36 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:26:36 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:26:36 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:36 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:36 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:36 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:36 --> Config Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:26:36 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:26:36 --> URI Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Router Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Output Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Security Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Input Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:26:36 --> Language Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Loader Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Controller Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:26:36 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:26:36 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:26:36 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:36 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:36 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:36 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:36 --> Config Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:26:36 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:26:36 --> URI Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Router Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Output Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Security Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Input Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:26:36 --> Language Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Loader Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Controller Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:26:36 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:26:36 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:26:36 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:36 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:36 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:36 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:36 --> Config Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:26:36 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:26:36 --> URI Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Router Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Output Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Security Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Input Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:26:36 --> Language Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Loader Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Controller Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:26:36 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:26:36 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:26:36 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:36 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:36 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:36 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:36 --> Config Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:26:36 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:26:36 --> URI Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Router Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Output Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Security Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Input Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:26:36 --> Language Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Loader Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Controller Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:26:36 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:26:36 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:26:36 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:36 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:36 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:36 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:36 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:37 --> Config Class Initialized
DEBUG - 2013-09-01 02:26:37 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:26:37 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:26:37 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:26:37 --> URI Class Initialized
DEBUG - 2013-09-01 02:26:37 --> Router Class Initialized
DEBUG - 2013-09-01 02:26:37 --> Output Class Initialized
DEBUG - 2013-09-01 02:26:37 --> Security Class Initialized
DEBUG - 2013-09-01 02:26:37 --> Input Class Initialized
DEBUG - 2013-09-01 02:26:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:26:37 --> Language Class Initialized
DEBUG - 2013-09-01 02:26:37 --> Loader Class Initialized
DEBUG - 2013-09-01 02:26:37 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:26:37 --> Controller Class Initialized
DEBUG - 2013-09-01 02:26:37 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:26:37 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:26:37 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:37 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:26:37 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:37 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:37 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:37 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:37 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:38 --> Config Class Initialized
DEBUG - 2013-09-01 02:26:38 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:26:38 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:26:38 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:26:38 --> URI Class Initialized
DEBUG - 2013-09-01 02:26:38 --> Router Class Initialized
DEBUG - 2013-09-01 02:26:38 --> Output Class Initialized
DEBUG - 2013-09-01 02:26:38 --> Security Class Initialized
DEBUG - 2013-09-01 02:26:38 --> Input Class Initialized
DEBUG - 2013-09-01 02:26:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:26:38 --> Language Class Initialized
DEBUG - 2013-09-01 02:26:38 --> Loader Class Initialized
DEBUG - 2013-09-01 02:26:38 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:26:38 --> Controller Class Initialized
DEBUG - 2013-09-01 02:26:38 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:26:38 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:26:38 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:38 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:26:38 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:38 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:38 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:38 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:38 --> Config Class Initialized
DEBUG - 2013-09-01 02:26:38 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:26:38 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:26:38 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:26:38 --> URI Class Initialized
DEBUG - 2013-09-01 02:26:38 --> Router Class Initialized
DEBUG - 2013-09-01 02:26:38 --> Output Class Initialized
DEBUG - 2013-09-01 02:26:38 --> Security Class Initialized
DEBUG - 2013-09-01 02:26:38 --> Input Class Initialized
DEBUG - 2013-09-01 02:26:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:26:38 --> Language Class Initialized
DEBUG - 2013-09-01 02:26:38 --> Loader Class Initialized
DEBUG - 2013-09-01 02:26:38 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:26:38 --> Controller Class Initialized
DEBUG - 2013-09-01 02:26:38 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:26:38 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:26:38 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:38 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:26:38 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:38 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:38 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:38 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:39 --> Config Class Initialized
DEBUG - 2013-09-01 02:26:39 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:26:39 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:26:39 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:26:39 --> URI Class Initialized
DEBUG - 2013-09-01 02:26:39 --> Router Class Initialized
DEBUG - 2013-09-01 02:26:39 --> Output Class Initialized
DEBUG - 2013-09-01 02:26:39 --> Security Class Initialized
DEBUG - 2013-09-01 02:26:39 --> Input Class Initialized
DEBUG - 2013-09-01 02:26:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:26:39 --> Language Class Initialized
DEBUG - 2013-09-01 02:26:39 --> Loader Class Initialized
DEBUG - 2013-09-01 02:26:39 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:26:39 --> Controller Class Initialized
DEBUG - 2013-09-01 02:26:39 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:26:39 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:26:39 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:39 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:26:39 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:39 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:39 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:39 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:39 --> Config Class Initialized
DEBUG - 2013-09-01 02:26:39 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:26:39 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:26:39 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:26:39 --> URI Class Initialized
DEBUG - 2013-09-01 02:26:39 --> Router Class Initialized
DEBUG - 2013-09-01 02:26:39 --> Output Class Initialized
DEBUG - 2013-09-01 02:26:39 --> Security Class Initialized
DEBUG - 2013-09-01 02:26:39 --> Input Class Initialized
DEBUG - 2013-09-01 02:26:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:26:39 --> Language Class Initialized
DEBUG - 2013-09-01 02:26:39 --> Loader Class Initialized
DEBUG - 2013-09-01 02:26:39 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:26:39 --> Controller Class Initialized
DEBUG - 2013-09-01 02:26:39 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:26:39 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:26:39 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:39 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:26:39 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:39 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:39 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:39 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:40 --> Config Class Initialized
DEBUG - 2013-09-01 02:26:40 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:26:40 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:26:40 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:26:40 --> URI Class Initialized
DEBUG - 2013-09-01 02:26:40 --> Router Class Initialized
DEBUG - 2013-09-01 02:26:40 --> Output Class Initialized
DEBUG - 2013-09-01 02:26:40 --> Security Class Initialized
DEBUG - 2013-09-01 02:26:40 --> Input Class Initialized
DEBUG - 2013-09-01 02:26:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:26:40 --> Language Class Initialized
DEBUG - 2013-09-01 02:26:40 --> Loader Class Initialized
DEBUG - 2013-09-01 02:26:40 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:26:40 --> Controller Class Initialized
DEBUG - 2013-09-01 02:26:40 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:26:40 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:26:40 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:40 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:26:40 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:40 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:40 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:40 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:41 --> Config Class Initialized
DEBUG - 2013-09-01 02:26:41 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:26:41 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:26:41 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:26:41 --> URI Class Initialized
DEBUG - 2013-09-01 02:26:41 --> Router Class Initialized
DEBUG - 2013-09-01 02:26:41 --> Output Class Initialized
DEBUG - 2013-09-01 02:26:41 --> Security Class Initialized
DEBUG - 2013-09-01 02:26:41 --> Input Class Initialized
DEBUG - 2013-09-01 02:26:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:26:41 --> Language Class Initialized
DEBUG - 2013-09-01 02:26:41 --> Loader Class Initialized
DEBUG - 2013-09-01 02:26:41 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:26:41 --> Controller Class Initialized
DEBUG - 2013-09-01 02:26:41 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:26:41 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:26:41 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:41 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:26:41 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:41 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:41 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:41 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:42 --> Config Class Initialized
DEBUG - 2013-09-01 02:26:42 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:26:42 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:26:42 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:26:42 --> URI Class Initialized
DEBUG - 2013-09-01 02:26:42 --> Router Class Initialized
DEBUG - 2013-09-01 02:26:42 --> Output Class Initialized
DEBUG - 2013-09-01 02:26:42 --> Security Class Initialized
DEBUG - 2013-09-01 02:26:42 --> Input Class Initialized
DEBUG - 2013-09-01 02:26:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:26:42 --> Language Class Initialized
DEBUG - 2013-09-01 02:26:42 --> Loader Class Initialized
DEBUG - 2013-09-01 02:26:42 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:26:42 --> Controller Class Initialized
DEBUG - 2013-09-01 02:26:42 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:26:42 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:26:42 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:42 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:26:42 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:42 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:42 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:42 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:42 --> Config Class Initialized
DEBUG - 2013-09-01 02:26:42 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:26:42 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:26:42 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:26:42 --> URI Class Initialized
DEBUG - 2013-09-01 02:26:42 --> Router Class Initialized
DEBUG - 2013-09-01 02:26:42 --> Output Class Initialized
DEBUG - 2013-09-01 02:26:42 --> Security Class Initialized
DEBUG - 2013-09-01 02:26:42 --> Input Class Initialized
DEBUG - 2013-09-01 02:26:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:26:42 --> Language Class Initialized
DEBUG - 2013-09-01 02:26:42 --> Loader Class Initialized
DEBUG - 2013-09-01 02:26:42 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:26:42 --> Controller Class Initialized
DEBUG - 2013-09-01 02:26:42 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:26:42 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:26:42 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:42 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:26:42 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:42 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:42 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:42 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:42 --> Config Class Initialized
DEBUG - 2013-09-01 02:26:42 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:26:42 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:26:42 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:26:42 --> URI Class Initialized
DEBUG - 2013-09-01 02:26:42 --> Router Class Initialized
DEBUG - 2013-09-01 02:26:42 --> Output Class Initialized
DEBUG - 2013-09-01 02:26:42 --> Security Class Initialized
DEBUG - 2013-09-01 02:26:42 --> Input Class Initialized
DEBUG - 2013-09-01 02:26:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:26:42 --> Language Class Initialized
DEBUG - 2013-09-01 02:26:42 --> Loader Class Initialized
DEBUG - 2013-09-01 02:26:42 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:26:42 --> Controller Class Initialized
DEBUG - 2013-09-01 02:26:42 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:26:42 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:26:42 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:42 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:26:42 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:42 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:42 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:42 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:44 --> Config Class Initialized
DEBUG - 2013-09-01 02:26:44 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:26:44 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:26:44 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:26:44 --> URI Class Initialized
DEBUG - 2013-09-01 02:26:44 --> Router Class Initialized
DEBUG - 2013-09-01 02:26:44 --> Output Class Initialized
DEBUG - 2013-09-01 02:26:44 --> Security Class Initialized
DEBUG - 2013-09-01 02:26:44 --> Input Class Initialized
DEBUG - 2013-09-01 02:26:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:26:44 --> Language Class Initialized
DEBUG - 2013-09-01 02:26:44 --> Loader Class Initialized
DEBUG - 2013-09-01 02:26:44 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:26:44 --> Controller Class Initialized
DEBUG - 2013-09-01 02:26:44 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:26:44 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:26:44 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:44 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:26:44 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:44 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:44 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:44 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:44 --> Config Class Initialized
DEBUG - 2013-09-01 02:26:44 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:26:44 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:26:44 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:26:44 --> URI Class Initialized
DEBUG - 2013-09-01 02:26:44 --> Router Class Initialized
DEBUG - 2013-09-01 02:26:44 --> Output Class Initialized
DEBUG - 2013-09-01 02:26:44 --> Security Class Initialized
DEBUG - 2013-09-01 02:26:44 --> Input Class Initialized
DEBUG - 2013-09-01 02:26:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:26:44 --> Language Class Initialized
DEBUG - 2013-09-01 02:26:44 --> Loader Class Initialized
DEBUG - 2013-09-01 02:26:44 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:26:44 --> Controller Class Initialized
DEBUG - 2013-09-01 02:26:44 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:26:44 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:26:44 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:44 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:26:44 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:44 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:44 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:44 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:45 --> Config Class Initialized
DEBUG - 2013-09-01 02:26:45 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:26:45 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:26:45 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:26:45 --> URI Class Initialized
DEBUG - 2013-09-01 02:26:45 --> Router Class Initialized
DEBUG - 2013-09-01 02:26:45 --> Output Class Initialized
DEBUG - 2013-09-01 02:26:45 --> Security Class Initialized
DEBUG - 2013-09-01 02:26:45 --> Input Class Initialized
DEBUG - 2013-09-01 02:26:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:26:45 --> Language Class Initialized
DEBUG - 2013-09-01 02:26:45 --> Loader Class Initialized
DEBUG - 2013-09-01 02:26:45 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:26:45 --> Controller Class Initialized
DEBUG - 2013-09-01 02:26:45 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:26:45 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:26:45 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:45 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:26:45 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:45 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:45 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:45 --> XSS Filtering completed
DEBUG - 2013-09-01 02:26:46 --> Config Class Initialized
DEBUG - 2013-09-01 02:26:46 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:26:46 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:26:46 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:26:46 --> URI Class Initialized
DEBUG - 2013-09-01 02:26:46 --> Router Class Initialized
DEBUG - 2013-09-01 02:26:46 --> Output Class Initialized
DEBUG - 2013-09-01 02:26:46 --> Security Class Initialized
DEBUG - 2013-09-01 02:26:46 --> Input Class Initialized
DEBUG - 2013-09-01 02:26:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:26:46 --> Language Class Initialized
DEBUG - 2013-09-01 02:26:46 --> Loader Class Initialized
DEBUG - 2013-09-01 02:26:46 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:26:46 --> Controller Class Initialized
DEBUG - 2013-09-01 02:26:46 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:26:46 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:26:46 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:46 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:26:46 --> Model Class Initialized
DEBUG - 2013-09-01 02:26:46 --> Model Class Initialized
DEBUG - 2013-09-01 02:28:40 --> Config Class Initialized
DEBUG - 2013-09-01 02:28:40 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:28:40 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:28:40 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:28:40 --> URI Class Initialized
DEBUG - 2013-09-01 02:28:40 --> Router Class Initialized
DEBUG - 2013-09-01 02:28:40 --> Output Class Initialized
DEBUG - 2013-09-01 02:28:40 --> Security Class Initialized
DEBUG - 2013-09-01 02:28:40 --> Input Class Initialized
DEBUG - 2013-09-01 02:28:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:28:40 --> Language Class Initialized
DEBUG - 2013-09-01 02:28:40 --> Loader Class Initialized
DEBUG - 2013-09-01 02:28:40 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:28:40 --> Controller Class Initialized
DEBUG - 2013-09-01 02:28:40 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:28:40 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:28:40 --> Model Class Initialized
DEBUG - 2013-09-01 02:28:40 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:28:40 --> Model Class Initialized
DEBUG - 2013-09-01 02:28:40 --> File loaded: application/views/admin.php
DEBUG - 2013-09-01 02:28:40 --> Final output sent to browser
DEBUG - 2013-09-01 02:28:40 --> Total execution time: 0.0350
DEBUG - 2013-09-01 02:28:44 --> Config Class Initialized
DEBUG - 2013-09-01 02:28:44 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:28:44 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:28:44 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:28:44 --> URI Class Initialized
DEBUG - 2013-09-01 02:28:44 --> Router Class Initialized
DEBUG - 2013-09-01 02:28:44 --> No URI present. Default controller set.
DEBUG - 2013-09-01 02:28:44 --> Output Class Initialized
DEBUG - 2013-09-01 02:28:44 --> Security Class Initialized
DEBUG - 2013-09-01 02:28:44 --> Input Class Initialized
DEBUG - 2013-09-01 02:28:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:28:44 --> Language Class Initialized
DEBUG - 2013-09-01 02:28:44 --> Loader Class Initialized
DEBUG - 2013-09-01 02:28:44 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:28:44 --> Controller Class Initialized
DEBUG - 2013-09-01 02:28:44 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:28:44 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:28:44 --> Model Class Initialized
DEBUG - 2013-09-01 02:28:44 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:28:44 --> Model Class Initialized
DEBUG - 2013-09-01 02:28:44 --> File loaded: application/views/index.php
DEBUG - 2013-09-01 02:28:44 --> Final output sent to browser
DEBUG - 2013-09-01 02:28:44 --> Total execution time: 0.0400
DEBUG - 2013-09-01 02:28:44 --> Config Class Initialized
DEBUG - 2013-09-01 02:28:44 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:28:44 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:28:44 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:28:44 --> URI Class Initialized
DEBUG - 2013-09-01 02:28:44 --> Router Class Initialized
ERROR - 2013-09-01 02:28:44 --> 404 Page Not Found --> Visitors_Kiosk.swf
DEBUG - 2013-09-01 02:28:55 --> Config Class Initialized
DEBUG - 2013-09-01 02:28:55 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:28:55 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:28:55 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:28:55 --> URI Class Initialized
DEBUG - 2013-09-01 02:28:55 --> Router Class Initialized
DEBUG - 2013-09-01 02:28:55 --> No URI present. Default controller set.
DEBUG - 2013-09-01 02:28:55 --> Output Class Initialized
DEBUG - 2013-09-01 02:28:55 --> Security Class Initialized
DEBUG - 2013-09-01 02:28:55 --> Input Class Initialized
DEBUG - 2013-09-01 02:28:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:28:55 --> Language Class Initialized
DEBUG - 2013-09-01 02:28:55 --> Loader Class Initialized
DEBUG - 2013-09-01 02:28:55 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:28:55 --> Controller Class Initialized
DEBUG - 2013-09-01 02:28:55 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:28:55 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:28:55 --> Model Class Initialized
DEBUG - 2013-09-01 02:28:55 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:28:55 --> Model Class Initialized
DEBUG - 2013-09-01 02:28:55 --> File loaded: application/views/index.php
DEBUG - 2013-09-01 02:28:55 --> Final output sent to browser
DEBUG - 2013-09-01 02:28:55 --> Total execution time: 0.0340
DEBUG - 2013-09-01 02:29:15 --> Config Class Initialized
DEBUG - 2013-09-01 02:29:15 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:29:15 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:29:15 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:29:15 --> URI Class Initialized
DEBUG - 2013-09-01 02:29:15 --> Router Class Initialized
DEBUG - 2013-09-01 02:29:15 --> No URI present. Default controller set.
DEBUG - 2013-09-01 02:29:15 --> Output Class Initialized
DEBUG - 2013-09-01 02:29:15 --> Security Class Initialized
DEBUG - 2013-09-01 02:29:15 --> Input Class Initialized
DEBUG - 2013-09-01 02:29:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:29:15 --> Language Class Initialized
DEBUG - 2013-09-01 02:29:15 --> Loader Class Initialized
DEBUG - 2013-09-01 02:29:15 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:29:15 --> Controller Class Initialized
DEBUG - 2013-09-01 02:29:15 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:29:15 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:29:15 --> Model Class Initialized
DEBUG - 2013-09-01 02:29:15 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:29:15 --> Model Class Initialized
DEBUG - 2013-09-01 02:29:15 --> File loaded: application/views/index.php
DEBUG - 2013-09-01 02:29:15 --> Final output sent to browser
DEBUG - 2013-09-01 02:29:15 --> Total execution time: 0.0360
DEBUG - 2013-09-01 02:29:16 --> Config Class Initialized
DEBUG - 2013-09-01 02:29:16 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:29:16 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:29:16 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:29:16 --> URI Class Initialized
DEBUG - 2013-09-01 02:29:16 --> Router Class Initialized
DEBUG - 2013-09-01 02:29:16 --> No URI present. Default controller set.
DEBUG - 2013-09-01 02:29:16 --> Output Class Initialized
DEBUG - 2013-09-01 02:29:16 --> Security Class Initialized
DEBUG - 2013-09-01 02:29:16 --> Input Class Initialized
DEBUG - 2013-09-01 02:29:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:29:16 --> Language Class Initialized
DEBUG - 2013-09-01 02:29:16 --> Loader Class Initialized
DEBUG - 2013-09-01 02:29:16 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:29:16 --> Controller Class Initialized
DEBUG - 2013-09-01 02:29:16 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:29:16 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:29:16 --> Model Class Initialized
DEBUG - 2013-09-01 02:29:16 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:29:16 --> Model Class Initialized
DEBUG - 2013-09-01 02:29:16 --> File loaded: application/views/index.php
DEBUG - 2013-09-01 02:29:16 --> Final output sent to browser
DEBUG - 2013-09-01 02:29:16 --> Total execution time: 0.0350
DEBUG - 2013-09-01 02:29:16 --> Config Class Initialized
DEBUG - 2013-09-01 02:29:16 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:29:16 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:29:16 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:29:16 --> URI Class Initialized
DEBUG - 2013-09-01 02:29:16 --> Router Class Initialized
DEBUG - 2013-09-01 02:29:16 --> No URI present. Default controller set.
DEBUG - 2013-09-01 02:29:16 --> Output Class Initialized
DEBUG - 2013-09-01 02:29:16 --> Security Class Initialized
DEBUG - 2013-09-01 02:29:16 --> Input Class Initialized
DEBUG - 2013-09-01 02:29:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:29:16 --> Language Class Initialized
DEBUG - 2013-09-01 02:29:16 --> Loader Class Initialized
DEBUG - 2013-09-01 02:29:16 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:29:16 --> Controller Class Initialized
DEBUG - 2013-09-01 02:29:16 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:29:16 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:29:16 --> Model Class Initialized
DEBUG - 2013-09-01 02:29:16 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:29:16 --> Model Class Initialized
DEBUG - 2013-09-01 02:29:16 --> File loaded: application/views/index.php
DEBUG - 2013-09-01 02:29:16 --> Final output sent to browser
DEBUG - 2013-09-01 02:29:16 --> Total execution time: 0.0360
DEBUG - 2013-09-01 02:29:16 --> Config Class Initialized
DEBUG - 2013-09-01 02:29:16 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:29:16 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:29:16 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:29:16 --> URI Class Initialized
DEBUG - 2013-09-01 02:29:16 --> Router Class Initialized
DEBUG - 2013-09-01 02:29:16 --> No URI present. Default controller set.
DEBUG - 2013-09-01 02:29:16 --> Output Class Initialized
DEBUG - 2013-09-01 02:29:16 --> Security Class Initialized
DEBUG - 2013-09-01 02:29:16 --> Input Class Initialized
DEBUG - 2013-09-01 02:29:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:29:16 --> Language Class Initialized
DEBUG - 2013-09-01 02:29:16 --> Loader Class Initialized
DEBUG - 2013-09-01 02:29:16 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:29:16 --> Controller Class Initialized
DEBUG - 2013-09-01 02:29:16 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:29:16 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:29:16 --> Model Class Initialized
DEBUG - 2013-09-01 02:29:16 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:29:16 --> Model Class Initialized
DEBUG - 2013-09-01 02:29:16 --> File loaded: application/views/index.php
DEBUG - 2013-09-01 02:29:16 --> Final output sent to browser
DEBUG - 2013-09-01 02:29:16 --> Total execution time: 0.0390
DEBUG - 2013-09-01 02:29:17 --> Config Class Initialized
DEBUG - 2013-09-01 02:29:17 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:29:17 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:29:17 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:29:17 --> URI Class Initialized
DEBUG - 2013-09-01 02:29:17 --> Router Class Initialized
DEBUG - 2013-09-01 02:29:17 --> No URI present. Default controller set.
DEBUG - 2013-09-01 02:29:17 --> Output Class Initialized
DEBUG - 2013-09-01 02:29:17 --> Security Class Initialized
DEBUG - 2013-09-01 02:29:17 --> Input Class Initialized
DEBUG - 2013-09-01 02:29:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:29:17 --> Language Class Initialized
DEBUG - 2013-09-01 02:29:17 --> Loader Class Initialized
DEBUG - 2013-09-01 02:29:17 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:29:17 --> Controller Class Initialized
DEBUG - 2013-09-01 02:29:17 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:29:17 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:29:17 --> Model Class Initialized
DEBUG - 2013-09-01 02:29:17 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:29:17 --> Model Class Initialized
DEBUG - 2013-09-01 02:29:17 --> Config Class Initialized
DEBUG - 2013-09-01 02:29:17 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:29:17 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:29:17 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:29:17 --> URI Class Initialized
DEBUG - 2013-09-01 02:29:17 --> Router Class Initialized
DEBUG - 2013-09-01 02:29:17 --> No URI present. Default controller set.
DEBUG - 2013-09-01 02:29:17 --> Output Class Initialized
DEBUG - 2013-09-01 02:29:17 --> Security Class Initialized
DEBUG - 2013-09-01 02:29:17 --> Input Class Initialized
DEBUG - 2013-09-01 02:29:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:29:17 --> Language Class Initialized
DEBUG - 2013-09-01 02:29:17 --> Loader Class Initialized
DEBUG - 2013-09-01 02:29:17 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:29:17 --> Controller Class Initialized
DEBUG - 2013-09-01 02:29:17 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:29:17 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:29:17 --> Model Class Initialized
DEBUG - 2013-09-01 02:29:17 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:29:17 --> Model Class Initialized
DEBUG - 2013-09-01 02:29:17 --> File loaded: application/views/index.php
DEBUG - 2013-09-01 02:29:17 --> File loaded: application/views/index.php
DEBUG - 2013-09-01 02:29:17 --> Final output sent to browser
DEBUG - 2013-09-01 02:29:17 --> Final output sent to browser
DEBUG - 2013-09-01 02:29:17 --> Total execution time: 0.1890
DEBUG - 2013-09-01 02:29:17 --> Total execution time: 0.0910
DEBUG - 2013-09-01 02:29:49 --> Config Class Initialized
DEBUG - 2013-09-01 02:29:49 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:29:49 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:29:49 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:29:49 --> URI Class Initialized
DEBUG - 2013-09-01 02:29:49 --> Router Class Initialized
DEBUG - 2013-09-01 02:29:49 --> No URI present. Default controller set.
DEBUG - 2013-09-01 02:29:49 --> Output Class Initialized
DEBUG - 2013-09-01 02:29:49 --> Security Class Initialized
DEBUG - 2013-09-01 02:29:49 --> Input Class Initialized
DEBUG - 2013-09-01 02:29:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:29:49 --> Language Class Initialized
DEBUG - 2013-09-01 02:29:49 --> Loader Class Initialized
DEBUG - 2013-09-01 02:29:49 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:29:49 --> Controller Class Initialized
DEBUG - 2013-09-01 02:29:49 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:29:49 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:29:49 --> Model Class Initialized
DEBUG - 2013-09-01 02:29:49 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:29:49 --> Model Class Initialized
DEBUG - 2013-09-01 02:29:49 --> File loaded: application/views/index.php
DEBUG - 2013-09-01 02:29:49 --> Final output sent to browser
DEBUG - 2013-09-01 02:29:49 --> Total execution time: 0.0350
DEBUG - 2013-09-01 02:30:21 --> Config Class Initialized
DEBUG - 2013-09-01 02:30:21 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:30:21 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:30:21 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:30:21 --> URI Class Initialized
DEBUG - 2013-09-01 02:30:21 --> Router Class Initialized
DEBUG - 2013-09-01 02:30:21 --> No URI present. Default controller set.
DEBUG - 2013-09-01 02:30:21 --> Output Class Initialized
DEBUG - 2013-09-01 02:30:21 --> Security Class Initialized
DEBUG - 2013-09-01 02:30:21 --> Input Class Initialized
DEBUG - 2013-09-01 02:30:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:30:21 --> Language Class Initialized
DEBUG - 2013-09-01 02:30:21 --> Loader Class Initialized
DEBUG - 2013-09-01 02:30:21 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:30:21 --> Controller Class Initialized
DEBUG - 2013-09-01 02:30:21 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:30:21 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:30:21 --> Model Class Initialized
DEBUG - 2013-09-01 02:30:21 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:30:21 --> Model Class Initialized
DEBUG - 2013-09-01 02:30:21 --> File loaded: application/views/index.php
DEBUG - 2013-09-01 02:30:21 --> Final output sent to browser
DEBUG - 2013-09-01 02:30:21 --> Total execution time: 0.0340
DEBUG - 2013-09-01 02:30:35 --> Config Class Initialized
DEBUG - 2013-09-01 02:30:35 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:30:35 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:30:35 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:30:35 --> URI Class Initialized
DEBUG - 2013-09-01 02:30:35 --> Router Class Initialized
DEBUG - 2013-09-01 02:30:35 --> No URI present. Default controller set.
DEBUG - 2013-09-01 02:30:35 --> Output Class Initialized
DEBUG - 2013-09-01 02:30:35 --> Security Class Initialized
DEBUG - 2013-09-01 02:30:35 --> Input Class Initialized
DEBUG - 2013-09-01 02:30:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:30:35 --> Language Class Initialized
DEBUG - 2013-09-01 02:30:35 --> Loader Class Initialized
DEBUG - 2013-09-01 02:30:35 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:30:35 --> Controller Class Initialized
DEBUG - 2013-09-01 02:30:35 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:30:35 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:30:35 --> Model Class Initialized
DEBUG - 2013-09-01 02:30:35 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:30:35 --> Model Class Initialized
DEBUG - 2013-09-01 02:30:35 --> File loaded: application/views/index.php
DEBUG - 2013-09-01 02:30:35 --> Final output sent to browser
DEBUG - 2013-09-01 02:30:35 --> Total execution time: 0.0340
DEBUG - 2013-09-01 02:30:46 --> Config Class Initialized
DEBUG - 2013-09-01 02:30:46 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:30:46 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:30:46 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:30:46 --> URI Class Initialized
DEBUG - 2013-09-01 02:30:46 --> Router Class Initialized
DEBUG - 2013-09-01 02:30:46 --> No URI present. Default controller set.
DEBUG - 2013-09-01 02:30:46 --> Output Class Initialized
DEBUG - 2013-09-01 02:30:46 --> Security Class Initialized
DEBUG - 2013-09-01 02:30:46 --> Input Class Initialized
DEBUG - 2013-09-01 02:30:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:30:46 --> Language Class Initialized
DEBUG - 2013-09-01 02:30:46 --> Loader Class Initialized
DEBUG - 2013-09-01 02:30:46 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:30:46 --> Controller Class Initialized
DEBUG - 2013-09-01 02:30:46 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:30:46 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:30:46 --> Model Class Initialized
DEBUG - 2013-09-01 02:30:46 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:30:46 --> Model Class Initialized
DEBUG - 2013-09-01 02:30:46 --> File loaded: application/views/index.php
DEBUG - 2013-09-01 02:30:46 --> Final output sent to browser
DEBUG - 2013-09-01 02:30:46 --> Total execution time: 0.0370
DEBUG - 2013-09-01 02:31:04 --> Config Class Initialized
DEBUG - 2013-09-01 02:31:04 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:31:04 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:31:04 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:31:04 --> URI Class Initialized
DEBUG - 2013-09-01 02:31:04 --> Router Class Initialized
DEBUG - 2013-09-01 02:31:04 --> No URI present. Default controller set.
DEBUG - 2013-09-01 02:31:04 --> Output Class Initialized
DEBUG - 2013-09-01 02:31:04 --> Security Class Initialized
DEBUG - 2013-09-01 02:31:04 --> Input Class Initialized
DEBUG - 2013-09-01 02:31:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:31:04 --> Language Class Initialized
DEBUG - 2013-09-01 02:31:04 --> Loader Class Initialized
DEBUG - 2013-09-01 02:31:04 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:31:04 --> Controller Class Initialized
DEBUG - 2013-09-01 02:31:04 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:31:04 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:31:04 --> Model Class Initialized
DEBUG - 2013-09-01 02:31:04 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:31:04 --> Model Class Initialized
DEBUG - 2013-09-01 02:31:04 --> File loaded: application/views/index.php
DEBUG - 2013-09-01 02:31:04 --> Final output sent to browser
DEBUG - 2013-09-01 02:31:04 --> Total execution time: 0.0410
DEBUG - 2013-09-01 02:31:09 --> Config Class Initialized
DEBUG - 2013-09-01 02:31:09 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:31:09 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:31:09 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:31:09 --> URI Class Initialized
DEBUG - 2013-09-01 02:31:09 --> Router Class Initialized
DEBUG - 2013-09-01 02:31:09 --> No URI present. Default controller set.
DEBUG - 2013-09-01 02:31:09 --> Output Class Initialized
DEBUG - 2013-09-01 02:31:09 --> Security Class Initialized
DEBUG - 2013-09-01 02:31:09 --> Input Class Initialized
DEBUG - 2013-09-01 02:31:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:31:09 --> Language Class Initialized
DEBUG - 2013-09-01 02:31:09 --> Loader Class Initialized
DEBUG - 2013-09-01 02:31:09 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:31:09 --> Controller Class Initialized
DEBUG - 2013-09-01 02:31:09 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:31:09 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:31:09 --> Model Class Initialized
DEBUG - 2013-09-01 02:31:09 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:31:09 --> Model Class Initialized
DEBUG - 2013-09-01 02:31:09 --> File loaded: application/views/index.php
DEBUG - 2013-09-01 02:31:09 --> Final output sent to browser
DEBUG - 2013-09-01 02:31:09 --> Total execution time: 0.0370
DEBUG - 2013-09-01 02:34:05 --> Config Class Initialized
DEBUG - 2013-09-01 02:34:05 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:34:05 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:34:05 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:34:05 --> URI Class Initialized
DEBUG - 2013-09-01 02:34:05 --> Router Class Initialized
ERROR - 2013-09-01 02:34:05 --> 404 Page Not Found --> admins
DEBUG - 2013-09-01 02:34:07 --> Config Class Initialized
DEBUG - 2013-09-01 02:34:07 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:34:07 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:34:07 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:34:07 --> URI Class Initialized
DEBUG - 2013-09-01 02:34:07 --> Router Class Initialized
DEBUG - 2013-09-01 02:34:07 --> Output Class Initialized
DEBUG - 2013-09-01 02:34:07 --> Security Class Initialized
DEBUG - 2013-09-01 02:34:07 --> Input Class Initialized
DEBUG - 2013-09-01 02:34:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:34:07 --> Language Class Initialized
DEBUG - 2013-09-01 02:34:07 --> Loader Class Initialized
DEBUG - 2013-09-01 02:34:07 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:34:07 --> Controller Class Initialized
DEBUG - 2013-09-01 02:34:07 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:34:07 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:34:07 --> Model Class Initialized
DEBUG - 2013-09-01 02:34:07 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:34:07 --> Model Class Initialized
DEBUG - 2013-09-01 02:34:07 --> File loaded: application/views/admin.php
DEBUG - 2013-09-01 02:34:07 --> Final output sent to browser
DEBUG - 2013-09-01 02:34:07 --> Total execution time: 0.0350
DEBUG - 2013-09-01 02:34:14 --> Config Class Initialized
DEBUG - 2013-09-01 02:34:14 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:34:14 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:34:14 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:34:14 --> URI Class Initialized
DEBUG - 2013-09-01 02:34:14 --> Router Class Initialized
DEBUG - 2013-09-01 02:34:14 --> Output Class Initialized
DEBUG - 2013-09-01 02:34:14 --> Security Class Initialized
DEBUG - 2013-09-01 02:34:14 --> Input Class Initialized
DEBUG - 2013-09-01 02:34:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:34:14 --> Language Class Initialized
DEBUG - 2013-09-01 02:34:14 --> Loader Class Initialized
DEBUG - 2013-09-01 02:34:14 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:34:14 --> Controller Class Initialized
DEBUG - 2013-09-01 02:34:14 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:34:14 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:34:14 --> Model Class Initialized
DEBUG - 2013-09-01 02:34:14 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:34:14 --> Model Class Initialized
DEBUG - 2013-09-01 02:34:14 --> Model Class Initialized
DEBUG - 2013-09-01 02:34:14 --> XSS Filtering completed
DEBUG - 2013-09-01 02:34:14 --> XSS Filtering completed
DEBUG - 2013-09-01 02:34:16 --> Config Class Initialized
DEBUG - 2013-09-01 02:34:16 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:34:17 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:34:17 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:34:17 --> URI Class Initialized
DEBUG - 2013-09-01 02:34:17 --> Router Class Initialized
DEBUG - 2013-09-01 02:34:17 --> Output Class Initialized
DEBUG - 2013-09-01 02:34:17 --> Security Class Initialized
DEBUG - 2013-09-01 02:34:17 --> Input Class Initialized
DEBUG - 2013-09-01 02:34:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:34:17 --> Language Class Initialized
DEBUG - 2013-09-01 02:34:17 --> Loader Class Initialized
DEBUG - 2013-09-01 02:34:17 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:34:17 --> Controller Class Initialized
DEBUG - 2013-09-01 02:34:17 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:34:17 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:34:17 --> Model Class Initialized
DEBUG - 2013-09-01 02:34:17 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:34:17 --> Model Class Initialized
DEBUG - 2013-09-01 02:34:17 --> Model Class Initialized
DEBUG - 2013-09-01 02:34:17 --> XSS Filtering completed
DEBUG - 2013-09-01 02:34:17 --> XSS Filtering completed
DEBUG - 2013-09-01 02:34:17 --> Config Class Initialized
DEBUG - 2013-09-01 02:34:17 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:34:17 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:34:17 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:34:17 --> URI Class Initialized
DEBUG - 2013-09-01 02:34:17 --> Router Class Initialized
DEBUG - 2013-09-01 02:34:17 --> Config Class Initialized
DEBUG - 2013-09-01 02:34:17 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:34:17 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:34:17 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:34:17 --> Output Class Initialized
DEBUG - 2013-09-01 02:34:17 --> URI Class Initialized
DEBUG - 2013-09-01 02:34:17 --> Router Class Initialized
DEBUG - 2013-09-01 02:34:17 --> Security Class Initialized
DEBUG - 2013-09-01 02:34:17 --> Input Class Initialized
DEBUG - 2013-09-01 02:34:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:34:17 --> Output Class Initialized
DEBUG - 2013-09-01 02:34:17 --> Language Class Initialized
DEBUG - 2013-09-01 02:34:17 --> Security Class Initialized
DEBUG - 2013-09-01 02:34:17 --> Input Class Initialized
DEBUG - 2013-09-01 02:34:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:34:17 --> Language Class Initialized
DEBUG - 2013-09-01 02:34:17 --> Loader Class Initialized
DEBUG - 2013-09-01 02:34:17 --> Loader Class Initialized
DEBUG - 2013-09-01 02:34:17 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:34:17 --> Controller Class Initialized
DEBUG - 2013-09-01 02:34:17 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:34:17 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:34:17 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:34:17 --> Controller Class Initialized
DEBUG - 2013-09-01 02:34:17 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:34:17 --> Model Class Initialized
DEBUG - 2013-09-01 02:34:17 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:34:17 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:34:17 --> Model Class Initialized
DEBUG - 2013-09-01 02:34:17 --> Model Class Initialized
DEBUG - 2013-09-01 02:34:17 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:34:17 --> Model Class Initialized
DEBUG - 2013-09-01 02:34:17 --> Model Class Initialized
DEBUG - 2013-09-01 02:34:17 --> XSS Filtering completed
DEBUG - 2013-09-01 02:34:17 --> XSS Filtering completed
DEBUG - 2013-09-01 02:34:17 --> Model Class Initialized
DEBUG - 2013-09-01 02:34:17 --> XSS Filtering completed
DEBUG - 2013-09-01 02:34:17 --> XSS Filtering completed
DEBUG - 2013-09-01 02:34:17 --> XSS Filtering completed
ERROR - 2013-09-01 02:34:17 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 181
ERROR - 2013-09-01 02:34:17 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 186
ERROR - 2013-09-01 02:34:17 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 186
ERROR - 2013-09-01 02:34:17 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 191
DEBUG - 2013-09-01 02:34:22 --> Config Class Initialized
DEBUG - 2013-09-01 02:34:22 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:34:22 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:34:22 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:34:22 --> URI Class Initialized
DEBUG - 2013-09-01 02:34:22 --> Config Class Initialized
DEBUG - 2013-09-01 02:34:22 --> Router Class Initialized
DEBUG - 2013-09-01 02:34:22 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:34:22 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:34:22 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:34:22 --> Output Class Initialized
DEBUG - 2013-09-01 02:34:22 --> URI Class Initialized
DEBUG - 2013-09-01 02:34:22 --> Security Class Initialized
DEBUG - 2013-09-01 02:34:22 --> Router Class Initialized
DEBUG - 2013-09-01 02:34:22 --> Input Class Initialized
DEBUG - 2013-09-01 02:34:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:34:22 --> Language Class Initialized
DEBUG - 2013-09-01 02:34:22 --> Output Class Initialized
DEBUG - 2013-09-01 02:34:22 --> Security Class Initialized
DEBUG - 2013-09-01 02:34:22 --> Input Class Initialized
DEBUG - 2013-09-01 02:34:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:34:22 --> Language Class Initialized
DEBUG - 2013-09-01 02:34:22 --> Loader Class Initialized
DEBUG - 2013-09-01 02:34:22 --> Loader Class Initialized
DEBUG - 2013-09-01 02:34:22 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:34:22 --> Controller Class Initialized
DEBUG - 2013-09-01 02:34:22 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:34:22 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:34:22 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:34:22 --> Controller Class Initialized
DEBUG - 2013-09-01 02:34:22 --> Model Class Initialized
DEBUG - 2013-09-01 02:34:22 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:34:22 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:34:22 --> Model Class Initialized
DEBUG - 2013-09-01 02:34:22 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:34:22 --> Model Class Initialized
DEBUG - 2013-09-01 02:34:22 --> Model Class Initialized
DEBUG - 2013-09-01 02:34:22 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:34:22 --> Model Class Initialized
DEBUG - 2013-09-01 02:34:22 --> XSS Filtering completed
DEBUG - 2013-09-01 02:34:22 --> XSS Filtering completed
DEBUG - 2013-09-01 02:34:22 --> XSS Filtering completed
DEBUG - 2013-09-01 02:34:22 --> Model Class Initialized
DEBUG - 2013-09-01 02:34:22 --> XSS Filtering completed
DEBUG - 2013-09-01 02:34:22 --> XSS Filtering completed
ERROR - 2013-09-01 02:34:22 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 181
ERROR - 2013-09-01 02:34:22 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 186
ERROR - 2013-09-01 02:34:22 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 186
ERROR - 2013-09-01 02:34:22 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 191
DEBUG - 2013-09-01 02:34:24 --> Config Class Initialized
DEBUG - 2013-09-01 02:34:24 --> Config Class Initialized
DEBUG - 2013-09-01 02:34:24 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:34:24 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:34:24 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:34:24 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:34:24 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:34:24 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:34:24 --> URI Class Initialized
DEBUG - 2013-09-01 02:34:24 --> URI Class Initialized
DEBUG - 2013-09-01 02:34:24 --> Router Class Initialized
DEBUG - 2013-09-01 02:34:24 --> Router Class Initialized
DEBUG - 2013-09-01 02:34:24 --> Output Class Initialized
DEBUG - 2013-09-01 02:34:24 --> Output Class Initialized
DEBUG - 2013-09-01 02:34:24 --> Security Class Initialized
DEBUG - 2013-09-01 02:34:24 --> Security Class Initialized
DEBUG - 2013-09-01 02:34:24 --> Input Class Initialized
DEBUG - 2013-09-01 02:34:24 --> Input Class Initialized
DEBUG - 2013-09-01 02:34:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:34:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:34:24 --> Language Class Initialized
DEBUG - 2013-09-01 02:34:24 --> Language Class Initialized
DEBUG - 2013-09-01 02:34:24 --> Loader Class Initialized
DEBUG - 2013-09-01 02:34:24 --> Loader Class Initialized
DEBUG - 2013-09-01 02:34:24 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:34:24 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:34:24 --> Controller Class Initialized
DEBUG - 2013-09-01 02:34:24 --> Controller Class Initialized
DEBUG - 2013-09-01 02:34:24 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:34:24 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:34:24 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:34:24 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:34:24 --> Model Class Initialized
DEBUG - 2013-09-01 02:34:24 --> Model Class Initialized
DEBUG - 2013-09-01 02:34:24 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:34:24 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:34:24 --> Model Class Initialized
DEBUG - 2013-09-01 02:34:24 --> Model Class Initialized
DEBUG - 2013-09-01 02:34:24 --> Model Class Initialized
DEBUG - 2013-09-01 02:34:24 --> Model Class Initialized
DEBUG - 2013-09-01 02:34:24 --> XSS Filtering completed
DEBUG - 2013-09-01 02:34:24 --> XSS Filtering completed
DEBUG - 2013-09-01 02:34:24 --> XSS Filtering completed
DEBUG - 2013-09-01 02:34:24 --> XSS Filtering completed
DEBUG - 2013-09-01 02:34:24 --> XSS Filtering completed
ERROR - 2013-09-01 02:34:24 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 181
ERROR - 2013-09-01 02:34:24 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 186
ERROR - 2013-09-01 02:34:24 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 186
ERROR - 2013-09-01 02:34:24 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 191
DEBUG - 2013-09-01 02:34:25 --> Config Class Initialized
DEBUG - 2013-09-01 02:34:25 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:34:25 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:34:25 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:34:25 --> URI Class Initialized
DEBUG - 2013-09-01 02:34:25 --> Router Class Initialized
DEBUG - 2013-09-01 02:34:25 --> Output Class Initialized
DEBUG - 2013-09-01 02:34:25 --> Security Class Initialized
DEBUG - 2013-09-01 02:34:25 --> Input Class Initialized
DEBUG - 2013-09-01 02:34:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:34:25 --> Language Class Initialized
DEBUG - 2013-09-01 02:34:25 --> Loader Class Initialized
DEBUG - 2013-09-01 02:34:25 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:34:25 --> Controller Class Initialized
DEBUG - 2013-09-01 02:34:25 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:34:25 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:34:25 --> Model Class Initialized
DEBUG - 2013-09-01 02:34:25 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:34:25 --> Model Class Initialized
DEBUG - 2013-09-01 02:34:25 --> Model Class Initialized
DEBUG - 2013-09-01 02:34:25 --> XSS Filtering completed
DEBUG - 2013-09-01 02:34:25 --> Config Class Initialized
DEBUG - 2013-09-01 02:34:25 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:34:25 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:34:25 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:34:25 --> URI Class Initialized
DEBUG - 2013-09-01 02:34:25 --> Config Class Initialized
DEBUG - 2013-09-01 02:34:25 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:34:25 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:34:25 --> Router Class Initialized
DEBUG - 2013-09-01 02:34:25 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:34:25 --> URI Class Initialized
DEBUG - 2013-09-01 02:34:25 --> Output Class Initialized
DEBUG - 2013-09-01 02:34:25 --> Router Class Initialized
DEBUG - 2013-09-01 02:34:25 --> Security Class Initialized
DEBUG - 2013-09-01 02:34:25 --> Input Class Initialized
DEBUG - 2013-09-01 02:34:25 --> Output Class Initialized
DEBUG - 2013-09-01 02:34:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:34:25 --> Language Class Initialized
DEBUG - 2013-09-01 02:34:25 --> Security Class Initialized
DEBUG - 2013-09-01 02:34:25 --> Input Class Initialized
DEBUG - 2013-09-01 02:34:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:34:25 --> Language Class Initialized
DEBUG - 2013-09-01 02:34:25 --> Loader Class Initialized
DEBUG - 2013-09-01 02:34:25 --> Loader Class Initialized
DEBUG - 2013-09-01 02:34:25 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:34:25 --> Controller Class Initialized
DEBUG - 2013-09-01 02:34:25 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:34:25 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:34:25 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:34:25 --> Controller Class Initialized
DEBUG - 2013-09-01 02:34:25 --> Model Class Initialized
DEBUG - 2013-09-01 02:34:25 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:34:25 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:34:25 --> Model Class Initialized
DEBUG - 2013-09-01 02:34:25 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:34:25 --> Model Class Initialized
DEBUG - 2013-09-01 02:34:25 --> Model Class Initialized
DEBUG - 2013-09-01 02:34:25 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:34:25 --> Model Class Initialized
DEBUG - 2013-09-01 02:34:25 --> XSS Filtering completed
DEBUG - 2013-09-01 02:34:25 --> XSS Filtering completed
DEBUG - 2013-09-01 02:34:25 --> XSS Filtering completed
DEBUG - 2013-09-01 02:34:25 --> Model Class Initialized
DEBUG - 2013-09-01 02:34:25 --> XSS Filtering completed
DEBUG - 2013-09-01 02:34:25 --> XSS Filtering completed
ERROR - 2013-09-01 02:34:25 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 181
ERROR - 2013-09-01 02:34:25 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 186
ERROR - 2013-09-01 02:34:25 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 186
ERROR - 2013-09-01 02:34:25 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 191
DEBUG - 2013-09-01 02:34:26 --> Config Class Initialized
DEBUG - 2013-09-01 02:34:26 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:34:26 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:34:26 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:34:26 --> URI Class Initialized
DEBUG - 2013-09-01 02:34:26 --> Router Class Initialized
DEBUG - 2013-09-01 02:34:26 --> Output Class Initialized
DEBUG - 2013-09-01 02:34:26 --> Security Class Initialized
DEBUG - 2013-09-01 02:34:26 --> Input Class Initialized
DEBUG - 2013-09-01 02:34:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:34:26 --> Language Class Initialized
DEBUG - 2013-09-01 02:34:26 --> Loader Class Initialized
DEBUG - 2013-09-01 02:34:26 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:34:26 --> Controller Class Initialized
DEBUG - 2013-09-01 02:34:26 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:34:26 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:34:26 --> Model Class Initialized
DEBUG - 2013-09-01 02:34:26 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:34:26 --> Model Class Initialized
DEBUG - 2013-09-01 02:34:26 --> Model Class Initialized
DEBUG - 2013-09-01 02:34:26 --> XSS Filtering completed
DEBUG - 2013-09-01 02:34:26 --> Config Class Initialized
DEBUG - 2013-09-01 02:34:26 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:34:26 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:34:26 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:34:26 --> Config Class Initialized
DEBUG - 2013-09-01 02:34:26 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:34:26 --> URI Class Initialized
DEBUG - 2013-09-01 02:34:26 --> Router Class Initialized
DEBUG - 2013-09-01 02:34:26 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:34:26 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:34:26 --> URI Class Initialized
DEBUG - 2013-09-01 02:34:26 --> Output Class Initialized
DEBUG - 2013-09-01 02:34:26 --> Router Class Initialized
DEBUG - 2013-09-01 02:34:26 --> Security Class Initialized
DEBUG - 2013-09-01 02:34:26 --> Input Class Initialized
DEBUG - 2013-09-01 02:34:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:34:26 --> Output Class Initialized
DEBUG - 2013-09-01 02:34:26 --> Language Class Initialized
DEBUG - 2013-09-01 02:34:26 --> Security Class Initialized
DEBUG - 2013-09-01 02:34:26 --> Input Class Initialized
DEBUG - 2013-09-01 02:34:26 --> Loader Class Initialized
DEBUG - 2013-09-01 02:34:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:34:26 --> Language Class Initialized
DEBUG - 2013-09-01 02:34:26 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:34:26 --> Controller Class Initialized
DEBUG - 2013-09-01 02:34:26 --> Loader Class Initialized
DEBUG - 2013-09-01 02:34:26 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:34:26 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:34:26 --> Model Class Initialized
DEBUG - 2013-09-01 02:34:26 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:34:26 --> Model Class Initialized
DEBUG - 2013-09-01 02:34:26 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:34:26 --> Controller Class Initialized
DEBUG - 2013-09-01 02:34:26 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:34:26 --> Model Class Initialized
DEBUG - 2013-09-01 02:34:26 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:34:26 --> XSS Filtering completed
DEBUG - 2013-09-01 02:34:26 --> XSS Filtering completed
DEBUG - 2013-09-01 02:34:26 --> Model Class Initialized
DEBUG - 2013-09-01 02:34:26 --> XSS Filtering completed
DEBUG - 2013-09-01 02:34:26 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:34:26 --> Model Class Initialized
DEBUG - 2013-09-01 02:34:26 --> Model Class Initialized
DEBUG - 2013-09-01 02:34:26 --> XSS Filtering completed
DEBUG - 2013-09-01 02:34:26 --> XSS Filtering completed
ERROR - 2013-09-01 02:34:26 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 181
ERROR - 2013-09-01 02:34:26 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 186
ERROR - 2013-09-01 02:34:26 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 186
ERROR - 2013-09-01 02:34:26 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 191
DEBUG - 2013-09-01 02:41:23 --> Config Class Initialized
DEBUG - 2013-09-01 02:41:23 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:41:23 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:41:23 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:41:23 --> URI Class Initialized
DEBUG - 2013-09-01 02:41:23 --> Router Class Initialized
DEBUG - 2013-09-01 02:41:23 --> Output Class Initialized
DEBUG - 2013-09-01 02:41:23 --> Security Class Initialized
DEBUG - 2013-09-01 02:41:23 --> Input Class Initialized
DEBUG - 2013-09-01 02:41:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:41:23 --> Language Class Initialized
DEBUG - 2013-09-01 02:41:23 --> Loader Class Initialized
DEBUG - 2013-09-01 02:41:23 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:41:23 --> Controller Class Initialized
DEBUG - 2013-09-01 02:41:23 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:41:23 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:41:23 --> Model Class Initialized
DEBUG - 2013-09-01 02:41:23 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:41:23 --> Model Class Initialized
DEBUG - 2013-09-01 02:41:23 --> Model Class Initialized
DEBUG - 2013-09-01 02:45:59 --> Config Class Initialized
DEBUG - 2013-09-01 02:45:59 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:45:59 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:45:59 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:45:59 --> URI Class Initialized
DEBUG - 2013-09-01 02:45:59 --> Router Class Initialized
DEBUG - 2013-09-01 02:45:59 --> Output Class Initialized
DEBUG - 2013-09-01 02:45:59 --> Security Class Initialized
DEBUG - 2013-09-01 02:45:59 --> Input Class Initialized
DEBUG - 2013-09-01 02:45:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:45:59 --> Language Class Initialized
DEBUG - 2013-09-01 02:45:59 --> Loader Class Initialized
DEBUG - 2013-09-01 02:45:59 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:45:59 --> Controller Class Initialized
DEBUG - 2013-09-01 02:45:59 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:45:59 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:45:59 --> Model Class Initialized
DEBUG - 2013-09-01 02:45:59 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:45:59 --> Model Class Initialized
DEBUG - 2013-09-01 02:45:59 --> Model Class Initialized
DEBUG - 2013-09-01 02:48:16 --> Config Class Initialized
DEBUG - 2013-09-01 02:48:16 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:48:16 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:48:16 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:48:16 --> URI Class Initialized
DEBUG - 2013-09-01 02:48:17 --> Router Class Initialized
DEBUG - 2013-09-01 02:48:17 --> Output Class Initialized
DEBUG - 2013-09-01 02:48:17 --> Security Class Initialized
DEBUG - 2013-09-01 02:48:17 --> Input Class Initialized
DEBUG - 2013-09-01 02:48:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:48:17 --> Language Class Initialized
DEBUG - 2013-09-01 02:48:17 --> Loader Class Initialized
DEBUG - 2013-09-01 02:48:17 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:48:17 --> Controller Class Initialized
DEBUG - 2013-09-01 02:48:17 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:48:17 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:48:17 --> Model Class Initialized
DEBUG - 2013-09-01 02:48:17 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:48:17 --> Model Class Initialized
DEBUG - 2013-09-01 02:48:17 --> Model Class Initialized
DEBUG - 2013-09-01 02:49:02 --> Config Class Initialized
DEBUG - 2013-09-01 02:49:02 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:49:02 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:49:02 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:49:02 --> URI Class Initialized
DEBUG - 2013-09-01 02:49:02 --> Router Class Initialized
DEBUG - 2013-09-01 02:49:02 --> Output Class Initialized
DEBUG - 2013-09-01 02:49:02 --> Security Class Initialized
DEBUG - 2013-09-01 02:49:02 --> Input Class Initialized
DEBUG - 2013-09-01 02:49:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:49:02 --> Language Class Initialized
DEBUG - 2013-09-01 02:49:02 --> Loader Class Initialized
DEBUG - 2013-09-01 02:49:02 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:49:02 --> Controller Class Initialized
DEBUG - 2013-09-01 02:49:02 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:49:02 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:49:02 --> Model Class Initialized
DEBUG - 2013-09-01 02:49:02 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:49:02 --> Model Class Initialized
DEBUG - 2013-09-01 02:49:02 --> Model Class Initialized
DEBUG - 2013-09-01 02:49:15 --> Config Class Initialized
DEBUG - 2013-09-01 02:49:15 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:49:15 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:49:15 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:49:15 --> URI Class Initialized
DEBUG - 2013-09-01 02:49:15 --> Router Class Initialized
DEBUG - 2013-09-01 02:49:15 --> Output Class Initialized
DEBUG - 2013-09-01 02:49:15 --> Security Class Initialized
DEBUG - 2013-09-01 02:49:15 --> Input Class Initialized
DEBUG - 2013-09-01 02:49:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:49:15 --> Language Class Initialized
DEBUG - 2013-09-01 02:49:15 --> Loader Class Initialized
DEBUG - 2013-09-01 02:49:15 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:49:15 --> Controller Class Initialized
DEBUG - 2013-09-01 02:49:15 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:49:15 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:49:15 --> Model Class Initialized
DEBUG - 2013-09-01 02:49:15 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:49:15 --> Model Class Initialized
DEBUG - 2013-09-01 02:49:15 --> Model Class Initialized
DEBUG - 2013-09-01 02:53:56 --> Config Class Initialized
DEBUG - 2013-09-01 02:53:56 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:53:56 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:53:56 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:53:56 --> URI Class Initialized
DEBUG - 2013-09-01 02:53:56 --> Router Class Initialized
DEBUG - 2013-09-01 02:53:56 --> Output Class Initialized
DEBUG - 2013-09-01 02:53:56 --> Security Class Initialized
DEBUG - 2013-09-01 02:53:56 --> Input Class Initialized
DEBUG - 2013-09-01 02:53:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:53:56 --> Language Class Initialized
DEBUG - 2013-09-01 02:53:56 --> Loader Class Initialized
DEBUG - 2013-09-01 02:53:56 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:53:56 --> Controller Class Initialized
DEBUG - 2013-09-01 02:53:56 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:53:56 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:53:56 --> Model Class Initialized
DEBUG - 2013-09-01 02:53:56 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:53:56 --> Model Class Initialized
DEBUG - 2013-09-01 02:53:56 --> Model Class Initialized
DEBUG - 2013-09-01 02:58:02 --> Config Class Initialized
DEBUG - 2013-09-01 02:58:02 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:58:02 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:58:02 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:58:02 --> URI Class Initialized
DEBUG - 2013-09-01 02:58:02 --> Router Class Initialized
DEBUG - 2013-09-01 02:58:02 --> Output Class Initialized
DEBUG - 2013-09-01 02:58:02 --> Security Class Initialized
DEBUG - 2013-09-01 02:58:02 --> Input Class Initialized
DEBUG - 2013-09-01 02:58:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:58:02 --> Language Class Initialized
DEBUG - 2013-09-01 02:58:02 --> Loader Class Initialized
DEBUG - 2013-09-01 02:58:02 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:58:02 --> Controller Class Initialized
DEBUG - 2013-09-01 02:58:02 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:58:02 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:58:02 --> Model Class Initialized
DEBUG - 2013-09-01 02:58:02 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:58:02 --> Model Class Initialized
DEBUG - 2013-09-01 02:58:02 --> Model Class Initialized
DEBUG - 2013-09-01 02:58:02 --> XSS Filtering completed
DEBUG - 2013-09-01 02:58:02 --> XSS Filtering completed
DEBUG - 2013-09-01 02:58:02 --> XSS Filtering completed
DEBUG - 2013-09-01 02:58:02 --> XSS Filtering completed
DEBUG - 2013-09-01 02:58:02 --> XSS Filtering completed
DEBUG - 2013-09-01 02:59:00 --> Config Class Initialized
DEBUG - 2013-09-01 02:59:00 --> Hooks Class Initialized
DEBUG - 2013-09-01 02:59:00 --> Utf8 Class Initialized
DEBUG - 2013-09-01 02:59:00 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 02:59:00 --> URI Class Initialized
DEBUG - 2013-09-01 02:59:00 --> Router Class Initialized
DEBUG - 2013-09-01 02:59:00 --> No URI present. Default controller set.
DEBUG - 2013-09-01 02:59:00 --> Output Class Initialized
DEBUG - 2013-09-01 02:59:00 --> Security Class Initialized
DEBUG - 2013-09-01 02:59:00 --> Input Class Initialized
DEBUG - 2013-09-01 02:59:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 02:59:00 --> Language Class Initialized
DEBUG - 2013-09-01 02:59:00 --> Loader Class Initialized
DEBUG - 2013-09-01 02:59:00 --> Database Driver Class Initialized
DEBUG - 2013-09-01 02:59:00 --> Controller Class Initialized
DEBUG - 2013-09-01 02:59:00 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 02:59:00 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 02:59:00 --> Model Class Initialized
DEBUG - 2013-09-01 02:59:00 --> Helper loaded: date_helper
DEBUG - 2013-09-01 02:59:00 --> Model Class Initialized
DEBUG - 2013-09-01 02:59:00 --> File loaded: application/views/index.php
DEBUG - 2013-09-01 02:59:00 --> Final output sent to browser
DEBUG - 2013-09-01 02:59:00 --> Total execution time: 0.0330
DEBUG - 2013-09-01 03:13:17 --> Config Class Initialized
DEBUG - 2013-09-01 03:13:17 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:13:17 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:13:17 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:13:17 --> URI Class Initialized
DEBUG - 2013-09-01 03:13:17 --> Router Class Initialized
DEBUG - 2013-09-01 03:13:17 --> No URI present. Default controller set.
DEBUG - 2013-09-01 03:13:17 --> Output Class Initialized
DEBUG - 2013-09-01 03:13:17 --> Security Class Initialized
DEBUG - 2013-09-01 03:13:17 --> Input Class Initialized
DEBUG - 2013-09-01 03:13:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:13:17 --> Language Class Initialized
DEBUG - 2013-09-01 03:13:17 --> Loader Class Initialized
DEBUG - 2013-09-01 03:13:17 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:13:17 --> Controller Class Initialized
DEBUG - 2013-09-01 03:13:17 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:13:17 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:13:17 --> Model Class Initialized
DEBUG - 2013-09-01 03:13:17 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:13:17 --> Model Class Initialized
DEBUG - 2013-09-01 03:13:17 --> File loaded: application/views/index.php
DEBUG - 2013-09-01 03:13:17 --> Final output sent to browser
DEBUG - 2013-09-01 03:13:17 --> Total execution time: 0.0380
DEBUG - 2013-09-01 03:13:58 --> Config Class Initialized
DEBUG - 2013-09-01 03:13:58 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:13:58 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:13:58 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:13:58 --> URI Class Initialized
DEBUG - 2013-09-01 03:13:58 --> Router Class Initialized
DEBUG - 2013-09-01 03:13:58 --> Output Class Initialized
DEBUG - 2013-09-01 03:13:58 --> Security Class Initialized
DEBUG - 2013-09-01 03:13:58 --> Input Class Initialized
DEBUG - 2013-09-01 03:13:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:13:58 --> Language Class Initialized
DEBUG - 2013-09-01 03:13:58 --> Loader Class Initialized
DEBUG - 2013-09-01 03:13:58 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:13:58 --> Controller Class Initialized
DEBUG - 2013-09-01 03:13:58 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:13:58 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:13:58 --> Model Class Initialized
DEBUG - 2013-09-01 03:13:58 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:13:58 --> Model Class Initialized
DEBUG - 2013-09-01 03:13:58 --> Model Class Initialized
DEBUG - 2013-09-01 03:13:58 --> XSS Filtering completed
DEBUG - 2013-09-01 03:13:58 --> XSS Filtering completed
DEBUG - 2013-09-01 03:13:58 --> XSS Filtering completed
DEBUG - 2013-09-01 03:13:58 --> XSS Filtering completed
DEBUG - 2013-09-01 03:13:58 --> XSS Filtering completed
DEBUG - 2013-09-01 03:14:02 --> Config Class Initialized
DEBUG - 2013-09-01 03:14:02 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:14:02 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:14:02 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:14:02 --> URI Class Initialized
DEBUG - 2013-09-01 03:14:02 --> Router Class Initialized
DEBUG - 2013-09-01 03:14:02 --> Output Class Initialized
DEBUG - 2013-09-01 03:14:02 --> Security Class Initialized
DEBUG - 2013-09-01 03:14:02 --> Input Class Initialized
DEBUG - 2013-09-01 03:14:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:14:02 --> Language Class Initialized
DEBUG - 2013-09-01 03:14:02 --> Loader Class Initialized
DEBUG - 2013-09-01 03:14:02 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:14:02 --> Controller Class Initialized
DEBUG - 2013-09-01 03:14:02 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:14:02 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:14:02 --> Model Class Initialized
DEBUG - 2013-09-01 03:14:02 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:14:02 --> Model Class Initialized
DEBUG - 2013-09-01 03:14:02 --> Model Class Initialized
DEBUG - 2013-09-01 03:14:02 --> XSS Filtering completed
DEBUG - 2013-09-01 03:14:04 --> Config Class Initialized
DEBUG - 2013-09-01 03:14:04 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:14:04 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:14:04 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:14:04 --> URI Class Initialized
DEBUG - 2013-09-01 03:14:04 --> Router Class Initialized
DEBUG - 2013-09-01 03:14:04 --> Output Class Initialized
DEBUG - 2013-09-01 03:14:04 --> Security Class Initialized
DEBUG - 2013-09-01 03:14:04 --> Input Class Initialized
DEBUG - 2013-09-01 03:14:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:14:04 --> Language Class Initialized
DEBUG - 2013-09-01 03:14:04 --> Loader Class Initialized
DEBUG - 2013-09-01 03:14:04 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:14:04 --> Controller Class Initialized
DEBUG - 2013-09-01 03:14:04 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:14:04 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:14:04 --> Model Class Initialized
DEBUG - 2013-09-01 03:14:04 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:14:04 --> Model Class Initialized
DEBUG - 2013-09-01 03:14:04 --> Model Class Initialized
DEBUG - 2013-09-01 03:14:04 --> XSS Filtering completed
DEBUG - 2013-09-01 03:14:04 --> XSS Filtering completed
DEBUG - 2013-09-01 03:14:04 --> Config Class Initialized
DEBUG - 2013-09-01 03:14:04 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:14:04 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:14:04 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:14:04 --> URI Class Initialized
DEBUG - 2013-09-01 03:14:04 --> Router Class Initialized
DEBUG - 2013-09-01 03:14:04 --> Output Class Initialized
DEBUG - 2013-09-01 03:14:04 --> Security Class Initialized
DEBUG - 2013-09-01 03:14:04 --> Input Class Initialized
DEBUG - 2013-09-01 03:14:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:14:04 --> Language Class Initialized
DEBUG - 2013-09-01 03:14:04 --> Loader Class Initialized
DEBUG - 2013-09-01 03:14:04 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:14:04 --> Controller Class Initialized
DEBUG - 2013-09-01 03:14:04 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:14:04 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:14:04 --> Model Class Initialized
DEBUG - 2013-09-01 03:14:04 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:14:04 --> Model Class Initialized
DEBUG - 2013-09-01 03:14:04 --> Model Class Initialized
DEBUG - 2013-09-01 03:14:04 --> XSS Filtering completed
DEBUG - 2013-09-01 03:14:04 --> XSS Filtering completed
DEBUG - 2013-09-01 03:14:05 --> Config Class Initialized
DEBUG - 2013-09-01 03:14:05 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:14:05 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:14:05 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:14:05 --> URI Class Initialized
DEBUG - 2013-09-01 03:14:05 --> Router Class Initialized
DEBUG - 2013-09-01 03:14:05 --> Output Class Initialized
DEBUG - 2013-09-01 03:14:05 --> Security Class Initialized
DEBUG - 2013-09-01 03:14:05 --> Input Class Initialized
DEBUG - 2013-09-01 03:14:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:14:05 --> Language Class Initialized
DEBUG - 2013-09-01 03:14:05 --> Loader Class Initialized
DEBUG - 2013-09-01 03:14:05 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:14:05 --> Controller Class Initialized
DEBUG - 2013-09-01 03:14:05 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:14:05 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:14:05 --> Model Class Initialized
DEBUG - 2013-09-01 03:14:05 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:14:05 --> Model Class Initialized
DEBUG - 2013-09-01 03:14:05 --> Model Class Initialized
DEBUG - 2013-09-01 03:14:05 --> XSS Filtering completed
DEBUG - 2013-09-01 03:14:05 --> XSS Filtering completed
DEBUG - 2013-09-01 03:14:05 --> Config Class Initialized
DEBUG - 2013-09-01 03:14:05 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:14:05 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:14:05 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:14:05 --> URI Class Initialized
DEBUG - 2013-09-01 03:14:05 --> Router Class Initialized
DEBUG - 2013-09-01 03:14:05 --> Output Class Initialized
DEBUG - 2013-09-01 03:14:05 --> Security Class Initialized
DEBUG - 2013-09-01 03:14:05 --> Input Class Initialized
DEBUG - 2013-09-01 03:14:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:14:05 --> Language Class Initialized
DEBUG - 2013-09-01 03:14:05 --> Loader Class Initialized
DEBUG - 2013-09-01 03:14:05 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:14:05 --> Controller Class Initialized
DEBUG - 2013-09-01 03:14:05 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:14:05 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:14:05 --> Model Class Initialized
DEBUG - 2013-09-01 03:14:05 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:14:05 --> Model Class Initialized
DEBUG - 2013-09-01 03:14:05 --> Model Class Initialized
DEBUG - 2013-09-01 03:14:05 --> XSS Filtering completed
DEBUG - 2013-09-01 03:14:05 --> XSS Filtering completed
DEBUG - 2013-09-01 03:14:06 --> Config Class Initialized
DEBUG - 2013-09-01 03:14:06 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:14:06 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:14:06 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:14:06 --> URI Class Initialized
DEBUG - 2013-09-01 03:14:06 --> Router Class Initialized
DEBUG - 2013-09-01 03:14:06 --> Output Class Initialized
DEBUG - 2013-09-01 03:14:06 --> Security Class Initialized
DEBUG - 2013-09-01 03:14:06 --> Input Class Initialized
DEBUG - 2013-09-01 03:14:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:14:06 --> Language Class Initialized
DEBUG - 2013-09-01 03:14:06 --> Loader Class Initialized
DEBUG - 2013-09-01 03:14:06 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:14:06 --> Controller Class Initialized
DEBUG - 2013-09-01 03:14:06 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:14:06 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:14:06 --> Model Class Initialized
DEBUG - 2013-09-01 03:14:06 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:14:06 --> Model Class Initialized
DEBUG - 2013-09-01 03:14:06 --> Model Class Initialized
DEBUG - 2013-09-01 03:14:06 --> XSS Filtering completed
DEBUG - 2013-09-01 03:14:06 --> XSS Filtering completed
DEBUG - 2013-09-01 03:14:10 --> Config Class Initialized
DEBUG - 2013-09-01 03:14:10 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:14:10 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:14:10 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:14:10 --> URI Class Initialized
DEBUG - 2013-09-01 03:14:10 --> Router Class Initialized
DEBUG - 2013-09-01 03:14:10 --> Output Class Initialized
DEBUG - 2013-09-01 03:14:10 --> Security Class Initialized
DEBUG - 2013-09-01 03:14:10 --> Input Class Initialized
DEBUG - 2013-09-01 03:14:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:14:10 --> Language Class Initialized
DEBUG - 2013-09-01 03:14:10 --> Loader Class Initialized
DEBUG - 2013-09-01 03:14:10 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:14:10 --> Controller Class Initialized
DEBUG - 2013-09-01 03:14:10 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:14:10 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:14:10 --> Model Class Initialized
DEBUG - 2013-09-01 03:14:10 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:14:10 --> Model Class Initialized
DEBUG - 2013-09-01 03:14:10 --> Model Class Initialized
DEBUG - 2013-09-01 03:14:10 --> XSS Filtering completed
DEBUG - 2013-09-01 03:14:10 --> XSS Filtering completed
DEBUG - 2013-09-01 03:14:10 --> Config Class Initialized
DEBUG - 2013-09-01 03:14:10 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:14:10 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:14:10 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:14:10 --> URI Class Initialized
DEBUG - 2013-09-01 03:14:10 --> Router Class Initialized
DEBUG - 2013-09-01 03:14:10 --> Output Class Initialized
DEBUG - 2013-09-01 03:14:10 --> Security Class Initialized
DEBUG - 2013-09-01 03:14:10 --> Input Class Initialized
DEBUG - 2013-09-01 03:14:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:14:10 --> Language Class Initialized
DEBUG - 2013-09-01 03:14:10 --> Loader Class Initialized
DEBUG - 2013-09-01 03:14:10 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:14:10 --> Controller Class Initialized
DEBUG - 2013-09-01 03:14:10 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:14:10 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:14:10 --> Model Class Initialized
DEBUG - 2013-09-01 03:14:10 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:14:10 --> Model Class Initialized
DEBUG - 2013-09-01 03:14:10 --> Model Class Initialized
DEBUG - 2013-09-01 03:14:10 --> XSS Filtering completed
DEBUG - 2013-09-01 03:14:10 --> XSS Filtering completed
DEBUG - 2013-09-01 03:14:11 --> Config Class Initialized
DEBUG - 2013-09-01 03:14:11 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:14:11 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:14:11 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:14:11 --> URI Class Initialized
DEBUG - 2013-09-01 03:14:11 --> Router Class Initialized
DEBUG - 2013-09-01 03:14:11 --> Output Class Initialized
DEBUG - 2013-09-01 03:14:11 --> Security Class Initialized
DEBUG - 2013-09-01 03:14:11 --> Input Class Initialized
DEBUG - 2013-09-01 03:14:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:14:11 --> Language Class Initialized
DEBUG - 2013-09-01 03:14:11 --> Loader Class Initialized
DEBUG - 2013-09-01 03:14:11 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:14:11 --> Controller Class Initialized
DEBUG - 2013-09-01 03:14:11 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:14:11 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:14:11 --> Model Class Initialized
DEBUG - 2013-09-01 03:14:11 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:14:11 --> Model Class Initialized
DEBUG - 2013-09-01 03:14:11 --> Model Class Initialized
DEBUG - 2013-09-01 03:14:11 --> XSS Filtering completed
DEBUG - 2013-09-01 03:14:11 --> XSS Filtering completed
DEBUG - 2013-09-01 03:14:11 --> Config Class Initialized
DEBUG - 2013-09-01 03:14:11 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:14:11 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:14:11 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:14:11 --> URI Class Initialized
DEBUG - 2013-09-01 03:14:11 --> Router Class Initialized
DEBUG - 2013-09-01 03:14:11 --> Output Class Initialized
DEBUG - 2013-09-01 03:14:11 --> Security Class Initialized
DEBUG - 2013-09-01 03:14:11 --> Input Class Initialized
DEBUG - 2013-09-01 03:14:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:14:11 --> Language Class Initialized
DEBUG - 2013-09-01 03:14:11 --> Loader Class Initialized
DEBUG - 2013-09-01 03:14:11 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:14:11 --> Controller Class Initialized
DEBUG - 2013-09-01 03:14:11 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:14:11 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:14:11 --> Model Class Initialized
DEBUG - 2013-09-01 03:14:11 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:14:11 --> Model Class Initialized
DEBUG - 2013-09-01 03:14:11 --> Model Class Initialized
DEBUG - 2013-09-01 03:14:11 --> XSS Filtering completed
DEBUG - 2013-09-01 03:14:11 --> XSS Filtering completed
DEBUG - 2013-09-01 03:14:12 --> Config Class Initialized
DEBUG - 2013-09-01 03:14:12 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:14:12 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:14:12 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:14:12 --> URI Class Initialized
DEBUG - 2013-09-01 03:14:12 --> Router Class Initialized
DEBUG - 2013-09-01 03:14:12 --> Output Class Initialized
DEBUG - 2013-09-01 03:14:12 --> Security Class Initialized
DEBUG - 2013-09-01 03:14:12 --> Input Class Initialized
DEBUG - 2013-09-01 03:14:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:14:12 --> Language Class Initialized
DEBUG - 2013-09-01 03:14:12 --> Loader Class Initialized
DEBUG - 2013-09-01 03:14:12 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:14:12 --> Controller Class Initialized
DEBUG - 2013-09-01 03:14:12 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:14:12 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:14:12 --> Model Class Initialized
DEBUG - 2013-09-01 03:14:12 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:14:12 --> Model Class Initialized
DEBUG - 2013-09-01 03:14:12 --> Model Class Initialized
DEBUG - 2013-09-01 03:14:12 --> XSS Filtering completed
DEBUG - 2013-09-01 03:14:12 --> XSS Filtering completed
DEBUG - 2013-09-01 03:14:12 --> Config Class Initialized
DEBUG - 2013-09-01 03:14:12 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:14:12 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:14:12 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:14:12 --> URI Class Initialized
DEBUG - 2013-09-01 03:14:12 --> Router Class Initialized
DEBUG - 2013-09-01 03:14:12 --> Output Class Initialized
DEBUG - 2013-09-01 03:14:12 --> Security Class Initialized
DEBUG - 2013-09-01 03:14:12 --> Input Class Initialized
DEBUG - 2013-09-01 03:14:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:14:12 --> Language Class Initialized
DEBUG - 2013-09-01 03:14:12 --> Loader Class Initialized
DEBUG - 2013-09-01 03:14:13 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:14:13 --> Controller Class Initialized
DEBUG - 2013-09-01 03:14:13 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:14:13 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:14:13 --> Model Class Initialized
DEBUG - 2013-09-01 03:14:13 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:14:13 --> Model Class Initialized
DEBUG - 2013-09-01 03:14:13 --> Model Class Initialized
DEBUG - 2013-09-01 03:14:13 --> XSS Filtering completed
DEBUG - 2013-09-01 03:14:13 --> XSS Filtering completed
DEBUG - 2013-09-01 03:14:13 --> Config Class Initialized
DEBUG - 2013-09-01 03:14:13 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:14:13 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:14:13 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:14:13 --> URI Class Initialized
DEBUG - 2013-09-01 03:14:13 --> Router Class Initialized
DEBUG - 2013-09-01 03:14:13 --> Output Class Initialized
DEBUG - 2013-09-01 03:14:13 --> Security Class Initialized
DEBUG - 2013-09-01 03:14:13 --> Input Class Initialized
DEBUG - 2013-09-01 03:14:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:14:13 --> Language Class Initialized
DEBUG - 2013-09-01 03:14:13 --> Loader Class Initialized
DEBUG - 2013-09-01 03:14:13 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:14:13 --> Controller Class Initialized
DEBUG - 2013-09-01 03:14:13 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:14:13 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:14:13 --> Model Class Initialized
DEBUG - 2013-09-01 03:14:13 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:14:13 --> Model Class Initialized
DEBUG - 2013-09-01 03:14:13 --> Model Class Initialized
DEBUG - 2013-09-01 03:14:13 --> XSS Filtering completed
DEBUG - 2013-09-01 03:14:13 --> XSS Filtering completed
DEBUG - 2013-09-01 03:14:14 --> Config Class Initialized
DEBUG - 2013-09-01 03:14:14 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:14:14 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:14:14 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:14:14 --> URI Class Initialized
DEBUG - 2013-09-01 03:14:14 --> Router Class Initialized
DEBUG - 2013-09-01 03:14:14 --> Output Class Initialized
DEBUG - 2013-09-01 03:14:14 --> Security Class Initialized
DEBUG - 2013-09-01 03:14:14 --> Input Class Initialized
DEBUG - 2013-09-01 03:14:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:14:14 --> Language Class Initialized
DEBUG - 2013-09-01 03:14:14 --> Loader Class Initialized
DEBUG - 2013-09-01 03:14:14 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:14:14 --> Controller Class Initialized
DEBUG - 2013-09-01 03:14:14 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:14:14 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:14:14 --> Model Class Initialized
DEBUG - 2013-09-01 03:14:14 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:14:14 --> Model Class Initialized
DEBUG - 2013-09-01 03:14:14 --> Model Class Initialized
DEBUG - 2013-09-01 03:14:14 --> XSS Filtering completed
DEBUG - 2013-09-01 03:14:14 --> XSS Filtering completed
DEBUG - 2013-09-01 03:21:10 --> Config Class Initialized
DEBUG - 2013-09-01 03:21:10 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:21:10 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:21:10 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:21:10 --> URI Class Initialized
DEBUG - 2013-09-01 03:21:10 --> Router Class Initialized
ERROR - 2013-09-01 03:21:10 --> 404 Page Not Found --> files
DEBUG - 2013-09-01 03:21:15 --> Config Class Initialized
DEBUG - 2013-09-01 03:21:15 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:21:15 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:21:15 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:21:15 --> URI Class Initialized
DEBUG - 2013-09-01 03:21:15 --> Router Class Initialized
DEBUG - 2013-09-01 03:21:15 --> Output Class Initialized
DEBUG - 2013-09-01 03:21:15 --> Security Class Initialized
DEBUG - 2013-09-01 03:21:15 --> Input Class Initialized
DEBUG - 2013-09-01 03:21:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:21:15 --> Language Class Initialized
DEBUG - 2013-09-01 03:21:15 --> Loader Class Initialized
DEBUG - 2013-09-01 03:21:15 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:21:15 --> Controller Class Initialized
DEBUG - 2013-09-01 03:21:15 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:21:15 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:21:15 --> Model Class Initialized
DEBUG - 2013-09-01 03:21:15 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:21:15 --> Model Class Initialized
DEBUG - 2013-09-01 03:21:15 --> Model Class Initialized
DEBUG - 2013-09-01 03:21:15 --> XSS Filtering completed
DEBUG - 2013-09-01 03:21:15 --> XSS Filtering completed
DEBUG - 2013-09-01 03:21:15 --> XSS Filtering completed
DEBUG - 2013-09-01 03:21:15 --> XSS Filtering completed
DEBUG - 2013-09-01 03:21:15 --> XSS Filtering completed
DEBUG - 2013-09-01 03:21:21 --> Config Class Initialized
DEBUG - 2013-09-01 03:21:21 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:21:21 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:21:21 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:21:21 --> URI Class Initialized
DEBUG - 2013-09-01 03:21:21 --> Router Class Initialized
DEBUG - 2013-09-01 03:21:21 --> Output Class Initialized
DEBUG - 2013-09-01 03:21:21 --> Security Class Initialized
DEBUG - 2013-09-01 03:21:21 --> Input Class Initialized
DEBUG - 2013-09-01 03:21:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:21:21 --> Language Class Initialized
DEBUG - 2013-09-01 03:21:21 --> Loader Class Initialized
DEBUG - 2013-09-01 03:21:21 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:21:21 --> Controller Class Initialized
DEBUG - 2013-09-01 03:21:21 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:21:21 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:21:21 --> Model Class Initialized
DEBUG - 2013-09-01 03:21:21 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:21:21 --> Model Class Initialized
DEBUG - 2013-09-01 03:21:21 --> Model Class Initialized
DEBUG - 2013-09-01 03:21:21 --> XSS Filtering completed
DEBUG - 2013-09-01 03:21:21 --> XSS Filtering completed
DEBUG - 2013-09-01 03:21:21 --> Config Class Initialized
DEBUG - 2013-09-01 03:21:21 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:21:21 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:21:21 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:21:21 --> URI Class Initialized
DEBUG - 2013-09-01 03:21:21 --> Router Class Initialized
DEBUG - 2013-09-01 03:21:21 --> Output Class Initialized
DEBUG - 2013-09-01 03:21:21 --> Security Class Initialized
DEBUG - 2013-09-01 03:21:21 --> Input Class Initialized
DEBUG - 2013-09-01 03:21:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:21:21 --> Language Class Initialized
DEBUG - 2013-09-01 03:21:21 --> Loader Class Initialized
DEBUG - 2013-09-01 03:21:21 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:21:21 --> Controller Class Initialized
DEBUG - 2013-09-01 03:21:21 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:21:21 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:21:21 --> Model Class Initialized
DEBUG - 2013-09-01 03:21:21 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:21:21 --> Model Class Initialized
DEBUG - 2013-09-01 03:21:21 --> Model Class Initialized
DEBUG - 2013-09-01 03:21:21 --> XSS Filtering completed
DEBUG - 2013-09-01 03:21:21 --> XSS Filtering completed
DEBUG - 2013-09-01 03:21:21 --> Config Class Initialized
DEBUG - 2013-09-01 03:21:21 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:21:21 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:21:21 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:21:21 --> URI Class Initialized
DEBUG - 2013-09-01 03:21:21 --> Router Class Initialized
DEBUG - 2013-09-01 03:21:21 --> Output Class Initialized
DEBUG - 2013-09-01 03:21:21 --> Security Class Initialized
DEBUG - 2013-09-01 03:21:21 --> Input Class Initialized
DEBUG - 2013-09-01 03:21:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:21:21 --> Language Class Initialized
DEBUG - 2013-09-01 03:21:21 --> Loader Class Initialized
DEBUG - 2013-09-01 03:21:21 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:21:21 --> Controller Class Initialized
DEBUG - 2013-09-01 03:21:21 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:21:21 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:21:21 --> Model Class Initialized
DEBUG - 2013-09-01 03:21:21 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:21:21 --> Model Class Initialized
DEBUG - 2013-09-01 03:21:21 --> Model Class Initialized
DEBUG - 2013-09-01 03:21:21 --> XSS Filtering completed
DEBUG - 2013-09-01 03:21:21 --> XSS Filtering completed
DEBUG - 2013-09-01 03:21:21 --> Config Class Initialized
DEBUG - 2013-09-01 03:21:21 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:21:21 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:21:21 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:21:21 --> URI Class Initialized
DEBUG - 2013-09-01 03:21:21 --> Router Class Initialized
DEBUG - 2013-09-01 03:21:22 --> Output Class Initialized
DEBUG - 2013-09-01 03:21:22 --> Security Class Initialized
DEBUG - 2013-09-01 03:21:22 --> Input Class Initialized
DEBUG - 2013-09-01 03:21:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:21:22 --> Language Class Initialized
DEBUG - 2013-09-01 03:21:22 --> Loader Class Initialized
DEBUG - 2013-09-01 03:21:22 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:21:22 --> Controller Class Initialized
DEBUG - 2013-09-01 03:21:22 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:21:22 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:21:22 --> Model Class Initialized
DEBUG - 2013-09-01 03:21:22 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:21:22 --> Model Class Initialized
DEBUG - 2013-09-01 03:21:22 --> Model Class Initialized
DEBUG - 2013-09-01 03:21:22 --> XSS Filtering completed
DEBUG - 2013-09-01 03:21:22 --> XSS Filtering completed
DEBUG - 2013-09-01 03:27:06 --> Config Class Initialized
DEBUG - 2013-09-01 03:27:06 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:27:06 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:27:06 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:27:06 --> URI Class Initialized
DEBUG - 2013-09-01 03:27:06 --> Router Class Initialized
DEBUG - 2013-09-01 03:27:06 --> Output Class Initialized
DEBUG - 2013-09-01 03:27:06 --> Security Class Initialized
DEBUG - 2013-09-01 03:27:06 --> Input Class Initialized
DEBUG - 2013-09-01 03:27:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:27:06 --> Language Class Initialized
DEBUG - 2013-09-01 03:27:06 --> Loader Class Initialized
DEBUG - 2013-09-01 03:27:06 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:27:06 --> Controller Class Initialized
DEBUG - 2013-09-01 03:27:06 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:27:06 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:27:06 --> Model Class Initialized
DEBUG - 2013-09-01 03:27:06 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:27:06 --> Model Class Initialized
DEBUG - 2013-09-01 03:27:06 --> Model Class Initialized
DEBUG - 2013-09-01 03:27:06 --> XSS Filtering completed
DEBUG - 2013-09-01 03:27:06 --> XSS Filtering completed
DEBUG - 2013-09-01 03:27:06 --> XSS Filtering completed
DEBUG - 2013-09-01 03:27:06 --> XSS Filtering completed
DEBUG - 2013-09-01 03:27:06 --> XSS Filtering completed
DEBUG - 2013-09-01 03:27:06 --> XSS Filtering completed
DEBUG - 2013-09-01 03:27:10 --> Config Class Initialized
DEBUG - 2013-09-01 03:27:10 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:27:10 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:27:10 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:27:10 --> URI Class Initialized
DEBUG - 2013-09-01 03:27:10 --> Router Class Initialized
DEBUG - 2013-09-01 03:27:10 --> Output Class Initialized
DEBUG - 2013-09-01 03:27:10 --> Security Class Initialized
DEBUG - 2013-09-01 03:27:10 --> Input Class Initialized
DEBUG - 2013-09-01 03:27:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:27:10 --> Language Class Initialized
DEBUG - 2013-09-01 03:27:10 --> Loader Class Initialized
DEBUG - 2013-09-01 03:27:10 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:27:10 --> Controller Class Initialized
DEBUG - 2013-09-01 03:27:10 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:27:10 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:27:10 --> Model Class Initialized
DEBUG - 2013-09-01 03:27:10 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:27:10 --> Model Class Initialized
DEBUG - 2013-09-01 03:27:10 --> Model Class Initialized
DEBUG - 2013-09-01 03:27:10 --> XSS Filtering completed
DEBUG - 2013-09-01 03:27:10 --> XSS Filtering completed
DEBUG - 2013-09-01 03:27:10 --> Config Class Initialized
DEBUG - 2013-09-01 03:27:10 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:27:10 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:27:10 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:27:10 --> URI Class Initialized
DEBUG - 2013-09-01 03:27:10 --> Router Class Initialized
DEBUG - 2013-09-01 03:27:10 --> Output Class Initialized
DEBUG - 2013-09-01 03:27:10 --> Security Class Initialized
DEBUG - 2013-09-01 03:27:10 --> Input Class Initialized
DEBUG - 2013-09-01 03:27:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:27:10 --> Language Class Initialized
DEBUG - 2013-09-01 03:27:10 --> Loader Class Initialized
DEBUG - 2013-09-01 03:27:10 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:27:10 --> Controller Class Initialized
DEBUG - 2013-09-01 03:27:10 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:27:10 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:27:10 --> Model Class Initialized
DEBUG - 2013-09-01 03:27:10 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:27:10 --> Model Class Initialized
DEBUG - 2013-09-01 03:27:10 --> Model Class Initialized
DEBUG - 2013-09-01 03:27:10 --> XSS Filtering completed
DEBUG - 2013-09-01 03:27:10 --> XSS Filtering completed
DEBUG - 2013-09-01 03:27:10 --> Config Class Initialized
DEBUG - 2013-09-01 03:27:10 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:27:10 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:27:10 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:27:10 --> URI Class Initialized
DEBUG - 2013-09-01 03:27:10 --> Router Class Initialized
DEBUG - 2013-09-01 03:27:10 --> Output Class Initialized
DEBUG - 2013-09-01 03:27:10 --> Security Class Initialized
DEBUG - 2013-09-01 03:27:10 --> Input Class Initialized
DEBUG - 2013-09-01 03:27:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:27:10 --> Language Class Initialized
DEBUG - 2013-09-01 03:27:10 --> Loader Class Initialized
DEBUG - 2013-09-01 03:27:10 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:27:10 --> Controller Class Initialized
DEBUG - 2013-09-01 03:27:10 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:27:10 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:27:10 --> Model Class Initialized
DEBUG - 2013-09-01 03:27:10 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:27:10 --> Model Class Initialized
DEBUG - 2013-09-01 03:27:10 --> Model Class Initialized
DEBUG - 2013-09-01 03:27:10 --> XSS Filtering completed
DEBUG - 2013-09-01 03:27:10 --> XSS Filtering completed
DEBUG - 2013-09-01 03:27:12 --> Config Class Initialized
DEBUG - 2013-09-01 03:27:12 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:27:12 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:27:12 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:27:12 --> URI Class Initialized
DEBUG - 2013-09-01 03:27:12 --> Router Class Initialized
DEBUG - 2013-09-01 03:27:12 --> Output Class Initialized
DEBUG - 2013-09-01 03:27:12 --> Security Class Initialized
DEBUG - 2013-09-01 03:27:12 --> Input Class Initialized
DEBUG - 2013-09-01 03:27:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:27:12 --> Language Class Initialized
DEBUG - 2013-09-01 03:27:12 --> Loader Class Initialized
DEBUG - 2013-09-01 03:27:12 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:27:12 --> Controller Class Initialized
DEBUG - 2013-09-01 03:27:12 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:27:12 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:27:12 --> Model Class Initialized
DEBUG - 2013-09-01 03:27:12 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:27:12 --> Model Class Initialized
DEBUG - 2013-09-01 03:27:12 --> Model Class Initialized
DEBUG - 2013-09-01 03:27:12 --> XSS Filtering completed
DEBUG - 2013-09-01 03:27:12 --> XSS Filtering completed
DEBUG - 2013-09-01 03:27:13 --> Config Class Initialized
DEBUG - 2013-09-01 03:27:13 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:27:13 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:27:13 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:27:13 --> URI Class Initialized
DEBUG - 2013-09-01 03:27:13 --> Router Class Initialized
DEBUG - 2013-09-01 03:27:13 --> Output Class Initialized
DEBUG - 2013-09-01 03:27:13 --> Security Class Initialized
DEBUG - 2013-09-01 03:27:13 --> Input Class Initialized
DEBUG - 2013-09-01 03:27:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:27:13 --> Language Class Initialized
DEBUG - 2013-09-01 03:27:13 --> Loader Class Initialized
DEBUG - 2013-09-01 03:27:13 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:27:13 --> Controller Class Initialized
DEBUG - 2013-09-01 03:27:13 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:27:13 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:27:13 --> Model Class Initialized
DEBUG - 2013-09-01 03:27:13 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:27:13 --> Model Class Initialized
DEBUG - 2013-09-01 03:27:13 --> Model Class Initialized
DEBUG - 2013-09-01 03:27:13 --> XSS Filtering completed
DEBUG - 2013-09-01 03:27:13 --> XSS Filtering completed
DEBUG - 2013-09-01 03:27:13 --> Config Class Initialized
DEBUG - 2013-09-01 03:27:13 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:27:13 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:27:13 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:27:13 --> URI Class Initialized
DEBUG - 2013-09-01 03:27:13 --> Router Class Initialized
DEBUG - 2013-09-01 03:27:13 --> Output Class Initialized
DEBUG - 2013-09-01 03:27:13 --> Security Class Initialized
DEBUG - 2013-09-01 03:27:13 --> Input Class Initialized
DEBUG - 2013-09-01 03:27:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:27:13 --> Language Class Initialized
DEBUG - 2013-09-01 03:27:13 --> Loader Class Initialized
DEBUG - 2013-09-01 03:27:13 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:27:13 --> Controller Class Initialized
DEBUG - 2013-09-01 03:27:13 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:27:13 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:27:13 --> Model Class Initialized
DEBUG - 2013-09-01 03:27:13 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:27:13 --> Model Class Initialized
DEBUG - 2013-09-01 03:27:13 --> Model Class Initialized
DEBUG - 2013-09-01 03:27:13 --> XSS Filtering completed
DEBUG - 2013-09-01 03:27:13 --> XSS Filtering completed
DEBUG - 2013-09-01 03:27:19 --> Config Class Initialized
DEBUG - 2013-09-01 03:27:19 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:27:19 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:27:19 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:27:19 --> URI Class Initialized
DEBUG - 2013-09-01 03:27:19 --> Router Class Initialized
DEBUG - 2013-09-01 03:27:19 --> Output Class Initialized
DEBUG - 2013-09-01 03:27:19 --> Security Class Initialized
DEBUG - 2013-09-01 03:27:19 --> Input Class Initialized
DEBUG - 2013-09-01 03:27:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:27:19 --> Language Class Initialized
DEBUG - 2013-09-01 03:27:19 --> Loader Class Initialized
DEBUG - 2013-09-01 03:27:19 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:27:19 --> Controller Class Initialized
DEBUG - 2013-09-01 03:27:19 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:27:19 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:27:19 --> Model Class Initialized
DEBUG - 2013-09-01 03:27:19 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:27:19 --> Model Class Initialized
DEBUG - 2013-09-01 03:27:19 --> Model Class Initialized
DEBUG - 2013-09-01 03:27:19 --> XSS Filtering completed
DEBUG - 2013-09-01 03:27:19 --> XSS Filtering completed
DEBUG - 2013-09-01 03:29:34 --> Config Class Initialized
DEBUG - 2013-09-01 03:29:34 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:29:34 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:29:34 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:29:34 --> URI Class Initialized
DEBUG - 2013-09-01 03:29:34 --> Router Class Initialized
DEBUG - 2013-09-01 03:29:34 --> Output Class Initialized
DEBUG - 2013-09-01 03:29:34 --> Security Class Initialized
DEBUG - 2013-09-01 03:29:34 --> Input Class Initialized
DEBUG - 2013-09-01 03:29:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:29:34 --> Language Class Initialized
DEBUG - 2013-09-01 03:29:34 --> Loader Class Initialized
DEBUG - 2013-09-01 03:29:34 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:29:34 --> Controller Class Initialized
DEBUG - 2013-09-01 03:29:34 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:29:34 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:29:34 --> Model Class Initialized
DEBUG - 2013-09-01 03:29:34 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:29:34 --> Model Class Initialized
DEBUG - 2013-09-01 03:29:34 --> Model Class Initialized
DEBUG - 2013-09-01 03:29:34 --> XSS Filtering completed
DEBUG - 2013-09-01 03:29:34 --> XSS Filtering completed
DEBUG - 2013-09-01 03:36:34 --> Config Class Initialized
DEBUG - 2013-09-01 03:36:34 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:36:34 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:36:34 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:36:34 --> URI Class Initialized
DEBUG - 2013-09-01 03:36:34 --> Router Class Initialized
DEBUG - 2013-09-01 03:36:35 --> Output Class Initialized
DEBUG - 2013-09-01 03:36:35 --> Security Class Initialized
DEBUG - 2013-09-01 03:36:35 --> Input Class Initialized
DEBUG - 2013-09-01 03:36:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:36:35 --> Language Class Initialized
DEBUG - 2013-09-01 03:36:35 --> Loader Class Initialized
DEBUG - 2013-09-01 03:36:35 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:36:35 --> Controller Class Initialized
DEBUG - 2013-09-01 03:36:35 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:36:35 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:36:35 --> Model Class Initialized
DEBUG - 2013-09-01 03:36:35 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:36:35 --> Model Class Initialized
DEBUG - 2013-09-01 03:36:35 --> Model Class Initialized
DEBUG - 2013-09-01 03:37:28 --> Config Class Initialized
DEBUG - 2013-09-01 03:37:28 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:37:28 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:37:28 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:37:28 --> URI Class Initialized
DEBUG - 2013-09-01 03:37:28 --> Router Class Initialized
DEBUG - 2013-09-01 03:37:28 --> Output Class Initialized
DEBUG - 2013-09-01 03:37:28 --> Security Class Initialized
DEBUG - 2013-09-01 03:37:28 --> Input Class Initialized
DEBUG - 2013-09-01 03:37:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:37:28 --> Language Class Initialized
DEBUG - 2013-09-01 03:37:28 --> Loader Class Initialized
DEBUG - 2013-09-01 03:37:28 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:37:28 --> Controller Class Initialized
DEBUG - 2013-09-01 03:37:28 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:37:28 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:37:28 --> Model Class Initialized
DEBUG - 2013-09-01 03:37:28 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:37:28 --> Model Class Initialized
DEBUG - 2013-09-01 03:37:28 --> File loaded: application/views/admin.php
DEBUG - 2013-09-01 03:37:28 --> Final output sent to browser
DEBUG - 2013-09-01 03:37:28 --> Total execution time: 0.0330
DEBUG - 2013-09-01 03:37:38 --> Config Class Initialized
DEBUG - 2013-09-01 03:37:38 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:37:38 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:37:38 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:37:38 --> URI Class Initialized
DEBUG - 2013-09-01 03:37:38 --> Router Class Initialized
DEBUG - 2013-09-01 03:37:38 --> Output Class Initialized
DEBUG - 2013-09-01 03:37:38 --> Security Class Initialized
DEBUG - 2013-09-01 03:37:38 --> Input Class Initialized
DEBUG - 2013-09-01 03:37:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:37:38 --> Language Class Initialized
DEBUG - 2013-09-01 03:37:38 --> Loader Class Initialized
DEBUG - 2013-09-01 03:37:38 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:37:38 --> Controller Class Initialized
DEBUG - 2013-09-01 03:37:38 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:37:38 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:37:38 --> Model Class Initialized
DEBUG - 2013-09-01 03:37:38 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:37:38 --> Model Class Initialized
DEBUG - 2013-09-01 03:37:38 --> File loaded: application/views/admin.php
DEBUG - 2013-09-01 03:37:38 --> Final output sent to browser
DEBUG - 2013-09-01 03:37:38 --> Total execution time: 0.0370
DEBUG - 2013-09-01 03:37:59 --> Config Class Initialized
DEBUG - 2013-09-01 03:37:59 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:37:59 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:37:59 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:37:59 --> URI Class Initialized
DEBUG - 2013-09-01 03:37:59 --> Router Class Initialized
DEBUG - 2013-09-01 03:37:59 --> Output Class Initialized
DEBUG - 2013-09-01 03:37:59 --> Security Class Initialized
DEBUG - 2013-09-01 03:37:59 --> Input Class Initialized
DEBUG - 2013-09-01 03:37:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:37:59 --> Language Class Initialized
DEBUG - 2013-09-01 03:37:59 --> Loader Class Initialized
DEBUG - 2013-09-01 03:37:59 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:37:59 --> Controller Class Initialized
DEBUG - 2013-09-01 03:37:59 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:37:59 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:37:59 --> Model Class Initialized
DEBUG - 2013-09-01 03:37:59 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:37:59 --> Model Class Initialized
DEBUG - 2013-09-01 03:37:59 --> File loaded: application/views/admin.php
DEBUG - 2013-09-01 03:37:59 --> Final output sent to browser
DEBUG - 2013-09-01 03:37:59 --> Total execution time: 0.0330
DEBUG - 2013-09-01 03:38:03 --> Config Class Initialized
DEBUG - 2013-09-01 03:38:03 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:38:03 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:38:03 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:38:03 --> URI Class Initialized
DEBUG - 2013-09-01 03:38:03 --> Router Class Initialized
DEBUG - 2013-09-01 03:38:03 --> Output Class Initialized
DEBUG - 2013-09-01 03:38:03 --> Security Class Initialized
DEBUG - 2013-09-01 03:38:03 --> Input Class Initialized
DEBUG - 2013-09-01 03:38:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:38:03 --> Language Class Initialized
DEBUG - 2013-09-01 03:38:03 --> Loader Class Initialized
DEBUG - 2013-09-01 03:38:03 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:38:03 --> Controller Class Initialized
DEBUG - 2013-09-01 03:38:03 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:38:03 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:38:03 --> Model Class Initialized
DEBUG - 2013-09-01 03:38:03 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:38:03 --> Model Class Initialized
DEBUG - 2013-09-01 03:38:03 --> File loaded: application/views/admin.php
DEBUG - 2013-09-01 03:38:03 --> Final output sent to browser
DEBUG - 2013-09-01 03:38:03 --> Total execution time: 0.0340
DEBUG - 2013-09-01 03:38:09 --> Config Class Initialized
DEBUG - 2013-09-01 03:38:09 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:38:09 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:38:09 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:38:09 --> URI Class Initialized
DEBUG - 2013-09-01 03:38:09 --> Router Class Initialized
DEBUG - 2013-09-01 03:38:09 --> Output Class Initialized
DEBUG - 2013-09-01 03:38:09 --> Security Class Initialized
DEBUG - 2013-09-01 03:38:09 --> Input Class Initialized
DEBUG - 2013-09-01 03:38:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:38:09 --> Language Class Initialized
DEBUG - 2013-09-01 03:38:09 --> Loader Class Initialized
DEBUG - 2013-09-01 03:38:09 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:38:09 --> Controller Class Initialized
DEBUG - 2013-09-01 03:38:09 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:38:09 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:38:09 --> Model Class Initialized
DEBUG - 2013-09-01 03:38:09 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:38:09 --> Model Class Initialized
DEBUG - 2013-09-01 03:38:09 --> File loaded: application/views/admin.php
DEBUG - 2013-09-01 03:38:09 --> Final output sent to browser
DEBUG - 2013-09-01 03:38:09 --> Total execution time: 0.0340
DEBUG - 2013-09-01 03:38:28 --> Config Class Initialized
DEBUG - 2013-09-01 03:38:28 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:38:28 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:38:28 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:38:28 --> URI Class Initialized
DEBUG - 2013-09-01 03:38:28 --> Router Class Initialized
DEBUG - 2013-09-01 03:38:28 --> Output Class Initialized
DEBUG - 2013-09-01 03:38:28 --> Security Class Initialized
DEBUG - 2013-09-01 03:38:28 --> Input Class Initialized
DEBUG - 2013-09-01 03:38:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:38:28 --> Language Class Initialized
DEBUG - 2013-09-01 03:38:28 --> Loader Class Initialized
DEBUG - 2013-09-01 03:38:28 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:38:28 --> Controller Class Initialized
DEBUG - 2013-09-01 03:38:28 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:38:28 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:38:28 --> Model Class Initialized
DEBUG - 2013-09-01 03:38:28 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:38:28 --> Model Class Initialized
DEBUG - 2013-09-01 03:38:28 --> File loaded: application/views/admin.php
DEBUG - 2013-09-01 03:38:28 --> Final output sent to browser
DEBUG - 2013-09-01 03:38:28 --> Total execution time: 0.0340
DEBUG - 2013-09-01 03:38:38 --> Config Class Initialized
DEBUG - 2013-09-01 03:38:38 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:38:38 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:38:38 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:38:38 --> URI Class Initialized
DEBUG - 2013-09-01 03:38:38 --> Router Class Initialized
DEBUG - 2013-09-01 03:38:38 --> Output Class Initialized
DEBUG - 2013-09-01 03:38:38 --> Security Class Initialized
DEBUG - 2013-09-01 03:38:38 --> Input Class Initialized
DEBUG - 2013-09-01 03:38:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:38:38 --> Language Class Initialized
DEBUG - 2013-09-01 03:38:38 --> Loader Class Initialized
DEBUG - 2013-09-01 03:38:38 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:38:38 --> Controller Class Initialized
DEBUG - 2013-09-01 03:38:38 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:38:38 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:38:38 --> Model Class Initialized
DEBUG - 2013-09-01 03:38:38 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:38:38 --> Model Class Initialized
DEBUG - 2013-09-01 03:38:38 --> File loaded: application/views/admin.php
DEBUG - 2013-09-01 03:38:38 --> Final output sent to browser
DEBUG - 2013-09-01 03:38:38 --> Total execution time: 0.0330
DEBUG - 2013-09-01 03:38:44 --> Config Class Initialized
DEBUG - 2013-09-01 03:38:44 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:38:44 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:38:44 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:38:44 --> URI Class Initialized
DEBUG - 2013-09-01 03:38:44 --> Router Class Initialized
DEBUG - 2013-09-01 03:38:44 --> Output Class Initialized
DEBUG - 2013-09-01 03:38:44 --> Security Class Initialized
DEBUG - 2013-09-01 03:38:44 --> Input Class Initialized
DEBUG - 2013-09-01 03:38:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:38:44 --> Language Class Initialized
DEBUG - 2013-09-01 03:38:44 --> Loader Class Initialized
DEBUG - 2013-09-01 03:38:44 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:38:44 --> Controller Class Initialized
DEBUG - 2013-09-01 03:38:44 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:38:44 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:38:44 --> Model Class Initialized
DEBUG - 2013-09-01 03:38:44 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:38:44 --> Model Class Initialized
DEBUG - 2013-09-01 03:38:44 --> Model Class Initialized
DEBUG - 2013-09-01 03:38:44 --> XSS Filtering completed
DEBUG - 2013-09-01 03:38:44 --> XSS Filtering completed
DEBUG - 2013-09-01 03:38:44 --> Config Class Initialized
DEBUG - 2013-09-01 03:38:44 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:38:44 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:38:44 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:38:44 --> URI Class Initialized
DEBUG - 2013-09-01 03:38:44 --> Router Class Initialized
DEBUG - 2013-09-01 03:38:44 --> Output Class Initialized
DEBUG - 2013-09-01 03:38:44 --> Security Class Initialized
DEBUG - 2013-09-01 03:38:44 --> Input Class Initialized
DEBUG - 2013-09-01 03:38:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:38:44 --> Language Class Initialized
DEBUG - 2013-09-01 03:38:44 --> Loader Class Initialized
DEBUG - 2013-09-01 03:38:44 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:38:44 --> Controller Class Initialized
DEBUG - 2013-09-01 03:38:44 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:38:44 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:38:44 --> Model Class Initialized
DEBUG - 2013-09-01 03:38:44 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:38:44 --> Model Class Initialized
DEBUG - 2013-09-01 03:38:44 --> Model Class Initialized
DEBUG - 2013-09-01 03:38:44 --> XSS Filtering completed
DEBUG - 2013-09-01 03:38:51 --> Config Class Initialized
DEBUG - 2013-09-01 03:38:51 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:38:51 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:38:51 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:38:51 --> URI Class Initialized
DEBUG - 2013-09-01 03:38:51 --> Router Class Initialized
DEBUG - 2013-09-01 03:38:51 --> Output Class Initialized
DEBUG - 2013-09-01 03:38:51 --> Security Class Initialized
DEBUG - 2013-09-01 03:38:51 --> Input Class Initialized
DEBUG - 2013-09-01 03:38:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:38:51 --> Language Class Initialized
DEBUG - 2013-09-01 03:38:51 --> Loader Class Initialized
DEBUG - 2013-09-01 03:38:51 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:38:51 --> Controller Class Initialized
DEBUG - 2013-09-01 03:38:51 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:38:51 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:38:51 --> Model Class Initialized
DEBUG - 2013-09-01 03:38:51 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:38:51 --> Model Class Initialized
DEBUG - 2013-09-01 03:38:51 --> Model Class Initialized
DEBUG - 2013-09-01 03:39:03 --> Config Class Initialized
DEBUG - 2013-09-01 03:39:03 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:39:03 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:39:03 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:39:03 --> URI Class Initialized
DEBUG - 2013-09-01 03:39:03 --> Router Class Initialized
DEBUG - 2013-09-01 03:39:03 --> Output Class Initialized
DEBUG - 2013-09-01 03:39:03 --> Security Class Initialized
DEBUG - 2013-09-01 03:39:03 --> Input Class Initialized
DEBUG - 2013-09-01 03:39:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:39:03 --> Language Class Initialized
DEBUG - 2013-09-01 03:39:03 --> Loader Class Initialized
DEBUG - 2013-09-01 03:39:03 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:39:03 --> Controller Class Initialized
DEBUG - 2013-09-01 03:39:03 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:39:03 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:39:03 --> Model Class Initialized
DEBUG - 2013-09-01 03:39:03 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:39:03 --> Model Class Initialized
DEBUG - 2013-09-01 03:39:03 --> File loaded: application/views/admin.php
DEBUG - 2013-09-01 03:39:03 --> Final output sent to browser
DEBUG - 2013-09-01 03:39:03 --> Total execution time: 0.0340
DEBUG - 2013-09-01 03:39:07 --> Config Class Initialized
DEBUG - 2013-09-01 03:39:07 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:39:07 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:39:07 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:39:07 --> URI Class Initialized
DEBUG - 2013-09-01 03:39:07 --> Router Class Initialized
DEBUG - 2013-09-01 03:39:07 --> Output Class Initialized
DEBUG - 2013-09-01 03:39:07 --> Security Class Initialized
DEBUG - 2013-09-01 03:39:07 --> Input Class Initialized
DEBUG - 2013-09-01 03:39:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:39:07 --> Language Class Initialized
DEBUG - 2013-09-01 03:39:07 --> Loader Class Initialized
DEBUG - 2013-09-01 03:39:07 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:39:07 --> Controller Class Initialized
DEBUG - 2013-09-01 03:39:07 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:39:07 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:39:07 --> Model Class Initialized
DEBUG - 2013-09-01 03:39:07 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:39:07 --> Model Class Initialized
DEBUG - 2013-09-01 03:39:07 --> Model Class Initialized
DEBUG - 2013-09-01 03:39:07 --> XSS Filtering completed
DEBUG - 2013-09-01 03:39:07 --> XSS Filtering completed
DEBUG - 2013-09-01 03:39:07 --> Config Class Initialized
DEBUG - 2013-09-01 03:39:07 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:39:07 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:39:07 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:39:07 --> URI Class Initialized
DEBUG - 2013-09-01 03:39:07 --> Router Class Initialized
DEBUG - 2013-09-01 03:39:07 --> Output Class Initialized
DEBUG - 2013-09-01 03:39:07 --> Security Class Initialized
DEBUG - 2013-09-01 03:39:07 --> Input Class Initialized
DEBUG - 2013-09-01 03:39:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:39:07 --> Language Class Initialized
DEBUG - 2013-09-01 03:39:07 --> Loader Class Initialized
DEBUG - 2013-09-01 03:39:07 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:39:07 --> Controller Class Initialized
DEBUG - 2013-09-01 03:39:07 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:39:07 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:39:07 --> Model Class Initialized
DEBUG - 2013-09-01 03:39:07 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:39:07 --> Model Class Initialized
DEBUG - 2013-09-01 03:39:07 --> Model Class Initialized
DEBUG - 2013-09-01 03:39:07 --> XSS Filtering completed
DEBUG - 2013-09-01 03:39:12 --> Config Class Initialized
DEBUG - 2013-09-01 03:39:12 --> Config Class Initialized
DEBUG - 2013-09-01 03:39:12 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:39:12 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:39:12 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:39:12 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:39:12 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:39:12 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:39:12 --> URI Class Initialized
DEBUG - 2013-09-01 03:39:12 --> URI Class Initialized
DEBUG - 2013-09-01 03:39:12 --> Router Class Initialized
DEBUG - 2013-09-01 03:39:12 --> Router Class Initialized
DEBUG - 2013-09-01 03:39:12 --> Output Class Initialized
DEBUG - 2013-09-01 03:39:12 --> Output Class Initialized
DEBUG - 2013-09-01 03:39:12 --> Security Class Initialized
DEBUG - 2013-09-01 03:39:12 --> Security Class Initialized
DEBUG - 2013-09-01 03:39:12 --> Input Class Initialized
DEBUG - 2013-09-01 03:39:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:39:12 --> Language Class Initialized
DEBUG - 2013-09-01 03:39:12 --> Input Class Initialized
DEBUG - 2013-09-01 03:39:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:39:12 --> Language Class Initialized
DEBUG - 2013-09-01 03:39:12 --> Loader Class Initialized
DEBUG - 2013-09-01 03:39:12 --> Loader Class Initialized
DEBUG - 2013-09-01 03:39:12 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:39:12 --> Controller Class Initialized
DEBUG - 2013-09-01 03:39:12 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:39:12 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:39:12 --> Controller Class Initialized
DEBUG - 2013-09-01 03:39:12 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:39:12 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:39:12 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:39:12 --> Model Class Initialized
DEBUG - 2013-09-01 03:39:12 --> Model Class Initialized
DEBUG - 2013-09-01 03:39:12 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:39:12 --> Model Class Initialized
DEBUG - 2013-09-01 03:39:12 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:39:12 --> Model Class Initialized
DEBUG - 2013-09-01 03:39:12 --> Model Class Initialized
DEBUG - 2013-09-01 03:39:12 --> Model Class Initialized
DEBUG - 2013-09-01 03:39:12 --> XSS Filtering completed
DEBUG - 2013-09-01 03:39:12 --> XSS Filtering completed
DEBUG - 2013-09-01 03:39:12 --> XSS Filtering completed
DEBUG - 2013-09-01 03:39:12 --> XSS Filtering completed
DEBUG - 2013-09-01 03:39:12 --> XSS Filtering completed
ERROR - 2013-09-01 03:39:12 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 185
ERROR - 2013-09-01 03:39:12 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-01 03:39:12 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-01 03:39:12 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 195
DEBUG - 2013-09-01 03:39:12 --> Config Class Initialized
DEBUG - 2013-09-01 03:39:12 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:39:12 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:39:12 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:39:12 --> URI Class Initialized
DEBUG - 2013-09-01 03:39:12 --> Router Class Initialized
DEBUG - 2013-09-01 03:39:12 --> Output Class Initialized
DEBUG - 2013-09-01 03:39:12 --> Security Class Initialized
DEBUG - 2013-09-01 03:39:12 --> Input Class Initialized
DEBUG - 2013-09-01 03:39:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:39:12 --> Language Class Initialized
DEBUG - 2013-09-01 03:39:12 --> Loader Class Initialized
DEBUG - 2013-09-01 03:39:12 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:39:12 --> Controller Class Initialized
DEBUG - 2013-09-01 03:39:12 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:39:12 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:39:12 --> Model Class Initialized
DEBUG - 2013-09-01 03:39:12 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:39:12 --> Model Class Initialized
DEBUG - 2013-09-01 03:39:12 --> Model Class Initialized
DEBUG - 2013-09-01 03:39:12 --> XSS Filtering completed
DEBUG - 2013-09-01 03:39:19 --> Config Class Initialized
DEBUG - 2013-09-01 03:39:19 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:39:19 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:39:19 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:39:19 --> URI Class Initialized
DEBUG - 2013-09-01 03:39:19 --> Router Class Initialized
DEBUG - 2013-09-01 03:39:19 --> Output Class Initialized
DEBUG - 2013-09-01 03:39:19 --> Security Class Initialized
DEBUG - 2013-09-01 03:39:19 --> Input Class Initialized
DEBUG - 2013-09-01 03:39:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:39:19 --> Language Class Initialized
DEBUG - 2013-09-01 03:39:19 --> Loader Class Initialized
DEBUG - 2013-09-01 03:39:19 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:39:19 --> Controller Class Initialized
DEBUG - 2013-09-01 03:39:19 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:39:19 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:39:19 --> Model Class Initialized
DEBUG - 2013-09-01 03:39:19 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:39:19 --> Model Class Initialized
DEBUG - 2013-09-01 03:39:19 --> Model Class Initialized
DEBUG - 2013-09-01 03:39:19 --> XSS Filtering completed
DEBUG - 2013-09-01 03:39:19 --> XSS Filtering completed
DEBUG - 2013-09-01 03:39:19 --> Config Class Initialized
DEBUG - 2013-09-01 03:39:19 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:39:19 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:39:19 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:39:19 --> URI Class Initialized
DEBUG - 2013-09-01 03:39:19 --> Router Class Initialized
DEBUG - 2013-09-01 03:39:19 --> Output Class Initialized
DEBUG - 2013-09-01 03:39:19 --> Security Class Initialized
DEBUG - 2013-09-01 03:39:19 --> Input Class Initialized
DEBUG - 2013-09-01 03:39:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:39:19 --> Language Class Initialized
DEBUG - 2013-09-01 03:39:19 --> Loader Class Initialized
DEBUG - 2013-09-01 03:39:19 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:39:19 --> Controller Class Initialized
DEBUG - 2013-09-01 03:39:19 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:39:19 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:39:19 --> Model Class Initialized
DEBUG - 2013-09-01 03:39:19 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:39:19 --> Model Class Initialized
DEBUG - 2013-09-01 03:39:19 --> File loaded: application/views/admin.php
DEBUG - 2013-09-01 03:39:19 --> Final output sent to browser
DEBUG - 2013-09-01 03:39:19 --> Total execution time: 0.0320
DEBUG - 2013-09-01 03:39:20 --> Config Class Initialized
DEBUG - 2013-09-01 03:39:20 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:39:20 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:39:20 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:39:20 --> URI Class Initialized
DEBUG - 2013-09-01 03:39:20 --> Router Class Initialized
DEBUG - 2013-09-01 03:39:20 --> Output Class Initialized
DEBUG - 2013-09-01 03:39:20 --> Security Class Initialized
DEBUG - 2013-09-01 03:39:20 --> Input Class Initialized
DEBUG - 2013-09-01 03:39:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:39:20 --> Language Class Initialized
DEBUG - 2013-09-01 03:39:20 --> Loader Class Initialized
DEBUG - 2013-09-01 03:39:20 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:39:20 --> Controller Class Initialized
DEBUG - 2013-09-01 03:39:20 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:39:20 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:39:20 --> Model Class Initialized
DEBUG - 2013-09-01 03:39:20 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:39:20 --> Model Class Initialized
DEBUG - 2013-09-01 03:39:20 --> Model Class Initialized
DEBUG - 2013-09-01 03:39:20 --> XSS Filtering completed
DEBUG - 2013-09-01 03:39:22 --> Config Class Initialized
DEBUG - 2013-09-01 03:39:22 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:39:22 --> Config Class Initialized
DEBUG - 2013-09-01 03:39:22 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:39:22 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:39:22 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:39:22 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:39:22 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:39:22 --> URI Class Initialized
DEBUG - 2013-09-01 03:39:22 --> URI Class Initialized
DEBUG - 2013-09-01 03:39:22 --> Router Class Initialized
DEBUG - 2013-09-01 03:39:22 --> Router Class Initialized
DEBUG - 2013-09-01 03:39:22 --> Output Class Initialized
DEBUG - 2013-09-01 03:39:22 --> Output Class Initialized
DEBUG - 2013-09-01 03:39:22 --> Security Class Initialized
DEBUG - 2013-09-01 03:39:22 --> Security Class Initialized
DEBUG - 2013-09-01 03:39:22 --> Input Class Initialized
DEBUG - 2013-09-01 03:39:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:39:22 --> Input Class Initialized
DEBUG - 2013-09-01 03:39:22 --> Language Class Initialized
DEBUG - 2013-09-01 03:39:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:39:22 --> Language Class Initialized
DEBUG - 2013-09-01 03:39:22 --> Loader Class Initialized
DEBUG - 2013-09-01 03:39:22 --> Loader Class Initialized
DEBUG - 2013-09-01 03:39:22 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:39:22 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:39:22 --> Controller Class Initialized
DEBUG - 2013-09-01 03:39:22 --> Controller Class Initialized
DEBUG - 2013-09-01 03:39:22 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:39:22 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:39:22 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:39:22 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:39:22 --> Model Class Initialized
DEBUG - 2013-09-01 03:39:22 --> Model Class Initialized
DEBUG - 2013-09-01 03:39:22 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:39:22 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:39:22 --> Model Class Initialized
DEBUG - 2013-09-01 03:39:22 --> Model Class Initialized
DEBUG - 2013-09-01 03:39:22 --> Model Class Initialized
DEBUG - 2013-09-01 03:39:22 --> Model Class Initialized
DEBUG - 2013-09-01 03:39:22 --> XSS Filtering completed
DEBUG - 2013-09-01 03:39:22 --> XSS Filtering completed
DEBUG - 2013-09-01 03:39:22 --> XSS Filtering completed
DEBUG - 2013-09-01 03:39:22 --> XSS Filtering completed
DEBUG - 2013-09-01 03:39:22 --> XSS Filtering completed
ERROR - 2013-09-01 03:39:22 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 185
ERROR - 2013-09-01 03:39:22 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-01 03:39:22 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-01 03:39:22 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 195
DEBUG - 2013-09-01 03:39:22 --> Config Class Initialized
DEBUG - 2013-09-01 03:39:22 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:39:22 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:39:22 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:39:22 --> URI Class Initialized
DEBUG - 2013-09-01 03:39:22 --> Router Class Initialized
DEBUG - 2013-09-01 03:39:22 --> Output Class Initialized
DEBUG - 2013-09-01 03:39:22 --> Security Class Initialized
DEBUG - 2013-09-01 03:39:22 --> Input Class Initialized
DEBUG - 2013-09-01 03:39:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:39:22 --> Language Class Initialized
DEBUG - 2013-09-01 03:39:22 --> Loader Class Initialized
DEBUG - 2013-09-01 03:39:22 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:39:22 --> Controller Class Initialized
DEBUG - 2013-09-01 03:39:22 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:39:22 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:39:22 --> Model Class Initialized
DEBUG - 2013-09-01 03:39:22 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:39:22 --> Model Class Initialized
DEBUG - 2013-09-01 03:39:22 --> Model Class Initialized
DEBUG - 2013-09-01 03:39:22 --> XSS Filtering completed
DEBUG - 2013-09-01 03:39:23 --> Config Class Initialized
DEBUG - 2013-09-01 03:39:23 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:39:23 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:39:23 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:39:23 --> Config Class Initialized
DEBUG - 2013-09-01 03:39:23 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:39:23 --> URI Class Initialized
DEBUG - 2013-09-01 03:39:23 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:39:23 --> Router Class Initialized
DEBUG - 2013-09-01 03:39:23 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:39:23 --> URI Class Initialized
DEBUG - 2013-09-01 03:39:23 --> Output Class Initialized
DEBUG - 2013-09-01 03:39:23 --> Router Class Initialized
DEBUG - 2013-09-01 03:39:23 --> Security Class Initialized
DEBUG - 2013-09-01 03:39:23 --> Output Class Initialized
DEBUG - 2013-09-01 03:39:23 --> Input Class Initialized
DEBUG - 2013-09-01 03:39:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:39:23 --> Security Class Initialized
DEBUG - 2013-09-01 03:39:23 --> Language Class Initialized
DEBUG - 2013-09-01 03:39:23 --> Input Class Initialized
DEBUG - 2013-09-01 03:39:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:39:23 --> Language Class Initialized
DEBUG - 2013-09-01 03:39:23 --> Loader Class Initialized
DEBUG - 2013-09-01 03:39:23 --> Loader Class Initialized
DEBUG - 2013-09-01 03:39:23 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:39:23 --> Controller Class Initialized
DEBUG - 2013-09-01 03:39:23 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:39:23 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:39:23 --> Controller Class Initialized
DEBUG - 2013-09-01 03:39:23 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:39:23 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:39:23 --> Model Class Initialized
DEBUG - 2013-09-01 03:39:23 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:39:23 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:39:23 --> Model Class Initialized
DEBUG - 2013-09-01 03:39:23 --> Model Class Initialized
DEBUG - 2013-09-01 03:39:23 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:39:23 --> Model Class Initialized
DEBUG - 2013-09-01 03:39:23 --> Model Class Initialized
DEBUG - 2013-09-01 03:39:23 --> XSS Filtering completed
DEBUG - 2013-09-01 03:39:23 --> Model Class Initialized
DEBUG - 2013-09-01 03:39:23 --> XSS Filtering completed
DEBUG - 2013-09-01 03:39:23 --> XSS Filtering completed
DEBUG - 2013-09-01 03:39:23 --> XSS Filtering completed
DEBUG - 2013-09-01 03:39:23 --> XSS Filtering completed
ERROR - 2013-09-01 03:39:23 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 185
ERROR - 2013-09-01 03:39:23 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-01 03:39:23 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-01 03:39:23 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 195
DEBUG - 2013-09-01 03:39:23 --> Config Class Initialized
DEBUG - 2013-09-01 03:39:23 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:39:23 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:39:23 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:39:23 --> URI Class Initialized
DEBUG - 2013-09-01 03:39:23 --> Router Class Initialized
DEBUG - 2013-09-01 03:39:23 --> Output Class Initialized
DEBUG - 2013-09-01 03:39:23 --> Security Class Initialized
DEBUG - 2013-09-01 03:39:23 --> Input Class Initialized
DEBUG - 2013-09-01 03:39:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:39:23 --> Language Class Initialized
DEBUG - 2013-09-01 03:39:23 --> Loader Class Initialized
DEBUG - 2013-09-01 03:39:23 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:39:23 --> Controller Class Initialized
DEBUG - 2013-09-01 03:39:23 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:39:23 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:39:23 --> Model Class Initialized
DEBUG - 2013-09-01 03:39:23 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:39:23 --> Model Class Initialized
DEBUG - 2013-09-01 03:39:23 --> Model Class Initialized
DEBUG - 2013-09-01 03:39:23 --> XSS Filtering completed
DEBUG - 2013-09-01 03:39:24 --> Config Class Initialized
DEBUG - 2013-09-01 03:39:24 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:39:24 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:39:24 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:39:24 --> Config Class Initialized
DEBUG - 2013-09-01 03:39:24 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:39:24 --> URI Class Initialized
DEBUG - 2013-09-01 03:39:24 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:39:24 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:39:24 --> Router Class Initialized
DEBUG - 2013-09-01 03:39:24 --> URI Class Initialized
DEBUG - 2013-09-01 03:39:24 --> Output Class Initialized
DEBUG - 2013-09-01 03:39:24 --> Router Class Initialized
DEBUG - 2013-09-01 03:39:24 --> Security Class Initialized
DEBUG - 2013-09-01 03:39:24 --> Output Class Initialized
DEBUG - 2013-09-01 03:39:24 --> Input Class Initialized
DEBUG - 2013-09-01 03:39:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:39:24 --> Language Class Initialized
DEBUG - 2013-09-01 03:39:24 --> Security Class Initialized
DEBUG - 2013-09-01 03:39:24 --> Input Class Initialized
DEBUG - 2013-09-01 03:39:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:39:24 --> Language Class Initialized
DEBUG - 2013-09-01 03:39:24 --> Loader Class Initialized
DEBUG - 2013-09-01 03:39:24 --> Loader Class Initialized
DEBUG - 2013-09-01 03:39:24 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:39:24 --> Controller Class Initialized
DEBUG - 2013-09-01 03:39:24 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:39:24 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:39:24 --> Controller Class Initialized
DEBUG - 2013-09-01 03:39:24 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:39:24 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:39:24 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:39:24 --> Model Class Initialized
DEBUG - 2013-09-01 03:39:24 --> Model Class Initialized
DEBUG - 2013-09-01 03:39:24 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:39:24 --> Model Class Initialized
DEBUG - 2013-09-01 03:39:24 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:39:24 --> Model Class Initialized
DEBUG - 2013-09-01 03:39:24 --> Model Class Initialized
DEBUG - 2013-09-01 03:39:24 --> Model Class Initialized
DEBUG - 2013-09-01 03:39:24 --> XSS Filtering completed
DEBUG - 2013-09-01 03:39:24 --> XSS Filtering completed
DEBUG - 2013-09-01 03:39:24 --> XSS Filtering completed
DEBUG - 2013-09-01 03:39:24 --> XSS Filtering completed
DEBUG - 2013-09-01 03:39:24 --> XSS Filtering completed
ERROR - 2013-09-01 03:39:24 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 185
ERROR - 2013-09-01 03:39:24 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-01 03:39:24 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-01 03:39:24 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 195
DEBUG - 2013-09-01 03:40:04 --> Config Class Initialized
DEBUG - 2013-09-01 03:40:04 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:40:04 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:40:04 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:40:04 --> URI Class Initialized
DEBUG - 2013-09-01 03:40:04 --> Router Class Initialized
DEBUG - 2013-09-01 03:40:04 --> Output Class Initialized
DEBUG - 2013-09-01 03:40:04 --> Security Class Initialized
DEBUG - 2013-09-01 03:40:04 --> Input Class Initialized
DEBUG - 2013-09-01 03:40:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:40:04 --> Language Class Initialized
DEBUG - 2013-09-01 03:40:04 --> Loader Class Initialized
DEBUG - 2013-09-01 03:40:04 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:40:04 --> Controller Class Initialized
DEBUG - 2013-09-01 03:40:04 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:40:04 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:40:04 --> Model Class Initialized
DEBUG - 2013-09-01 03:40:04 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:40:04 --> Model Class Initialized
DEBUG - 2013-09-01 03:40:04 --> File loaded: application/views/admin.php
DEBUG - 2013-09-01 03:40:04 --> Final output sent to browser
DEBUG - 2013-09-01 03:40:04 --> Total execution time: 0.0330
DEBUG - 2013-09-01 03:40:05 --> Config Class Initialized
DEBUG - 2013-09-01 03:40:05 --> Config Class Initialized
DEBUG - 2013-09-01 03:40:05 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:40:05 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:40:05 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:40:05 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:40:05 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:40:05 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:40:05 --> URI Class Initialized
DEBUG - 2013-09-01 03:40:05 --> URI Class Initialized
DEBUG - 2013-09-01 03:40:05 --> Router Class Initialized
DEBUG - 2013-09-01 03:40:05 --> Router Class Initialized
DEBUG - 2013-09-01 03:40:05 --> Output Class Initialized
DEBUG - 2013-09-01 03:40:05 --> Output Class Initialized
DEBUG - 2013-09-01 03:40:05 --> Security Class Initialized
DEBUG - 2013-09-01 03:40:05 --> Input Class Initialized
DEBUG - 2013-09-01 03:40:05 --> Security Class Initialized
DEBUG - 2013-09-01 03:40:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:40:05 --> Language Class Initialized
DEBUG - 2013-09-01 03:40:05 --> Input Class Initialized
DEBUG - 2013-09-01 03:40:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:40:05 --> Language Class Initialized
DEBUG - 2013-09-01 03:40:05 --> Loader Class Initialized
DEBUG - 2013-09-01 03:40:05 --> Loader Class Initialized
DEBUG - 2013-09-01 03:40:05 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:40:05 --> Controller Class Initialized
DEBUG - 2013-09-01 03:40:05 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:40:05 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:40:05 --> Controller Class Initialized
DEBUG - 2013-09-01 03:40:05 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:40:05 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:40:05 --> Model Class Initialized
DEBUG - 2013-09-01 03:40:05 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:40:05 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:40:05 --> Model Class Initialized
DEBUG - 2013-09-01 03:40:05 --> Model Class Initialized
DEBUG - 2013-09-01 03:40:05 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:40:05 --> Model Class Initialized
DEBUG - 2013-09-01 03:40:05 --> Model Class Initialized
DEBUG - 2013-09-01 03:40:05 --> XSS Filtering completed
DEBUG - 2013-09-01 03:40:05 --> Model Class Initialized
DEBUG - 2013-09-01 03:40:05 --> XSS Filtering completed
ERROR - 2013-09-01 03:40:05 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 185
ERROR - 2013-09-01 03:40:05 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-01 03:40:05 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
DEBUG - 2013-09-01 03:40:05 --> XSS Filtering completed
ERROR - 2013-09-01 03:40:05 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 195
DEBUG - 2013-09-01 03:40:05 --> XSS Filtering completed
DEBUG - 2013-09-01 03:40:05 --> XSS Filtering completed
DEBUG - 2013-09-01 03:40:14 --> Config Class Initialized
DEBUG - 2013-09-01 03:40:14 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:40:14 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:40:14 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:40:14 --> URI Class Initialized
DEBUG - 2013-09-01 03:40:14 --> Router Class Initialized
DEBUG - 2013-09-01 03:40:14 --> Output Class Initialized
DEBUG - 2013-09-01 03:40:14 --> Security Class Initialized
DEBUG - 2013-09-01 03:40:14 --> Input Class Initialized
DEBUG - 2013-09-01 03:40:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:40:14 --> Language Class Initialized
DEBUG - 2013-09-01 03:40:14 --> Loader Class Initialized
DEBUG - 2013-09-01 03:40:14 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:40:14 --> Controller Class Initialized
DEBUG - 2013-09-01 03:40:14 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:40:14 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:40:14 --> Model Class Initialized
DEBUG - 2013-09-01 03:40:14 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:40:14 --> Model Class Initialized
DEBUG - 2013-09-01 03:40:14 --> File loaded: application/views/admin.php
DEBUG - 2013-09-01 03:40:14 --> Final output sent to browser
DEBUG - 2013-09-01 03:40:14 --> Total execution time: 0.0340
DEBUG - 2013-09-01 03:40:15 --> Config Class Initialized
DEBUG - 2013-09-01 03:40:15 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:40:15 --> Config Class Initialized
DEBUG - 2013-09-01 03:40:15 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:40:15 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:40:15 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:40:15 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:40:15 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:40:15 --> URI Class Initialized
DEBUG - 2013-09-01 03:40:15 --> URI Class Initialized
DEBUG - 2013-09-01 03:40:15 --> Router Class Initialized
DEBUG - 2013-09-01 03:40:15 --> Router Class Initialized
DEBUG - 2013-09-01 03:40:15 --> Output Class Initialized
DEBUG - 2013-09-01 03:40:15 --> Output Class Initialized
DEBUG - 2013-09-01 03:40:15 --> Security Class Initialized
DEBUG - 2013-09-01 03:40:15 --> Security Class Initialized
DEBUG - 2013-09-01 03:40:15 --> Input Class Initialized
DEBUG - 2013-09-01 03:40:15 --> Input Class Initialized
DEBUG - 2013-09-01 03:40:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:40:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:40:15 --> Language Class Initialized
DEBUG - 2013-09-01 03:40:15 --> Language Class Initialized
DEBUG - 2013-09-01 03:40:15 --> Loader Class Initialized
DEBUG - 2013-09-01 03:40:15 --> Loader Class Initialized
DEBUG - 2013-09-01 03:40:15 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:40:15 --> Controller Class Initialized
DEBUG - 2013-09-01 03:40:15 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:40:15 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:40:15 --> Controller Class Initialized
DEBUG - 2013-09-01 03:40:15 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:40:15 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:40:15 --> Model Class Initialized
DEBUG - 2013-09-01 03:40:15 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:40:15 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:40:15 --> Model Class Initialized
DEBUG - 2013-09-01 03:40:15 --> Model Class Initialized
DEBUG - 2013-09-01 03:40:15 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:40:15 --> Model Class Initialized
DEBUG - 2013-09-01 03:40:15 --> Model Class Initialized
DEBUG - 2013-09-01 03:40:15 --> XSS Filtering completed
DEBUG - 2013-09-01 03:40:15 --> XSS Filtering completed
DEBUG - 2013-09-01 03:40:15 --> Model Class Initialized
ERROR - 2013-09-01 03:40:15 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 185
ERROR - 2013-09-01 03:40:15 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-01 03:40:15 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
DEBUG - 2013-09-01 03:40:15 --> XSS Filtering completed
ERROR - 2013-09-01 03:40:15 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 195
DEBUG - 2013-09-01 03:40:15 --> XSS Filtering completed
DEBUG - 2013-09-01 03:40:15 --> XSS Filtering completed
DEBUG - 2013-09-01 03:40:25 --> Config Class Initialized
DEBUG - 2013-09-01 03:40:25 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:40:25 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:40:25 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:40:25 --> URI Class Initialized
DEBUG - 2013-09-01 03:40:25 --> Router Class Initialized
DEBUG - 2013-09-01 03:40:25 --> Output Class Initialized
DEBUG - 2013-09-01 03:40:25 --> Security Class Initialized
DEBUG - 2013-09-01 03:40:25 --> Input Class Initialized
DEBUG - 2013-09-01 03:40:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:40:25 --> Language Class Initialized
DEBUG - 2013-09-01 03:40:25 --> Loader Class Initialized
DEBUG - 2013-09-01 03:40:25 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:40:25 --> Controller Class Initialized
DEBUG - 2013-09-01 03:40:25 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:40:25 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:40:25 --> Model Class Initialized
DEBUG - 2013-09-01 03:40:25 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:40:25 --> Model Class Initialized
DEBUG - 2013-09-01 03:40:25 --> File loaded: application/views/admin.php
DEBUG - 2013-09-01 03:40:25 --> Final output sent to browser
DEBUG - 2013-09-01 03:40:25 --> Total execution time: 0.2790
DEBUG - 2013-09-01 03:40:25 --> Config Class Initialized
DEBUG - 2013-09-01 03:40:25 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:40:25 --> Config Class Initialized
DEBUG - 2013-09-01 03:40:25 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:40:25 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:40:25 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:40:25 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:40:25 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:40:25 --> URI Class Initialized
DEBUG - 2013-09-01 03:40:25 --> URI Class Initialized
DEBUG - 2013-09-01 03:40:25 --> Router Class Initialized
DEBUG - 2013-09-01 03:40:25 --> Router Class Initialized
DEBUG - 2013-09-01 03:40:25 --> Output Class Initialized
DEBUG - 2013-09-01 03:40:25 --> Output Class Initialized
DEBUG - 2013-09-01 03:40:25 --> Security Class Initialized
DEBUG - 2013-09-01 03:40:25 --> Input Class Initialized
DEBUG - 2013-09-01 03:40:25 --> Security Class Initialized
DEBUG - 2013-09-01 03:40:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:40:25 --> Language Class Initialized
DEBUG - 2013-09-01 03:40:25 --> Input Class Initialized
DEBUG - 2013-09-01 03:40:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:40:25 --> Language Class Initialized
DEBUG - 2013-09-01 03:40:25 --> Loader Class Initialized
DEBUG - 2013-09-01 03:40:25 --> Loader Class Initialized
DEBUG - 2013-09-01 03:40:25 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:40:25 --> Controller Class Initialized
DEBUG - 2013-09-01 03:40:25 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:40:25 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:40:25 --> Controller Class Initialized
DEBUG - 2013-09-01 03:40:25 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:40:25 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:40:25 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:40:25 --> Model Class Initialized
DEBUG - 2013-09-01 03:40:25 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:40:25 --> Model Class Initialized
DEBUG - 2013-09-01 03:40:25 --> Model Class Initialized
DEBUG - 2013-09-01 03:40:25 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:40:25 --> Model Class Initialized
DEBUG - 2013-09-01 03:40:25 --> Model Class Initialized
DEBUG - 2013-09-01 03:40:25 --> Model Class Initialized
DEBUG - 2013-09-01 03:40:25 --> XSS Filtering completed
DEBUG - 2013-09-01 03:40:25 --> XSS Filtering completed
DEBUG - 2013-09-01 03:40:25 --> XSS Filtering completed
DEBUG - 2013-09-01 03:40:25 --> XSS Filtering completed
DEBUG - 2013-09-01 03:40:25 --> XSS Filtering completed
ERROR - 2013-09-01 03:40:25 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 185
ERROR - 2013-09-01 03:40:25 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-01 03:40:25 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-01 03:40:25 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 195
DEBUG - 2013-09-01 03:40:36 --> Config Class Initialized
DEBUG - 2013-09-01 03:40:36 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:40:36 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:40:36 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:40:36 --> URI Class Initialized
DEBUG - 2013-09-01 03:40:36 --> Router Class Initialized
DEBUG - 2013-09-01 03:40:36 --> Output Class Initialized
DEBUG - 2013-09-01 03:40:36 --> Security Class Initialized
DEBUG - 2013-09-01 03:40:36 --> Input Class Initialized
DEBUG - 2013-09-01 03:40:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:40:36 --> Language Class Initialized
DEBUG - 2013-09-01 03:40:36 --> Loader Class Initialized
DEBUG - 2013-09-01 03:40:36 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:40:36 --> Controller Class Initialized
DEBUG - 2013-09-01 03:40:36 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:40:36 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:40:36 --> Model Class Initialized
DEBUG - 2013-09-01 03:40:36 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:40:36 --> Model Class Initialized
DEBUG - 2013-09-01 03:40:36 --> File loaded: application/views/admin.php
DEBUG - 2013-09-01 03:40:36 --> Final output sent to browser
DEBUG - 2013-09-01 03:40:36 --> Total execution time: 0.0330
DEBUG - 2013-09-01 03:40:36 --> Config Class Initialized
DEBUG - 2013-09-01 03:40:36 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:40:36 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:40:36 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:40:36 --> Config Class Initialized
DEBUG - 2013-09-01 03:40:36 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:40:36 --> URI Class Initialized
DEBUG - 2013-09-01 03:40:36 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:40:36 --> Router Class Initialized
DEBUG - 2013-09-01 03:40:36 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:40:36 --> URI Class Initialized
DEBUG - 2013-09-01 03:40:36 --> Output Class Initialized
DEBUG - 2013-09-01 03:40:36 --> Router Class Initialized
DEBUG - 2013-09-01 03:40:36 --> Security Class Initialized
DEBUG - 2013-09-01 03:40:36 --> Output Class Initialized
DEBUG - 2013-09-01 03:40:36 --> Input Class Initialized
DEBUG - 2013-09-01 03:40:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:40:36 --> Security Class Initialized
DEBUG - 2013-09-01 03:40:36 --> Language Class Initialized
DEBUG - 2013-09-01 03:40:36 --> Input Class Initialized
DEBUG - 2013-09-01 03:40:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:40:36 --> Language Class Initialized
DEBUG - 2013-09-01 03:40:36 --> Loader Class Initialized
DEBUG - 2013-09-01 03:40:36 --> Loader Class Initialized
DEBUG - 2013-09-01 03:40:36 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:40:36 --> Controller Class Initialized
DEBUG - 2013-09-01 03:40:36 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:40:36 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:40:36 --> Controller Class Initialized
DEBUG - 2013-09-01 03:40:36 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:40:36 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:40:36 --> Model Class Initialized
DEBUG - 2013-09-01 03:40:36 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:40:36 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:40:36 --> Model Class Initialized
DEBUG - 2013-09-01 03:40:36 --> Model Class Initialized
DEBUG - 2013-09-01 03:40:36 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:40:36 --> Model Class Initialized
DEBUG - 2013-09-01 03:40:36 --> Model Class Initialized
DEBUG - 2013-09-01 03:40:36 --> XSS Filtering completed
DEBUG - 2013-09-01 03:40:36 --> Model Class Initialized
DEBUG - 2013-09-01 03:40:36 --> XSS Filtering completed
ERROR - 2013-09-01 03:40:36 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 185
ERROR - 2013-09-01 03:40:36 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
DEBUG - 2013-09-01 03:40:36 --> XSS Filtering completed
ERROR - 2013-09-01 03:40:36 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-01 03:40:36 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 195
DEBUG - 2013-09-01 03:40:36 --> XSS Filtering completed
DEBUG - 2013-09-01 03:40:36 --> XSS Filtering completed
DEBUG - 2013-09-01 03:40:50 --> Config Class Initialized
DEBUG - 2013-09-01 03:40:50 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:40:50 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:40:50 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:40:50 --> URI Class Initialized
DEBUG - 2013-09-01 03:40:50 --> Router Class Initialized
DEBUG - 2013-09-01 03:40:50 --> Output Class Initialized
DEBUG - 2013-09-01 03:40:50 --> Security Class Initialized
DEBUG - 2013-09-01 03:40:50 --> Input Class Initialized
DEBUG - 2013-09-01 03:40:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:40:50 --> Language Class Initialized
DEBUG - 2013-09-01 03:40:50 --> Loader Class Initialized
DEBUG - 2013-09-01 03:40:50 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:40:50 --> Controller Class Initialized
DEBUG - 2013-09-01 03:40:50 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:40:50 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:40:50 --> Model Class Initialized
DEBUG - 2013-09-01 03:40:50 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:40:50 --> Model Class Initialized
DEBUG - 2013-09-01 03:40:50 --> File loaded: application/views/admin.php
DEBUG - 2013-09-01 03:40:50 --> Final output sent to browser
DEBUG - 2013-09-01 03:40:50 --> Total execution time: 0.0330
DEBUG - 2013-09-01 03:40:50 --> Config Class Initialized
DEBUG - 2013-09-01 03:40:50 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:40:50 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:40:50 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:40:50 --> Config Class Initialized
DEBUG - 2013-09-01 03:40:50 --> URI Class Initialized
DEBUG - 2013-09-01 03:40:50 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:40:50 --> Router Class Initialized
DEBUG - 2013-09-01 03:40:50 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:40:50 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:40:50 --> URI Class Initialized
DEBUG - 2013-09-01 03:40:50 --> Output Class Initialized
DEBUG - 2013-09-01 03:40:50 --> Router Class Initialized
DEBUG - 2013-09-01 03:40:50 --> Security Class Initialized
DEBUG - 2013-09-01 03:40:50 --> Input Class Initialized
DEBUG - 2013-09-01 03:40:50 --> Output Class Initialized
DEBUG - 2013-09-01 03:40:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:40:50 --> Language Class Initialized
DEBUG - 2013-09-01 03:40:50 --> Security Class Initialized
DEBUG - 2013-09-01 03:40:50 --> Input Class Initialized
DEBUG - 2013-09-01 03:40:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:40:50 --> Language Class Initialized
DEBUG - 2013-09-01 03:40:50 --> Loader Class Initialized
DEBUG - 2013-09-01 03:40:50 --> Loader Class Initialized
DEBUG - 2013-09-01 03:40:50 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:40:50 --> Controller Class Initialized
DEBUG - 2013-09-01 03:40:50 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:40:50 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:40:50 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:40:50 --> Controller Class Initialized
DEBUG - 2013-09-01 03:40:50 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:40:50 --> Model Class Initialized
DEBUG - 2013-09-01 03:40:50 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:40:50 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:40:50 --> Model Class Initialized
DEBUG - 2013-09-01 03:40:50 --> Model Class Initialized
DEBUG - 2013-09-01 03:40:50 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:40:50 --> Model Class Initialized
DEBUG - 2013-09-01 03:40:50 --> Model Class Initialized
DEBUG - 2013-09-01 03:40:50 --> XSS Filtering completed
DEBUG - 2013-09-01 03:40:50 --> XSS Filtering completed
DEBUG - 2013-09-01 03:40:50 --> XSS Filtering completed
DEBUG - 2013-09-01 03:40:50 --> Model Class Initialized
DEBUG - 2013-09-01 03:40:50 --> XSS Filtering completed
DEBUG - 2013-09-01 03:40:50 --> XSS Filtering completed
ERROR - 2013-09-01 03:40:50 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 185
ERROR - 2013-09-01 03:40:50 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-01 03:40:50 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-01 03:40:50 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 195
DEBUG - 2013-09-01 03:40:55 --> Config Class Initialized
DEBUG - 2013-09-01 03:40:55 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:40:55 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:40:55 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:40:55 --> URI Class Initialized
DEBUG - 2013-09-01 03:40:55 --> Router Class Initialized
DEBUG - 2013-09-01 03:40:55 --> Output Class Initialized
DEBUG - 2013-09-01 03:40:55 --> Security Class Initialized
DEBUG - 2013-09-01 03:40:55 --> Input Class Initialized
DEBUG - 2013-09-01 03:40:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:40:55 --> Language Class Initialized
DEBUG - 2013-09-01 03:40:55 --> Loader Class Initialized
DEBUG - 2013-09-01 03:40:55 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:40:55 --> Controller Class Initialized
DEBUG - 2013-09-01 03:40:55 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:40:55 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:40:55 --> Model Class Initialized
DEBUG - 2013-09-01 03:40:55 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:40:55 --> Model Class Initialized
DEBUG - 2013-09-01 03:40:55 --> Model Class Initialized
DEBUG - 2013-09-01 03:57:51 --> Config Class Initialized
DEBUG - 2013-09-01 03:57:51 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:57:51 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:57:51 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:57:51 --> URI Class Initialized
DEBUG - 2013-09-01 03:57:51 --> Router Class Initialized
DEBUG - 2013-09-01 03:57:51 --> Output Class Initialized
DEBUG - 2013-09-01 03:57:51 --> Security Class Initialized
DEBUG - 2013-09-01 03:57:51 --> Input Class Initialized
DEBUG - 2013-09-01 03:57:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:57:51 --> Language Class Initialized
DEBUG - 2013-09-01 03:57:51 --> Loader Class Initialized
DEBUG - 2013-09-01 03:57:51 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:57:51 --> Controller Class Initialized
DEBUG - 2013-09-01 03:57:51 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:57:51 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:57:51 --> Model Class Initialized
DEBUG - 2013-09-01 03:57:51 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:57:51 --> Model Class Initialized
DEBUG - 2013-09-01 03:57:51 --> File loaded: application/views/admin.php
DEBUG - 2013-09-01 03:57:51 --> Final output sent to browser
DEBUG - 2013-09-01 03:57:51 --> Total execution time: 0.0340
DEBUG - 2013-09-01 03:57:58 --> Config Class Initialized
DEBUG - 2013-09-01 03:57:58 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:57:58 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:57:58 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:57:58 --> URI Class Initialized
DEBUG - 2013-09-01 03:57:58 --> Router Class Initialized
DEBUG - 2013-09-01 03:57:58 --> Output Class Initialized
DEBUG - 2013-09-01 03:57:58 --> Security Class Initialized
DEBUG - 2013-09-01 03:57:58 --> Input Class Initialized
DEBUG - 2013-09-01 03:57:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:57:58 --> Language Class Initialized
DEBUG - 2013-09-01 03:57:58 --> Loader Class Initialized
DEBUG - 2013-09-01 03:57:58 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:57:58 --> Controller Class Initialized
DEBUG - 2013-09-01 03:57:58 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:57:58 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:57:58 --> Model Class Initialized
DEBUG - 2013-09-01 03:57:58 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:57:58 --> Model Class Initialized
DEBUG - 2013-09-01 03:57:58 --> Model Class Initialized
DEBUG - 2013-09-01 03:57:58 --> XSS Filtering completed
DEBUG - 2013-09-01 03:57:58 --> XSS Filtering completed
DEBUG - 2013-09-01 03:57:58 --> Config Class Initialized
DEBUG - 2013-09-01 03:57:58 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:57:58 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:57:58 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:57:58 --> URI Class Initialized
DEBUG - 2013-09-01 03:57:58 --> Router Class Initialized
DEBUG - 2013-09-01 03:57:58 --> Config Class Initialized
DEBUG - 2013-09-01 03:57:58 --> Hooks Class Initialized
DEBUG - 2013-09-01 03:57:58 --> Utf8 Class Initialized
DEBUG - 2013-09-01 03:57:58 --> Output Class Initialized
DEBUG - 2013-09-01 03:57:58 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 03:57:58 --> Security Class Initialized
DEBUG - 2013-09-01 03:57:58 --> URI Class Initialized
DEBUG - 2013-09-01 03:57:58 --> Router Class Initialized
DEBUG - 2013-09-01 03:57:58 --> Input Class Initialized
DEBUG - 2013-09-01 03:57:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:57:58 --> Language Class Initialized
DEBUG - 2013-09-01 03:57:58 --> Output Class Initialized
DEBUG - 2013-09-01 03:57:58 --> Security Class Initialized
DEBUG - 2013-09-01 03:57:58 --> Input Class Initialized
DEBUG - 2013-09-01 03:57:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 03:57:58 --> Loader Class Initialized
DEBUG - 2013-09-01 03:57:58 --> Language Class Initialized
DEBUG - 2013-09-01 03:57:58 --> Loader Class Initialized
DEBUG - 2013-09-01 03:57:58 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:57:58 --> Controller Class Initialized
DEBUG - 2013-09-01 03:57:58 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:57:58 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:57:58 --> Model Class Initialized
DEBUG - 2013-09-01 03:57:58 --> Database Driver Class Initialized
DEBUG - 2013-09-01 03:57:58 --> Controller Class Initialized
DEBUG - 2013-09-01 03:57:58 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:57:58 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 03:57:58 --> Model Class Initialized
DEBUG - 2013-09-01 03:57:58 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 03:57:58 --> Model Class Initialized
DEBUG - 2013-09-01 03:57:58 --> Model Class Initialized
DEBUG - 2013-09-01 03:57:58 --> XSS Filtering completed
DEBUG - 2013-09-01 03:57:58 --> Helper loaded: date_helper
DEBUG - 2013-09-01 03:57:58 --> XSS Filtering completed
DEBUG - 2013-09-01 03:57:58 --> XSS Filtering completed
DEBUG - 2013-09-01 03:57:58 --> Model Class Initialized
DEBUG - 2013-09-01 03:57:58 --> Model Class Initialized
DEBUG - 2013-09-01 03:57:58 --> XSS Filtering completed
DEBUG - 2013-09-01 03:57:58 --> XSS Filtering completed
ERROR - 2013-09-01 03:57:58 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 185
ERROR - 2013-09-01 03:57:58 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-01 03:57:58 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-01 03:57:58 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 195
DEBUG - 2013-09-01 04:07:52 --> Config Class Initialized
DEBUG - 2013-09-01 04:07:52 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:07:52 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:07:52 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:07:52 --> URI Class Initialized
DEBUG - 2013-09-01 04:07:52 --> Router Class Initialized
DEBUG - 2013-09-01 04:07:52 --> No URI present. Default controller set.
DEBUG - 2013-09-01 04:07:52 --> Output Class Initialized
DEBUG - 2013-09-01 04:07:52 --> Security Class Initialized
DEBUG - 2013-09-01 04:07:52 --> Input Class Initialized
DEBUG - 2013-09-01 04:07:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:07:52 --> Language Class Initialized
DEBUG - 2013-09-01 04:07:52 --> Loader Class Initialized
DEBUG - 2013-09-01 04:07:52 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:07:52 --> Controller Class Initialized
DEBUG - 2013-09-01 04:07:52 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:07:52 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:07:52 --> Model Class Initialized
DEBUG - 2013-09-01 04:07:52 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:07:52 --> Model Class Initialized
DEBUG - 2013-09-01 04:07:52 --> File loaded: application/views/index.php
DEBUG - 2013-09-01 04:07:52 --> Final output sent to browser
DEBUG - 2013-09-01 04:07:52 --> Total execution time: 0.0360
DEBUG - 2013-09-01 04:09:29 --> Config Class Initialized
DEBUG - 2013-09-01 04:09:29 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:09:29 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:09:29 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:09:29 --> URI Class Initialized
DEBUG - 2013-09-01 04:09:29 --> Router Class Initialized
DEBUG - 2013-09-01 04:09:29 --> No URI present. Default controller set.
DEBUG - 2013-09-01 04:09:29 --> Output Class Initialized
DEBUG - 2013-09-01 04:09:29 --> Security Class Initialized
DEBUG - 2013-09-01 04:09:29 --> Input Class Initialized
DEBUG - 2013-09-01 04:09:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:09:29 --> Language Class Initialized
DEBUG - 2013-09-01 04:09:29 --> Loader Class Initialized
DEBUG - 2013-09-01 04:09:29 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:09:29 --> Controller Class Initialized
DEBUG - 2013-09-01 04:09:29 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:09:29 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:09:29 --> Model Class Initialized
DEBUG - 2013-09-01 04:09:29 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:09:29 --> Model Class Initialized
DEBUG - 2013-09-01 04:09:29 --> File loaded: application/views/index.php
DEBUG - 2013-09-01 04:09:29 --> Final output sent to browser
DEBUG - 2013-09-01 04:09:29 --> Total execution time: 0.0390
DEBUG - 2013-09-01 04:10:19 --> Config Class Initialized
DEBUG - 2013-09-01 04:10:19 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:10:19 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:10:19 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:10:19 --> URI Class Initialized
DEBUG - 2013-09-01 04:10:19 --> Router Class Initialized
DEBUG - 2013-09-01 04:10:19 --> No URI present. Default controller set.
DEBUG - 2013-09-01 04:10:19 --> Output Class Initialized
DEBUG - 2013-09-01 04:10:19 --> Security Class Initialized
DEBUG - 2013-09-01 04:10:19 --> Input Class Initialized
DEBUG - 2013-09-01 04:10:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:10:19 --> Language Class Initialized
DEBUG - 2013-09-01 04:10:19 --> Loader Class Initialized
DEBUG - 2013-09-01 04:10:19 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:10:19 --> Controller Class Initialized
DEBUG - 2013-09-01 04:10:19 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:10:19 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:10:19 --> Model Class Initialized
DEBUG - 2013-09-01 04:10:19 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:10:19 --> Model Class Initialized
DEBUG - 2013-09-01 04:10:19 --> File loaded: application/views/index.php
DEBUG - 2013-09-01 04:10:19 --> Final output sent to browser
DEBUG - 2013-09-01 04:10:19 --> Total execution time: 0.0350
DEBUG - 2013-09-01 04:10:40 --> Config Class Initialized
DEBUG - 2013-09-01 04:10:40 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:10:40 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:10:40 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:10:40 --> URI Class Initialized
DEBUG - 2013-09-01 04:10:40 --> Router Class Initialized
DEBUG - 2013-09-01 04:10:40 --> No URI present. Default controller set.
DEBUG - 2013-09-01 04:10:40 --> Output Class Initialized
DEBUG - 2013-09-01 04:10:40 --> Security Class Initialized
DEBUG - 2013-09-01 04:10:40 --> Input Class Initialized
DEBUG - 2013-09-01 04:10:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:10:40 --> Language Class Initialized
DEBUG - 2013-09-01 04:10:40 --> Loader Class Initialized
DEBUG - 2013-09-01 04:10:40 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:10:40 --> Controller Class Initialized
DEBUG - 2013-09-01 04:10:40 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:10:40 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:10:40 --> Model Class Initialized
DEBUG - 2013-09-01 04:10:40 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:10:40 --> Model Class Initialized
DEBUG - 2013-09-01 04:10:40 --> File loaded: application/views/index.php
DEBUG - 2013-09-01 04:10:40 --> Final output sent to browser
DEBUG - 2013-09-01 04:10:40 --> Total execution time: 0.0350
DEBUG - 2013-09-01 04:10:40 --> Config Class Initialized
DEBUG - 2013-09-01 04:10:40 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:10:40 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:10:40 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:10:40 --> URI Class Initialized
DEBUG - 2013-09-01 04:10:40 --> Router Class Initialized
DEBUG - 2013-09-01 04:10:40 --> No URI present. Default controller set.
DEBUG - 2013-09-01 04:10:40 --> Output Class Initialized
DEBUG - 2013-09-01 04:10:40 --> Security Class Initialized
DEBUG - 2013-09-01 04:10:40 --> Input Class Initialized
DEBUG - 2013-09-01 04:10:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:10:40 --> Language Class Initialized
DEBUG - 2013-09-01 04:10:40 --> Loader Class Initialized
DEBUG - 2013-09-01 04:10:40 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:10:40 --> Controller Class Initialized
DEBUG - 2013-09-01 04:10:40 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:10:40 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:10:40 --> Model Class Initialized
DEBUG - 2013-09-01 04:10:40 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:10:40 --> Model Class Initialized
DEBUG - 2013-09-01 04:10:40 --> File loaded: application/views/index.php
DEBUG - 2013-09-01 04:10:40 --> Final output sent to browser
DEBUG - 2013-09-01 04:10:40 --> Total execution time: 0.0350
DEBUG - 2013-09-01 04:11:30 --> Config Class Initialized
DEBUG - 2013-09-01 04:11:30 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:11:30 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:11:30 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:11:30 --> URI Class Initialized
DEBUG - 2013-09-01 04:11:30 --> Router Class Initialized
DEBUG - 2013-09-01 04:11:30 --> Output Class Initialized
DEBUG - 2013-09-01 04:11:30 --> Security Class Initialized
DEBUG - 2013-09-01 04:11:30 --> Input Class Initialized
DEBUG - 2013-09-01 04:11:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:11:30 --> Language Class Initialized
DEBUG - 2013-09-01 04:11:30 --> Loader Class Initialized
DEBUG - 2013-09-01 04:11:30 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:11:30 --> Controller Class Initialized
DEBUG - 2013-09-01 04:11:30 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:11:30 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:11:30 --> Model Class Initialized
DEBUG - 2013-09-01 04:11:30 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:11:30 --> Model Class Initialized
DEBUG - 2013-09-01 04:11:30 --> File loaded: application/views/admin.php
DEBUG - 2013-09-01 04:11:30 --> Final output sent to browser
DEBUG - 2013-09-01 04:11:30 --> Total execution time: 0.0370
DEBUG - 2013-09-01 04:11:31 --> Config Class Initialized
DEBUG - 2013-09-01 04:11:31 --> Config Class Initialized
DEBUG - 2013-09-01 04:11:31 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:11:31 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:11:31 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:11:31 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:11:31 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:11:31 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:11:31 --> URI Class Initialized
DEBUG - 2013-09-01 04:11:31 --> URI Class Initialized
DEBUG - 2013-09-01 04:11:31 --> Router Class Initialized
DEBUG - 2013-09-01 04:11:31 --> Router Class Initialized
DEBUG - 2013-09-01 04:11:31 --> Output Class Initialized
DEBUG - 2013-09-01 04:11:31 --> Output Class Initialized
DEBUG - 2013-09-01 04:11:31 --> Security Class Initialized
DEBUG - 2013-09-01 04:11:31 --> Security Class Initialized
DEBUG - 2013-09-01 04:11:31 --> Input Class Initialized
DEBUG - 2013-09-01 04:11:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:11:31 --> Input Class Initialized
DEBUG - 2013-09-01 04:11:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:11:31 --> Language Class Initialized
DEBUG - 2013-09-01 04:11:31 --> Language Class Initialized
DEBUG - 2013-09-01 04:11:31 --> Loader Class Initialized
DEBUG - 2013-09-01 04:11:31 --> Loader Class Initialized
DEBUG - 2013-09-01 04:11:31 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:11:31 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:11:31 --> Controller Class Initialized
DEBUG - 2013-09-01 04:11:31 --> Controller Class Initialized
DEBUG - 2013-09-01 04:11:31 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:11:31 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:11:31 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:11:31 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:11:31 --> Model Class Initialized
DEBUG - 2013-09-01 04:11:31 --> Model Class Initialized
DEBUG - 2013-09-01 04:11:31 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:11:31 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:11:31 --> Model Class Initialized
DEBUG - 2013-09-01 04:11:31 --> Model Class Initialized
DEBUG - 2013-09-01 04:11:31 --> Model Class Initialized
DEBUG - 2013-09-01 04:11:31 --> XSS Filtering completed
DEBUG - 2013-09-01 04:11:31 --> XSS Filtering completed
DEBUG - 2013-09-01 04:11:31 --> XSS Filtering completed
DEBUG - 2013-09-01 04:11:31 --> Model Class Initialized
DEBUG - 2013-09-01 04:11:31 --> XSS Filtering completed
DEBUG - 2013-09-01 04:11:31 --> XSS Filtering completed
ERROR - 2013-09-01 04:11:31 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 185
ERROR - 2013-09-01 04:11:31 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-01 04:11:31 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-01 04:11:31 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 195
DEBUG - 2013-09-01 04:11:55 --> Config Class Initialized
DEBUG - 2013-09-01 04:11:55 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:11:55 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:11:55 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:11:55 --> URI Class Initialized
DEBUG - 2013-09-01 04:11:55 --> Router Class Initialized
DEBUG - 2013-09-01 04:11:55 --> Output Class Initialized
DEBUG - 2013-09-01 04:11:55 --> Security Class Initialized
DEBUG - 2013-09-01 04:11:55 --> Input Class Initialized
DEBUG - 2013-09-01 04:11:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:11:55 --> Language Class Initialized
DEBUG - 2013-09-01 04:11:55 --> Loader Class Initialized
DEBUG - 2013-09-01 04:11:55 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:11:55 --> Controller Class Initialized
DEBUG - 2013-09-01 04:11:55 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:11:55 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:11:55 --> Model Class Initialized
DEBUG - 2013-09-01 04:11:55 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:11:55 --> Model Class Initialized
DEBUG - 2013-09-01 04:11:55 --> Model Class Initialized
DEBUG - 2013-09-01 04:12:07 --> Config Class Initialized
DEBUG - 2013-09-01 04:12:07 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:12:07 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:12:07 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:12:07 --> URI Class Initialized
DEBUG - 2013-09-01 04:12:07 --> Router Class Initialized
DEBUG - 2013-09-01 04:12:07 --> No URI present. Default controller set.
DEBUG - 2013-09-01 04:12:07 --> Output Class Initialized
DEBUG - 2013-09-01 04:12:07 --> Security Class Initialized
DEBUG - 2013-09-01 04:12:07 --> Input Class Initialized
DEBUG - 2013-09-01 04:12:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:12:07 --> Language Class Initialized
DEBUG - 2013-09-01 04:12:07 --> Loader Class Initialized
DEBUG - 2013-09-01 04:12:07 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:12:07 --> Controller Class Initialized
DEBUG - 2013-09-01 04:12:07 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:12:07 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:12:07 --> Model Class Initialized
DEBUG - 2013-09-01 04:12:07 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:12:07 --> Model Class Initialized
DEBUG - 2013-09-01 04:12:07 --> File loaded: application/views/index.php
DEBUG - 2013-09-01 04:12:07 --> Final output sent to browser
DEBUG - 2013-09-01 04:12:07 --> Total execution time: 0.0390
DEBUG - 2013-09-01 04:12:25 --> Config Class Initialized
DEBUG - 2013-09-01 04:12:25 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:12:25 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:12:25 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:12:25 --> URI Class Initialized
DEBUG - 2013-09-01 04:12:25 --> Router Class Initialized
DEBUG - 2013-09-01 04:12:25 --> No URI present. Default controller set.
DEBUG - 2013-09-01 04:12:25 --> Output Class Initialized
DEBUG - 2013-09-01 04:12:25 --> Security Class Initialized
DEBUG - 2013-09-01 04:12:25 --> Input Class Initialized
DEBUG - 2013-09-01 04:12:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:12:25 --> Language Class Initialized
DEBUG - 2013-09-01 04:12:25 --> Loader Class Initialized
DEBUG - 2013-09-01 04:12:25 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:12:25 --> Controller Class Initialized
DEBUG - 2013-09-01 04:12:25 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:12:25 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:12:25 --> Model Class Initialized
DEBUG - 2013-09-01 04:12:25 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:12:25 --> Model Class Initialized
DEBUG - 2013-09-01 04:12:25 --> File loaded: application/views/index.php
DEBUG - 2013-09-01 04:12:25 --> Final output sent to browser
DEBUG - 2013-09-01 04:12:25 --> Total execution time: 0.1530
DEBUG - 2013-09-01 04:12:29 --> Config Class Initialized
DEBUG - 2013-09-01 04:12:29 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:12:29 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:12:29 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:12:29 --> URI Class Initialized
DEBUG - 2013-09-01 04:12:29 --> Router Class Initialized
DEBUG - 2013-09-01 04:12:29 --> No URI present. Default controller set.
DEBUG - 2013-09-01 04:12:29 --> Output Class Initialized
DEBUG - 2013-09-01 04:12:29 --> Security Class Initialized
DEBUG - 2013-09-01 04:12:30 --> Input Class Initialized
DEBUG - 2013-09-01 04:12:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:12:30 --> Language Class Initialized
DEBUG - 2013-09-01 04:12:30 --> Loader Class Initialized
DEBUG - 2013-09-01 04:12:30 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:12:30 --> Controller Class Initialized
DEBUG - 2013-09-01 04:12:30 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:12:30 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:12:30 --> Model Class Initialized
DEBUG - 2013-09-01 04:12:30 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:12:30 --> Model Class Initialized
DEBUG - 2013-09-01 04:12:30 --> File loaded: application/views/index.php
DEBUG - 2013-09-01 04:12:30 --> Final output sent to browser
DEBUG - 2013-09-01 04:12:30 --> Total execution time: 0.0370
DEBUG - 2013-09-01 04:12:35 --> Config Class Initialized
DEBUG - 2013-09-01 04:12:35 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:12:35 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:12:35 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:12:35 --> URI Class Initialized
DEBUG - 2013-09-01 04:12:35 --> Router Class Initialized
DEBUG - 2013-09-01 04:12:35 --> No URI present. Default controller set.
DEBUG - 2013-09-01 04:12:35 --> Output Class Initialized
DEBUG - 2013-09-01 04:12:35 --> Security Class Initialized
DEBUG - 2013-09-01 04:12:35 --> Input Class Initialized
DEBUG - 2013-09-01 04:12:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:12:35 --> Language Class Initialized
DEBUG - 2013-09-01 04:12:35 --> Loader Class Initialized
DEBUG - 2013-09-01 04:12:35 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:12:35 --> Controller Class Initialized
DEBUG - 2013-09-01 04:12:35 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:12:35 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:12:35 --> Model Class Initialized
DEBUG - 2013-09-01 04:12:35 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:12:35 --> Model Class Initialized
DEBUG - 2013-09-01 04:12:35 --> File loaded: application/views/index.php
DEBUG - 2013-09-01 04:12:35 --> Final output sent to browser
DEBUG - 2013-09-01 04:12:35 --> Total execution time: 0.0330
DEBUG - 2013-09-01 04:13:10 --> Config Class Initialized
DEBUG - 2013-09-01 04:13:10 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:13:10 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:13:10 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:13:10 --> URI Class Initialized
DEBUG - 2013-09-01 04:13:10 --> Router Class Initialized
DEBUG - 2013-09-01 04:13:10 --> No URI present. Default controller set.
DEBUG - 2013-09-01 04:13:10 --> Output Class Initialized
DEBUG - 2013-09-01 04:13:10 --> Security Class Initialized
DEBUG - 2013-09-01 04:13:10 --> Input Class Initialized
DEBUG - 2013-09-01 04:13:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:13:10 --> Language Class Initialized
DEBUG - 2013-09-01 04:13:10 --> Loader Class Initialized
DEBUG - 2013-09-01 04:13:10 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:13:10 --> Controller Class Initialized
DEBUG - 2013-09-01 04:13:10 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:13:10 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:13:10 --> Model Class Initialized
DEBUG - 2013-09-01 04:13:10 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:13:10 --> Model Class Initialized
DEBUG - 2013-09-01 04:13:10 --> File loaded: application/views/index.php
DEBUG - 2013-09-01 04:13:10 --> Final output sent to browser
DEBUG - 2013-09-01 04:13:10 --> Total execution time: 0.0360
DEBUG - 2013-09-01 04:13:12 --> Config Class Initialized
DEBUG - 2013-09-01 04:13:12 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:13:12 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:13:12 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:13:12 --> URI Class Initialized
DEBUG - 2013-09-01 04:13:12 --> Router Class Initialized
DEBUG - 2013-09-01 04:13:12 --> Output Class Initialized
DEBUG - 2013-09-01 04:13:12 --> Security Class Initialized
DEBUG - 2013-09-01 04:13:12 --> Input Class Initialized
DEBUG - 2013-09-01 04:13:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:13:12 --> Language Class Initialized
DEBUG - 2013-09-01 04:13:12 --> Loader Class Initialized
DEBUG - 2013-09-01 04:13:12 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:13:12 --> Controller Class Initialized
DEBUG - 2013-09-01 04:13:12 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:13:12 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:13:12 --> Model Class Initialized
DEBUG - 2013-09-01 04:13:12 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:13:12 --> Model Class Initialized
DEBUG - 2013-09-01 04:13:12 --> File loaded: application/views/admin.php
DEBUG - 2013-09-01 04:13:12 --> Final output sent to browser
DEBUG - 2013-09-01 04:13:12 --> Total execution time: 0.0370
DEBUG - 2013-09-01 04:13:17 --> Config Class Initialized
DEBUG - 2013-09-01 04:13:17 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:13:17 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:13:17 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:13:17 --> URI Class Initialized
DEBUG - 2013-09-01 04:13:17 --> Router Class Initialized
DEBUG - 2013-09-01 04:13:17 --> Output Class Initialized
DEBUG - 2013-09-01 04:13:17 --> Security Class Initialized
DEBUG - 2013-09-01 04:13:17 --> Input Class Initialized
DEBUG - 2013-09-01 04:13:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:13:17 --> Language Class Initialized
DEBUG - 2013-09-01 04:13:17 --> Loader Class Initialized
DEBUG - 2013-09-01 04:13:17 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:13:17 --> Controller Class Initialized
DEBUG - 2013-09-01 04:13:17 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:13:17 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:13:17 --> Model Class Initialized
DEBUG - 2013-09-01 04:13:17 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:13:17 --> Model Class Initialized
DEBUG - 2013-09-01 04:13:17 --> File loaded: application/views/admin.php
DEBUG - 2013-09-01 04:13:17 --> Final output sent to browser
DEBUG - 2013-09-01 04:13:17 --> Total execution time: 0.0370
DEBUG - 2013-09-01 04:13:39 --> Config Class Initialized
DEBUG - 2013-09-01 04:13:39 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:13:39 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:13:39 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:13:39 --> URI Class Initialized
DEBUG - 2013-09-01 04:13:39 --> Router Class Initialized
DEBUG - 2013-09-01 04:13:39 --> No URI present. Default controller set.
DEBUG - 2013-09-01 04:13:39 --> Output Class Initialized
DEBUG - 2013-09-01 04:13:39 --> Security Class Initialized
DEBUG - 2013-09-01 04:13:39 --> Input Class Initialized
DEBUG - 2013-09-01 04:13:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:13:39 --> Language Class Initialized
DEBUG - 2013-09-01 04:13:39 --> Loader Class Initialized
DEBUG - 2013-09-01 04:13:39 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:13:39 --> Controller Class Initialized
DEBUG - 2013-09-01 04:13:39 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:13:39 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:13:39 --> Model Class Initialized
DEBUG - 2013-09-01 04:13:39 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:13:39 --> Model Class Initialized
DEBUG - 2013-09-01 04:13:39 --> File loaded: application/views/index.php
DEBUG - 2013-09-01 04:13:39 --> Final output sent to browser
DEBUG - 2013-09-01 04:13:39 --> Total execution time: 0.0340
DEBUG - 2013-09-01 04:13:40 --> Config Class Initialized
DEBUG - 2013-09-01 04:13:40 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:13:40 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:13:40 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:13:40 --> URI Class Initialized
DEBUG - 2013-09-01 04:13:40 --> Router Class Initialized
DEBUG - 2013-09-01 04:13:40 --> Output Class Initialized
DEBUG - 2013-09-01 04:13:40 --> Security Class Initialized
DEBUG - 2013-09-01 04:13:40 --> Input Class Initialized
DEBUG - 2013-09-01 04:13:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:13:40 --> Language Class Initialized
DEBUG - 2013-09-01 04:13:40 --> Loader Class Initialized
DEBUG - 2013-09-01 04:13:41 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:13:41 --> Controller Class Initialized
DEBUG - 2013-09-01 04:13:41 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:13:41 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:13:41 --> Model Class Initialized
DEBUG - 2013-09-01 04:13:41 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:13:41 --> Model Class Initialized
DEBUG - 2013-09-01 04:13:41 --> File loaded: application/views/admin.php
DEBUG - 2013-09-01 04:13:41 --> Final output sent to browser
DEBUG - 2013-09-01 04:13:41 --> Total execution time: 0.0370
DEBUG - 2013-09-01 04:13:54 --> Config Class Initialized
DEBUG - 2013-09-01 04:13:54 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:13:54 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:13:54 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:13:54 --> URI Class Initialized
DEBUG - 2013-09-01 04:13:54 --> Router Class Initialized
DEBUG - 2013-09-01 04:13:54 --> No URI present. Default controller set.
DEBUG - 2013-09-01 04:13:54 --> Output Class Initialized
DEBUG - 2013-09-01 04:13:54 --> Security Class Initialized
DEBUG - 2013-09-01 04:13:54 --> Input Class Initialized
DEBUG - 2013-09-01 04:13:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:13:54 --> Language Class Initialized
DEBUG - 2013-09-01 04:13:54 --> Loader Class Initialized
DEBUG - 2013-09-01 04:13:54 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:13:54 --> Controller Class Initialized
DEBUG - 2013-09-01 04:13:54 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:13:54 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:13:54 --> Model Class Initialized
DEBUG - 2013-09-01 04:13:54 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:13:54 --> Model Class Initialized
DEBUG - 2013-09-01 04:13:54 --> File loaded: application/views/index.php
DEBUG - 2013-09-01 04:13:54 --> Final output sent to browser
DEBUG - 2013-09-01 04:13:54 --> Total execution time: 0.0340
DEBUG - 2013-09-01 04:13:55 --> Config Class Initialized
DEBUG - 2013-09-01 04:13:55 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:13:55 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:13:55 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:13:55 --> URI Class Initialized
DEBUG - 2013-09-01 04:13:55 --> Router Class Initialized
DEBUG - 2013-09-01 04:13:55 --> Output Class Initialized
DEBUG - 2013-09-01 04:13:55 --> Security Class Initialized
DEBUG - 2013-09-01 04:13:55 --> Input Class Initialized
DEBUG - 2013-09-01 04:13:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:13:55 --> Language Class Initialized
DEBUG - 2013-09-01 04:13:55 --> Loader Class Initialized
DEBUG - 2013-09-01 04:13:55 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:13:55 --> Controller Class Initialized
DEBUG - 2013-09-01 04:13:55 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:13:55 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:13:55 --> Model Class Initialized
DEBUG - 2013-09-01 04:13:55 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:13:55 --> Model Class Initialized
DEBUG - 2013-09-01 04:13:55 --> File loaded: application/views/admin.php
DEBUG - 2013-09-01 04:13:55 --> Final output sent to browser
DEBUG - 2013-09-01 04:13:55 --> Total execution time: 0.0340
DEBUG - 2013-09-01 04:13:59 --> Config Class Initialized
DEBUG - 2013-09-01 04:13:59 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:13:59 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:13:59 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:13:59 --> URI Class Initialized
DEBUG - 2013-09-01 04:13:59 --> Router Class Initialized
DEBUG - 2013-09-01 04:13:59 --> Output Class Initialized
DEBUG - 2013-09-01 04:13:59 --> Security Class Initialized
DEBUG - 2013-09-01 04:13:59 --> Input Class Initialized
DEBUG - 2013-09-01 04:13:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:13:59 --> Language Class Initialized
DEBUG - 2013-09-01 04:13:59 --> Loader Class Initialized
DEBUG - 2013-09-01 04:13:59 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:13:59 --> Controller Class Initialized
DEBUG - 2013-09-01 04:13:59 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:13:59 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:13:59 --> Model Class Initialized
DEBUG - 2013-09-01 04:13:59 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:13:59 --> Model Class Initialized
DEBUG - 2013-09-01 04:13:59 --> File loaded: application/views/admin.php
DEBUG - 2013-09-01 04:13:59 --> Final output sent to browser
DEBUG - 2013-09-01 04:13:59 --> Total execution time: 0.0340
DEBUG - 2013-09-01 04:14:03 --> Config Class Initialized
DEBUG - 2013-09-01 04:14:03 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:14:03 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:14:03 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:14:03 --> URI Class Initialized
DEBUG - 2013-09-01 04:14:03 --> Router Class Initialized
DEBUG - 2013-09-01 04:14:03 --> Output Class Initialized
DEBUG - 2013-09-01 04:14:03 --> Security Class Initialized
DEBUG - 2013-09-01 04:14:03 --> Input Class Initialized
DEBUG - 2013-09-01 04:14:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:14:03 --> Language Class Initialized
DEBUG - 2013-09-01 04:14:03 --> Loader Class Initialized
DEBUG - 2013-09-01 04:14:03 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:14:03 --> Controller Class Initialized
DEBUG - 2013-09-01 04:14:03 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:14:03 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:14:03 --> Model Class Initialized
DEBUG - 2013-09-01 04:14:03 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:14:03 --> Model Class Initialized
DEBUG - 2013-09-01 04:14:03 --> File loaded: application/views/admin.php
DEBUG - 2013-09-01 04:14:03 --> Final output sent to browser
DEBUG - 2013-09-01 04:14:03 --> Total execution time: 0.1130
DEBUG - 2013-09-01 04:29:14 --> Config Class Initialized
DEBUG - 2013-09-01 04:29:14 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:29:14 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:29:14 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:29:14 --> URI Class Initialized
DEBUG - 2013-09-01 04:29:14 --> Router Class Initialized
DEBUG - 2013-09-01 04:29:14 --> No URI present. Default controller set.
DEBUG - 2013-09-01 04:29:14 --> Output Class Initialized
DEBUG - 2013-09-01 04:29:14 --> Security Class Initialized
DEBUG - 2013-09-01 04:29:14 --> Input Class Initialized
DEBUG - 2013-09-01 04:29:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:29:14 --> Language Class Initialized
DEBUG - 2013-09-01 04:29:14 --> Loader Class Initialized
DEBUG - 2013-09-01 04:29:14 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:29:14 --> Controller Class Initialized
DEBUG - 2013-09-01 04:29:14 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:29:14 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:29:14 --> Model Class Initialized
DEBUG - 2013-09-01 04:29:14 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:29:14 --> Model Class Initialized
DEBUG - 2013-09-01 04:29:14 --> File loaded: application/views/index.php
DEBUG - 2013-09-01 04:29:14 --> Final output sent to browser
DEBUG - 2013-09-01 04:29:14 --> Total execution time: 0.0380
DEBUG - 2013-09-01 04:29:19 --> Config Class Initialized
DEBUG - 2013-09-01 04:29:19 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:29:19 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:29:19 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:29:19 --> URI Class Initialized
DEBUG - 2013-09-01 04:29:19 --> Router Class Initialized
DEBUG - 2013-09-01 04:29:19 --> Output Class Initialized
DEBUG - 2013-09-01 04:29:19 --> Security Class Initialized
DEBUG - 2013-09-01 04:29:19 --> Input Class Initialized
DEBUG - 2013-09-01 04:29:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:29:19 --> Language Class Initialized
DEBUG - 2013-09-01 04:29:19 --> Loader Class Initialized
DEBUG - 2013-09-01 04:29:19 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:29:19 --> Controller Class Initialized
DEBUG - 2013-09-01 04:29:19 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:29:19 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:29:19 --> Model Class Initialized
DEBUG - 2013-09-01 04:29:19 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:29:19 --> Model Class Initialized
DEBUG - 2013-09-01 04:29:19 --> File loaded: application/views/admin.php
DEBUG - 2013-09-01 04:29:19 --> Final output sent to browser
DEBUG - 2013-09-01 04:29:19 --> Total execution time: 0.0630
DEBUG - 2013-09-01 04:29:21 --> Config Class Initialized
DEBUG - 2013-09-01 04:29:21 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:29:21 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:29:21 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:29:21 --> URI Class Initialized
DEBUG - 2013-09-01 04:29:21 --> Router Class Initialized
DEBUG - 2013-09-01 04:29:21 --> Output Class Initialized
DEBUG - 2013-09-01 04:29:21 --> Security Class Initialized
DEBUG - 2013-09-01 04:29:21 --> Input Class Initialized
DEBUG - 2013-09-01 04:29:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:29:21 --> Language Class Initialized
DEBUG - 2013-09-01 04:29:21 --> Loader Class Initialized
DEBUG - 2013-09-01 04:29:21 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:29:21 --> Controller Class Initialized
DEBUG - 2013-09-01 04:29:21 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:29:21 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:29:21 --> Model Class Initialized
DEBUG - 2013-09-01 04:29:21 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:29:21 --> Model Class Initialized
DEBUG - 2013-09-01 04:29:21 --> File loaded: application/views/admin.php
DEBUG - 2013-09-01 04:29:21 --> Final output sent to browser
DEBUG - 2013-09-01 04:29:21 --> Total execution time: 0.0360
DEBUG - 2013-09-01 04:29:31 --> Config Class Initialized
DEBUG - 2013-09-01 04:29:31 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:29:31 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:29:31 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:29:31 --> URI Class Initialized
DEBUG - 2013-09-01 04:29:31 --> Router Class Initialized
DEBUG - 2013-09-01 04:29:31 --> Output Class Initialized
DEBUG - 2013-09-01 04:29:31 --> Security Class Initialized
DEBUG - 2013-09-01 04:29:31 --> Input Class Initialized
DEBUG - 2013-09-01 04:29:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:29:31 --> Language Class Initialized
DEBUG - 2013-09-01 04:29:31 --> Loader Class Initialized
DEBUG - 2013-09-01 04:29:31 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:29:31 --> Controller Class Initialized
DEBUG - 2013-09-01 04:29:31 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:29:31 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:29:31 --> Model Class Initialized
DEBUG - 2013-09-01 04:29:31 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:29:31 --> Model Class Initialized
DEBUG - 2013-09-01 04:29:31 --> File loaded: application/views/admin.php
DEBUG - 2013-09-01 04:29:31 --> Final output sent to browser
DEBUG - 2013-09-01 04:29:31 --> Total execution time: 0.0330
DEBUG - 2013-09-01 04:29:36 --> Config Class Initialized
DEBUG - 2013-09-01 04:29:36 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:29:36 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:29:36 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:29:36 --> URI Class Initialized
DEBUG - 2013-09-01 04:29:36 --> Router Class Initialized
DEBUG - 2013-09-01 04:29:36 --> Output Class Initialized
DEBUG - 2013-09-01 04:29:36 --> Security Class Initialized
DEBUG - 2013-09-01 04:29:36 --> Input Class Initialized
DEBUG - 2013-09-01 04:29:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:29:36 --> Language Class Initialized
DEBUG - 2013-09-01 04:29:36 --> Loader Class Initialized
DEBUG - 2013-09-01 04:29:36 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:29:36 --> Controller Class Initialized
DEBUG - 2013-09-01 04:29:36 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:29:36 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:29:36 --> Model Class Initialized
DEBUG - 2013-09-01 04:29:36 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:29:36 --> Model Class Initialized
DEBUG - 2013-09-01 04:29:36 --> Model Class Initialized
DEBUG - 2013-09-01 04:29:36 --> XSS Filtering completed
DEBUG - 2013-09-01 04:29:36 --> XSS Filtering completed
DEBUG - 2013-09-01 04:29:36 --> Config Class Initialized
DEBUG - 2013-09-01 04:29:36 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:29:36 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:29:36 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:29:36 --> URI Class Initialized
DEBUG - 2013-09-01 04:29:36 --> Config Class Initialized
DEBUG - 2013-09-01 04:29:36 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:29:36 --> Router Class Initialized
DEBUG - 2013-09-01 04:29:36 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:29:36 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:29:36 --> Output Class Initialized
DEBUG - 2013-09-01 04:29:36 --> URI Class Initialized
DEBUG - 2013-09-01 04:29:36 --> Security Class Initialized
DEBUG - 2013-09-01 04:29:36 --> Router Class Initialized
DEBUG - 2013-09-01 04:29:36 --> Input Class Initialized
DEBUG - 2013-09-01 04:29:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:29:36 --> Output Class Initialized
DEBUG - 2013-09-01 04:29:36 --> Language Class Initialized
DEBUG - 2013-09-01 04:29:36 --> Security Class Initialized
DEBUG - 2013-09-01 04:29:36 --> Input Class Initialized
DEBUG - 2013-09-01 04:29:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:29:36 --> Language Class Initialized
DEBUG - 2013-09-01 04:29:36 --> Loader Class Initialized
DEBUG - 2013-09-01 04:29:36 --> Loader Class Initialized
DEBUG - 2013-09-01 04:29:36 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:29:36 --> Controller Class Initialized
DEBUG - 2013-09-01 04:29:36 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:29:36 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:29:36 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:29:36 --> Controller Class Initialized
DEBUG - 2013-09-01 04:29:36 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:29:36 --> Model Class Initialized
DEBUG - 2013-09-01 04:29:36 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:29:36 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:29:36 --> Model Class Initialized
DEBUG - 2013-09-01 04:29:36 --> Model Class Initialized
DEBUG - 2013-09-01 04:29:36 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:29:36 --> Model Class Initialized
DEBUG - 2013-09-01 04:29:36 --> Model Class Initialized
DEBUG - 2013-09-01 04:29:36 --> XSS Filtering completed
DEBUG - 2013-09-01 04:29:36 --> XSS Filtering completed
DEBUG - 2013-09-01 04:29:36 --> XSS Filtering completed
DEBUG - 2013-09-01 04:29:36 --> Model Class Initialized
DEBUG - 2013-09-01 04:29:36 --> XSS Filtering completed
DEBUG - 2013-09-01 04:29:36 --> XSS Filtering completed
ERROR - 2013-09-01 04:29:36 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 185
ERROR - 2013-09-01 04:29:36 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-01 04:29:36 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-01 04:29:36 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 195
DEBUG - 2013-09-01 04:29:38 --> Config Class Initialized
DEBUG - 2013-09-01 04:29:38 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:29:38 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:29:38 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:29:38 --> URI Class Initialized
DEBUG - 2013-09-01 04:29:38 --> Router Class Initialized
DEBUG - 2013-09-01 04:29:38 --> Output Class Initialized
DEBUG - 2013-09-01 04:29:38 --> Security Class Initialized
DEBUG - 2013-09-01 04:29:38 --> Input Class Initialized
DEBUG - 2013-09-01 04:29:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:29:38 --> Language Class Initialized
DEBUG - 2013-09-01 04:29:38 --> Loader Class Initialized
DEBUG - 2013-09-01 04:29:38 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:29:38 --> Controller Class Initialized
DEBUG - 2013-09-01 04:29:38 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:29:38 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:29:38 --> Model Class Initialized
DEBUG - 2013-09-01 04:29:38 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:29:38 --> Model Class Initialized
DEBUG - 2013-09-01 04:29:38 --> Model Class Initialized
DEBUG - 2013-09-01 04:29:38 --> XSS Filtering completed
DEBUG - 2013-09-01 04:29:58 --> Config Class Initialized
DEBUG - 2013-09-01 04:29:58 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:29:58 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:29:58 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:29:58 --> URI Class Initialized
DEBUG - 2013-09-01 04:29:58 --> Router Class Initialized
DEBUG - 2013-09-01 04:29:58 --> Output Class Initialized
DEBUG - 2013-09-01 04:29:58 --> Security Class Initialized
DEBUG - 2013-09-01 04:29:58 --> Input Class Initialized
DEBUG - 2013-09-01 04:29:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:29:58 --> Language Class Initialized
DEBUG - 2013-09-01 04:29:58 --> Loader Class Initialized
DEBUG - 2013-09-01 04:29:58 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:29:58 --> Controller Class Initialized
DEBUG - 2013-09-01 04:29:58 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:29:58 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:29:58 --> Model Class Initialized
DEBUG - 2013-09-01 04:29:58 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:29:58 --> Model Class Initialized
DEBUG - 2013-09-01 04:29:58 --> Model Class Initialized
DEBUG - 2013-09-01 04:29:58 --> XSS Filtering completed
DEBUG - 2013-09-01 04:29:58 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:00 --> Config Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:30:00 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:30:00 --> URI Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Router Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Output Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Security Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Input Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:30:00 --> Language Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Loader Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Controller Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:30:00 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:30:00 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:30:00 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:00 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:00 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:00 --> Config Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:30:00 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:30:00 --> URI Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Router Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Output Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Security Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Input Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:30:00 --> Language Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Loader Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Controller Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:30:00 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:30:00 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:30:00 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:00 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:00 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:00 --> Config Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:30:00 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:30:00 --> URI Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Router Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Output Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Security Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Input Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:30:00 --> Language Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Loader Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Controller Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:30:00 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:30:00 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:30:00 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:00 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:00 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:00 --> Config Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:30:00 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:30:00 --> URI Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Router Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Output Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Security Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Input Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:30:00 --> Language Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Loader Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Controller Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:30:00 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:30:00 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:30:00 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:00 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:00 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:00 --> Config Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:30:00 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:30:00 --> URI Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Router Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Output Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Security Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Input Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:30:00 --> Language Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Loader Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Controller Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:30:00 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:30:00 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:30:00 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:00 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:00 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:00 --> Config Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:30:00 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:30:00 --> URI Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Router Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Output Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Security Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Input Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:30:00 --> Language Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Loader Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Controller Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:30:00 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:30:00 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:30:00 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:00 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:00 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:00 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:01 --> Config Class Initialized
DEBUG - 2013-09-01 04:30:01 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:30:01 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:30:01 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:30:01 --> URI Class Initialized
DEBUG - 2013-09-01 04:30:01 --> Router Class Initialized
DEBUG - 2013-09-01 04:30:01 --> Output Class Initialized
DEBUG - 2013-09-01 04:30:01 --> Security Class Initialized
DEBUG - 2013-09-01 04:30:01 --> Input Class Initialized
DEBUG - 2013-09-01 04:30:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:30:01 --> Language Class Initialized
DEBUG - 2013-09-01 04:30:01 --> Loader Class Initialized
DEBUG - 2013-09-01 04:30:01 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:30:01 --> Controller Class Initialized
DEBUG - 2013-09-01 04:30:01 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:30:01 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:30:01 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:01 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:30:01 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:01 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:01 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:01 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:02 --> Config Class Initialized
DEBUG - 2013-09-01 04:30:02 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:30:02 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:30:02 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:30:02 --> URI Class Initialized
DEBUG - 2013-09-01 04:30:02 --> Router Class Initialized
DEBUG - 2013-09-01 04:30:02 --> Output Class Initialized
DEBUG - 2013-09-01 04:30:02 --> Security Class Initialized
DEBUG - 2013-09-01 04:30:02 --> Input Class Initialized
DEBUG - 2013-09-01 04:30:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:30:02 --> Language Class Initialized
DEBUG - 2013-09-01 04:30:02 --> Loader Class Initialized
DEBUG - 2013-09-01 04:30:02 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:30:02 --> Controller Class Initialized
DEBUG - 2013-09-01 04:30:02 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:30:02 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:30:02 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:02 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:30:02 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:02 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:02 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:02 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:04 --> Config Class Initialized
DEBUG - 2013-09-01 04:30:04 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:30:04 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:30:04 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:30:04 --> URI Class Initialized
DEBUG - 2013-09-01 04:30:04 --> Router Class Initialized
DEBUG - 2013-09-01 04:30:04 --> Output Class Initialized
DEBUG - 2013-09-01 04:30:04 --> Security Class Initialized
DEBUG - 2013-09-01 04:30:04 --> Input Class Initialized
DEBUG - 2013-09-01 04:30:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:30:04 --> Language Class Initialized
DEBUG - 2013-09-01 04:30:04 --> Loader Class Initialized
DEBUG - 2013-09-01 04:30:04 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:30:04 --> Controller Class Initialized
DEBUG - 2013-09-01 04:30:04 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:30:04 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:30:04 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:04 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:30:04 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:04 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:04 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:04 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:05 --> Config Class Initialized
DEBUG - 2013-09-01 04:30:05 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:30:05 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:30:05 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:30:05 --> URI Class Initialized
DEBUG - 2013-09-01 04:30:05 --> Router Class Initialized
DEBUG - 2013-09-01 04:30:05 --> Output Class Initialized
DEBUG - 2013-09-01 04:30:05 --> Security Class Initialized
DEBUG - 2013-09-01 04:30:05 --> Input Class Initialized
DEBUG - 2013-09-01 04:30:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:30:05 --> Language Class Initialized
DEBUG - 2013-09-01 04:30:05 --> Loader Class Initialized
DEBUG - 2013-09-01 04:30:05 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:30:05 --> Controller Class Initialized
DEBUG - 2013-09-01 04:30:05 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:30:05 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:30:05 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:05 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:30:05 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:05 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:05 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:05 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:06 --> Config Class Initialized
DEBUG - 2013-09-01 04:30:06 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:30:06 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:30:06 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:30:06 --> URI Class Initialized
DEBUG - 2013-09-01 04:30:06 --> Router Class Initialized
DEBUG - 2013-09-01 04:30:06 --> Output Class Initialized
DEBUG - 2013-09-01 04:30:06 --> Security Class Initialized
DEBUG - 2013-09-01 04:30:06 --> Input Class Initialized
DEBUG - 2013-09-01 04:30:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:30:06 --> Language Class Initialized
DEBUG - 2013-09-01 04:30:06 --> Loader Class Initialized
DEBUG - 2013-09-01 04:30:06 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:30:06 --> Controller Class Initialized
DEBUG - 2013-09-01 04:30:06 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:30:06 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:30:06 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:06 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:30:06 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:06 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:06 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:06 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:06 --> Config Class Initialized
DEBUG - 2013-09-01 04:30:06 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:30:06 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:30:06 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:30:06 --> URI Class Initialized
DEBUG - 2013-09-01 04:30:06 --> Router Class Initialized
DEBUG - 2013-09-01 04:30:06 --> Output Class Initialized
DEBUG - 2013-09-01 04:30:06 --> Security Class Initialized
DEBUG - 2013-09-01 04:30:06 --> Input Class Initialized
DEBUG - 2013-09-01 04:30:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:30:06 --> Language Class Initialized
DEBUG - 2013-09-01 04:30:06 --> Loader Class Initialized
DEBUG - 2013-09-01 04:30:06 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:30:06 --> Controller Class Initialized
DEBUG - 2013-09-01 04:30:06 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:30:06 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:30:06 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:06 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:30:06 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:06 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:06 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:06 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:06 --> Config Class Initialized
DEBUG - 2013-09-01 04:30:06 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:30:06 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:30:06 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:30:06 --> URI Class Initialized
DEBUG - 2013-09-01 04:30:06 --> Router Class Initialized
DEBUG - 2013-09-01 04:30:06 --> Output Class Initialized
DEBUG - 2013-09-01 04:30:06 --> Security Class Initialized
DEBUG - 2013-09-01 04:30:06 --> Input Class Initialized
DEBUG - 2013-09-01 04:30:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:30:06 --> Language Class Initialized
DEBUG - 2013-09-01 04:30:06 --> Loader Class Initialized
DEBUG - 2013-09-01 04:30:06 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:30:06 --> Controller Class Initialized
DEBUG - 2013-09-01 04:30:06 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:30:06 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:30:06 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:06 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:30:06 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:06 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:06 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:06 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:07 --> Config Class Initialized
DEBUG - 2013-09-01 04:30:07 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:30:07 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:30:07 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:30:07 --> URI Class Initialized
DEBUG - 2013-09-01 04:30:07 --> Router Class Initialized
DEBUG - 2013-09-01 04:30:07 --> Output Class Initialized
DEBUG - 2013-09-01 04:30:07 --> Security Class Initialized
DEBUG - 2013-09-01 04:30:07 --> Input Class Initialized
DEBUG - 2013-09-01 04:30:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:30:07 --> Language Class Initialized
DEBUG - 2013-09-01 04:30:07 --> Loader Class Initialized
DEBUG - 2013-09-01 04:30:07 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:30:07 --> Controller Class Initialized
DEBUG - 2013-09-01 04:30:07 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:30:07 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:30:07 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:07 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:30:07 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:07 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:07 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:07 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:07 --> Config Class Initialized
DEBUG - 2013-09-01 04:30:07 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:30:07 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:30:07 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:30:07 --> URI Class Initialized
DEBUG - 2013-09-01 04:30:07 --> Router Class Initialized
DEBUG - 2013-09-01 04:30:07 --> Output Class Initialized
DEBUG - 2013-09-01 04:30:07 --> Security Class Initialized
DEBUG - 2013-09-01 04:30:07 --> Input Class Initialized
DEBUG - 2013-09-01 04:30:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:30:07 --> Language Class Initialized
DEBUG - 2013-09-01 04:30:07 --> Loader Class Initialized
DEBUG - 2013-09-01 04:30:07 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:30:07 --> Controller Class Initialized
DEBUG - 2013-09-01 04:30:07 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:30:07 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:30:07 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:07 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:30:07 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:07 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:07 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:07 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:09 --> Config Class Initialized
DEBUG - 2013-09-01 04:30:09 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:30:09 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:30:09 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:30:09 --> URI Class Initialized
DEBUG - 2013-09-01 04:30:09 --> Router Class Initialized
DEBUG - 2013-09-01 04:30:09 --> Output Class Initialized
DEBUG - 2013-09-01 04:30:09 --> Security Class Initialized
DEBUG - 2013-09-01 04:30:09 --> Input Class Initialized
DEBUG - 2013-09-01 04:30:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:30:09 --> Language Class Initialized
DEBUG - 2013-09-01 04:30:09 --> Loader Class Initialized
DEBUG - 2013-09-01 04:30:09 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:30:09 --> Controller Class Initialized
DEBUG - 2013-09-01 04:30:09 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:30:09 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:30:09 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:09 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:30:09 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:09 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:09 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:09 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:10 --> Config Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:30:10 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:30:10 --> URI Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Router Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Output Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Security Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Input Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:30:10 --> Language Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Loader Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Controller Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:30:10 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:30:10 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:30:10 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:10 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:10 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:10 --> Config Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:30:10 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:30:10 --> URI Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Router Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Output Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Security Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Input Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:30:10 --> Language Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Loader Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Controller Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:30:10 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:30:10 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:30:10 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:10 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:10 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:10 --> Config Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:30:10 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:30:10 --> URI Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Router Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Output Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Security Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Input Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:30:10 --> Language Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Loader Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Controller Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:30:10 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:30:10 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:30:10 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:10 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:10 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:10 --> Config Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:30:10 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:30:10 --> URI Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Router Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Output Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Security Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Input Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:30:10 --> Language Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Loader Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Controller Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:30:10 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:30:10 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:30:10 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:10 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:10 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:10 --> Config Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:30:10 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:30:10 --> URI Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Router Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Output Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Security Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Input Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:30:10 --> Language Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Loader Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Controller Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:30:10 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:30:10 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:30:10 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:10 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:10 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:10 --> Config Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:30:10 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:30:10 --> URI Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Router Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Output Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Security Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Input Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:30:10 --> Language Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Loader Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Controller Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:30:10 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:30:10 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:30:10 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:10 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:10 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:10 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:11 --> Config Class Initialized
DEBUG - 2013-09-01 04:30:11 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:30:11 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:30:11 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:30:11 --> URI Class Initialized
DEBUG - 2013-09-01 04:30:11 --> Router Class Initialized
DEBUG - 2013-09-01 04:30:11 --> Output Class Initialized
DEBUG - 2013-09-01 04:30:11 --> Security Class Initialized
DEBUG - 2013-09-01 04:30:11 --> Input Class Initialized
DEBUG - 2013-09-01 04:30:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:30:11 --> Language Class Initialized
DEBUG - 2013-09-01 04:30:11 --> Loader Class Initialized
DEBUG - 2013-09-01 04:30:11 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:30:11 --> Controller Class Initialized
DEBUG - 2013-09-01 04:30:11 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:30:11 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:30:11 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:11 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:30:11 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:11 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:11 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:11 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:11 --> Config Class Initialized
DEBUG - 2013-09-01 04:30:11 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:30:11 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:30:11 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:30:11 --> URI Class Initialized
DEBUG - 2013-09-01 04:30:11 --> Router Class Initialized
DEBUG - 2013-09-01 04:30:11 --> Output Class Initialized
DEBUG - 2013-09-01 04:30:11 --> Security Class Initialized
DEBUG - 2013-09-01 04:30:11 --> Input Class Initialized
DEBUG - 2013-09-01 04:30:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:30:11 --> Language Class Initialized
DEBUG - 2013-09-01 04:30:11 --> Loader Class Initialized
DEBUG - 2013-09-01 04:30:11 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:30:11 --> Controller Class Initialized
DEBUG - 2013-09-01 04:30:11 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:30:12 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:30:12 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:12 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:30:12 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:12 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:12 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:12 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:12 --> Config Class Initialized
DEBUG - 2013-09-01 04:30:12 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:30:12 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:30:12 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:30:12 --> URI Class Initialized
DEBUG - 2013-09-01 04:30:12 --> Router Class Initialized
DEBUG - 2013-09-01 04:30:12 --> Output Class Initialized
DEBUG - 2013-09-01 04:30:12 --> Security Class Initialized
DEBUG - 2013-09-01 04:30:12 --> Input Class Initialized
DEBUG - 2013-09-01 04:30:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:30:12 --> Language Class Initialized
DEBUG - 2013-09-01 04:30:12 --> Loader Class Initialized
DEBUG - 2013-09-01 04:30:12 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:30:12 --> Controller Class Initialized
DEBUG - 2013-09-01 04:30:12 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:30:12 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:30:12 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:12 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:30:12 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:12 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:12 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:12 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:13 --> Config Class Initialized
DEBUG - 2013-09-01 04:30:13 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:30:13 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:30:13 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:30:13 --> URI Class Initialized
DEBUG - 2013-09-01 04:30:13 --> Router Class Initialized
DEBUG - 2013-09-01 04:30:13 --> Output Class Initialized
DEBUG - 2013-09-01 04:30:13 --> Security Class Initialized
DEBUG - 2013-09-01 04:30:13 --> Input Class Initialized
DEBUG - 2013-09-01 04:30:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:30:13 --> Language Class Initialized
DEBUG - 2013-09-01 04:30:13 --> Loader Class Initialized
DEBUG - 2013-09-01 04:30:13 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:30:13 --> Controller Class Initialized
DEBUG - 2013-09-01 04:30:13 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:30:13 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:30:13 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:13 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:30:13 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:13 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:13 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:13 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:13 --> Config Class Initialized
DEBUG - 2013-09-01 04:30:13 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:30:13 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:30:13 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:30:13 --> URI Class Initialized
DEBUG - 2013-09-01 04:30:13 --> Router Class Initialized
DEBUG - 2013-09-01 04:30:13 --> Output Class Initialized
DEBUG - 2013-09-01 04:30:13 --> Security Class Initialized
DEBUG - 2013-09-01 04:30:13 --> Input Class Initialized
DEBUG - 2013-09-01 04:30:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:30:13 --> Language Class Initialized
DEBUG - 2013-09-01 04:30:13 --> Loader Class Initialized
DEBUG - 2013-09-01 04:30:13 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:30:13 --> Controller Class Initialized
DEBUG - 2013-09-01 04:30:13 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:30:13 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:30:13 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:13 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:30:13 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:13 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:13 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:13 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:42 --> Config Class Initialized
DEBUG - 2013-09-01 04:30:42 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:30:42 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:30:42 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:30:42 --> URI Class Initialized
DEBUG - 2013-09-01 04:30:42 --> Router Class Initialized
DEBUG - 2013-09-01 04:30:42 --> Output Class Initialized
DEBUG - 2013-09-01 04:30:42 --> Security Class Initialized
DEBUG - 2013-09-01 04:30:42 --> Input Class Initialized
DEBUG - 2013-09-01 04:30:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:30:42 --> Language Class Initialized
DEBUG - 2013-09-01 04:30:42 --> Loader Class Initialized
DEBUG - 2013-09-01 04:30:42 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:30:42 --> Controller Class Initialized
DEBUG - 2013-09-01 04:30:42 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:30:42 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:30:42 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:42 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:30:42 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:42 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:42 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:42 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:43 --> Config Class Initialized
DEBUG - 2013-09-01 04:30:43 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:30:43 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:30:43 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:30:43 --> URI Class Initialized
DEBUG - 2013-09-01 04:30:43 --> Router Class Initialized
DEBUG - 2013-09-01 04:30:43 --> Output Class Initialized
DEBUG - 2013-09-01 04:30:43 --> Security Class Initialized
DEBUG - 2013-09-01 04:30:43 --> Input Class Initialized
DEBUG - 2013-09-01 04:30:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:30:43 --> Language Class Initialized
DEBUG - 2013-09-01 04:30:43 --> Loader Class Initialized
DEBUG - 2013-09-01 04:30:43 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:30:43 --> Controller Class Initialized
DEBUG - 2013-09-01 04:30:43 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:30:43 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:30:43 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:43 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:30:43 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:43 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:43 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:43 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:43 --> Config Class Initialized
DEBUG - 2013-09-01 04:30:43 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:30:43 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:30:43 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:30:43 --> URI Class Initialized
DEBUG - 2013-09-01 04:30:43 --> Router Class Initialized
DEBUG - 2013-09-01 04:30:43 --> Output Class Initialized
DEBUG - 2013-09-01 04:30:43 --> Security Class Initialized
DEBUG - 2013-09-01 04:30:43 --> Input Class Initialized
DEBUG - 2013-09-01 04:30:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:30:43 --> Language Class Initialized
DEBUG - 2013-09-01 04:30:43 --> Loader Class Initialized
DEBUG - 2013-09-01 04:30:43 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:30:43 --> Controller Class Initialized
DEBUG - 2013-09-01 04:30:43 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:30:43 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:30:43 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:43 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:30:43 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:43 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:43 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:43 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:44 --> Config Class Initialized
DEBUG - 2013-09-01 04:30:44 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:30:44 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:30:44 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:30:44 --> URI Class Initialized
DEBUG - 2013-09-01 04:30:44 --> Router Class Initialized
DEBUG - 2013-09-01 04:30:44 --> Output Class Initialized
DEBUG - 2013-09-01 04:30:44 --> Security Class Initialized
DEBUG - 2013-09-01 04:30:44 --> Input Class Initialized
DEBUG - 2013-09-01 04:30:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:30:44 --> Language Class Initialized
DEBUG - 2013-09-01 04:30:44 --> Loader Class Initialized
DEBUG - 2013-09-01 04:30:44 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:30:44 --> Controller Class Initialized
DEBUG - 2013-09-01 04:30:44 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:30:44 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:30:44 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:44 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:30:44 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:44 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:44 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:44 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:44 --> Config Class Initialized
DEBUG - 2013-09-01 04:30:44 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:30:44 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:30:44 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:30:44 --> URI Class Initialized
DEBUG - 2013-09-01 04:30:44 --> Router Class Initialized
DEBUG - 2013-09-01 04:30:44 --> Output Class Initialized
DEBUG - 2013-09-01 04:30:44 --> Security Class Initialized
DEBUG - 2013-09-01 04:30:44 --> Input Class Initialized
DEBUG - 2013-09-01 04:30:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:30:44 --> Language Class Initialized
DEBUG - 2013-09-01 04:30:44 --> Loader Class Initialized
DEBUG - 2013-09-01 04:30:44 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:30:44 --> Controller Class Initialized
DEBUG - 2013-09-01 04:30:44 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:30:44 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:30:44 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:44 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:30:44 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:44 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:44 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:44 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:44 --> Config Class Initialized
DEBUG - 2013-09-01 04:30:44 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:30:44 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:30:44 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:30:44 --> URI Class Initialized
DEBUG - 2013-09-01 04:30:44 --> Router Class Initialized
DEBUG - 2013-09-01 04:30:44 --> Output Class Initialized
DEBUG - 2013-09-01 04:30:44 --> Security Class Initialized
DEBUG - 2013-09-01 04:30:44 --> Input Class Initialized
DEBUG - 2013-09-01 04:30:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:30:44 --> Language Class Initialized
DEBUG - 2013-09-01 04:30:44 --> Loader Class Initialized
DEBUG - 2013-09-01 04:30:44 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:30:44 --> Controller Class Initialized
DEBUG - 2013-09-01 04:30:44 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:30:44 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:30:44 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:44 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:30:44 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:44 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:44 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:44 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:45 --> Config Class Initialized
DEBUG - 2013-09-01 04:30:45 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:30:45 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:30:45 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:30:45 --> URI Class Initialized
DEBUG - 2013-09-01 04:30:45 --> Router Class Initialized
DEBUG - 2013-09-01 04:30:45 --> Output Class Initialized
DEBUG - 2013-09-01 04:30:45 --> Security Class Initialized
DEBUG - 2013-09-01 04:30:45 --> Input Class Initialized
DEBUG - 2013-09-01 04:30:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:30:45 --> Language Class Initialized
DEBUG - 2013-09-01 04:30:45 --> Loader Class Initialized
DEBUG - 2013-09-01 04:30:45 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:30:45 --> Controller Class Initialized
DEBUG - 2013-09-01 04:30:45 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:30:45 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:30:45 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:45 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:30:45 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:45 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:45 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:45 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:45 --> Config Class Initialized
DEBUG - 2013-09-01 04:30:45 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:30:45 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:30:45 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:30:45 --> URI Class Initialized
DEBUG - 2013-09-01 04:30:45 --> Router Class Initialized
DEBUG - 2013-09-01 04:30:45 --> Output Class Initialized
DEBUG - 2013-09-01 04:30:45 --> Security Class Initialized
DEBUG - 2013-09-01 04:30:45 --> Input Class Initialized
DEBUG - 2013-09-01 04:30:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:30:45 --> Language Class Initialized
DEBUG - 2013-09-01 04:30:45 --> Loader Class Initialized
DEBUG - 2013-09-01 04:30:45 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:30:45 --> Controller Class Initialized
DEBUG - 2013-09-01 04:30:45 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:30:45 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:30:45 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:45 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:30:45 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:45 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:45 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:45 --> XSS Filtering completed
DEBUG - 2013-09-01 04:30:53 --> Config Class Initialized
DEBUG - 2013-09-01 04:30:53 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:30:53 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:30:53 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:30:53 --> URI Class Initialized
DEBUG - 2013-09-01 04:30:53 --> Router Class Initialized
DEBUG - 2013-09-01 04:30:53 --> No URI present. Default controller set.
DEBUG - 2013-09-01 04:30:53 --> Output Class Initialized
DEBUG - 2013-09-01 04:30:53 --> Security Class Initialized
DEBUG - 2013-09-01 04:30:53 --> Input Class Initialized
DEBUG - 2013-09-01 04:30:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:30:53 --> Language Class Initialized
DEBUG - 2013-09-01 04:30:53 --> Loader Class Initialized
DEBUG - 2013-09-01 04:30:53 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:30:53 --> Controller Class Initialized
DEBUG - 2013-09-01 04:30:53 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:30:53 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:30:53 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:53 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:30:53 --> Model Class Initialized
DEBUG - 2013-09-01 04:30:53 --> File loaded: application/views/index.php
DEBUG - 2013-09-01 04:30:53 --> Final output sent to browser
DEBUG - 2013-09-01 04:30:53 --> Total execution time: 0.2250
DEBUG - 2013-09-01 04:32:24 --> Config Class Initialized
DEBUG - 2013-09-01 04:32:24 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:32:24 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:32:24 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:32:24 --> URI Class Initialized
DEBUG - 2013-09-01 04:32:24 --> Router Class Initialized
DEBUG - 2013-09-01 04:32:24 --> Output Class Initialized
DEBUG - 2013-09-01 04:32:24 --> Security Class Initialized
DEBUG - 2013-09-01 04:32:24 --> Input Class Initialized
DEBUG - 2013-09-01 04:32:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:32:24 --> Language Class Initialized
DEBUG - 2013-09-01 04:32:24 --> Loader Class Initialized
DEBUG - 2013-09-01 04:32:24 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:32:24 --> Controller Class Initialized
DEBUG - 2013-09-01 04:32:24 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:32:24 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:32:24 --> Model Class Initialized
DEBUG - 2013-09-01 04:32:24 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:32:24 --> Model Class Initialized
DEBUG - 2013-09-01 04:32:24 --> Model Class Initialized
DEBUG - 2013-09-01 04:32:24 --> XSS Filtering completed
DEBUG - 2013-09-01 04:32:24 --> XSS Filtering completed
DEBUG - 2013-09-01 04:32:25 --> Config Class Initialized
DEBUG - 2013-09-01 04:32:25 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:32:25 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:32:25 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:32:25 --> URI Class Initialized
DEBUG - 2013-09-01 04:32:25 --> Router Class Initialized
DEBUG - 2013-09-01 04:32:25 --> Output Class Initialized
DEBUG - 2013-09-01 04:32:25 --> Security Class Initialized
DEBUG - 2013-09-01 04:32:25 --> Input Class Initialized
DEBUG - 2013-09-01 04:32:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:32:25 --> Language Class Initialized
DEBUG - 2013-09-01 04:32:25 --> Loader Class Initialized
DEBUG - 2013-09-01 04:32:25 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:32:25 --> Controller Class Initialized
DEBUG - 2013-09-01 04:32:25 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:32:25 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:32:25 --> Model Class Initialized
DEBUG - 2013-09-01 04:32:25 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:32:25 --> Model Class Initialized
DEBUG - 2013-09-01 04:32:25 --> Model Class Initialized
DEBUG - 2013-09-01 04:32:25 --> XSS Filtering completed
DEBUG - 2013-09-01 04:32:25 --> XSS Filtering completed
DEBUG - 2013-09-01 04:32:26 --> Config Class Initialized
DEBUG - 2013-09-01 04:32:26 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:32:26 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:32:26 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:32:26 --> URI Class Initialized
DEBUG - 2013-09-01 04:32:26 --> Router Class Initialized
DEBUG - 2013-09-01 04:32:26 --> Output Class Initialized
DEBUG - 2013-09-01 04:32:26 --> Security Class Initialized
DEBUG - 2013-09-01 04:32:26 --> Input Class Initialized
DEBUG - 2013-09-01 04:32:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:32:26 --> Language Class Initialized
DEBUG - 2013-09-01 04:32:26 --> Loader Class Initialized
DEBUG - 2013-09-01 04:32:26 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:32:26 --> Controller Class Initialized
DEBUG - 2013-09-01 04:32:26 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:32:26 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:32:26 --> Model Class Initialized
DEBUG - 2013-09-01 04:32:26 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:32:26 --> Model Class Initialized
DEBUG - 2013-09-01 04:32:26 --> Model Class Initialized
DEBUG - 2013-09-01 04:32:26 --> XSS Filtering completed
DEBUG - 2013-09-01 04:32:26 --> XSS Filtering completed
DEBUG - 2013-09-01 04:32:27 --> Config Class Initialized
DEBUG - 2013-09-01 04:32:27 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:32:27 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:32:27 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:32:27 --> URI Class Initialized
DEBUG - 2013-09-01 04:32:27 --> Router Class Initialized
DEBUG - 2013-09-01 04:32:27 --> Output Class Initialized
DEBUG - 2013-09-01 04:32:27 --> Security Class Initialized
DEBUG - 2013-09-01 04:32:27 --> Input Class Initialized
DEBUG - 2013-09-01 04:32:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:32:27 --> Language Class Initialized
DEBUG - 2013-09-01 04:32:27 --> Loader Class Initialized
DEBUG - 2013-09-01 04:32:27 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:32:27 --> Controller Class Initialized
DEBUG - 2013-09-01 04:32:27 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:32:27 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:32:27 --> Model Class Initialized
DEBUG - 2013-09-01 04:32:27 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:32:27 --> Model Class Initialized
DEBUG - 2013-09-01 04:32:27 --> Model Class Initialized
DEBUG - 2013-09-01 04:32:27 --> XSS Filtering completed
DEBUG - 2013-09-01 04:32:27 --> XSS Filtering completed
DEBUG - 2013-09-01 04:32:27 --> Config Class Initialized
DEBUG - 2013-09-01 04:32:27 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:32:27 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:32:27 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:32:27 --> Config Class Initialized
DEBUG - 2013-09-01 04:32:27 --> Config Class Initialized
DEBUG - 2013-09-01 04:32:27 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:32:27 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:32:27 --> URI Class Initialized
DEBUG - 2013-09-01 04:32:27 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:32:27 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:32:27 --> Router Class Initialized
DEBUG - 2013-09-01 04:32:27 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:32:27 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:32:27 --> URI Class Initialized
DEBUG - 2013-09-01 04:32:27 --> URI Class Initialized
DEBUG - 2013-09-01 04:32:27 --> Router Class Initialized
DEBUG - 2013-09-01 04:32:27 --> Output Class Initialized
DEBUG - 2013-09-01 04:32:27 --> Router Class Initialized
DEBUG - 2013-09-01 04:32:27 --> Security Class Initialized
DEBUG - 2013-09-01 04:32:27 --> Output Class Initialized
DEBUG - 2013-09-01 04:32:27 --> Output Class Initialized
DEBUG - 2013-09-01 04:32:27 --> Input Class Initialized
DEBUG - 2013-09-01 04:32:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:32:27 --> Security Class Initialized
DEBUG - 2013-09-01 04:32:27 --> Security Class Initialized
DEBUG - 2013-09-01 04:32:27 --> Language Class Initialized
DEBUG - 2013-09-01 04:32:27 --> Input Class Initialized
DEBUG - 2013-09-01 04:32:27 --> Input Class Initialized
DEBUG - 2013-09-01 04:32:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:32:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:32:27 --> Language Class Initialized
DEBUG - 2013-09-01 04:32:27 --> Language Class Initialized
DEBUG - 2013-09-01 04:32:27 --> Loader Class Initialized
DEBUG - 2013-09-01 04:32:27 --> Loader Class Initialized
DEBUG - 2013-09-01 04:32:27 --> Loader Class Initialized
DEBUG - 2013-09-01 04:32:27 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:32:27 --> Controller Class Initialized
DEBUG - 2013-09-01 04:32:27 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:32:27 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:32:27 --> Controller Class Initialized
DEBUG - 2013-09-01 04:32:27 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:32:27 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:32:27 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:32:27 --> Controller Class Initialized
DEBUG - 2013-09-01 04:32:27 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:32:27 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:32:27 --> Model Class Initialized
DEBUG - 2013-09-01 04:32:27 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:32:27 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:32:27 --> Model Class Initialized
DEBUG - 2013-09-01 04:32:27 --> Model Class Initialized
DEBUG - 2013-09-01 04:32:27 --> Model Class Initialized
DEBUG - 2013-09-01 04:32:27 --> Model Class Initialized
DEBUG - 2013-09-01 04:32:27 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:32:27 --> Model Class Initialized
DEBUG - 2013-09-01 04:32:27 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:32:27 --> Model Class Initialized
DEBUG - 2013-09-01 04:32:27 --> Model Class Initialized
DEBUG - 2013-09-01 04:32:27 --> XSS Filtering completed
DEBUG - 2013-09-01 04:32:27 --> Model Class Initialized
DEBUG - 2013-09-01 04:32:27 --> XSS Filtering completed
DEBUG - 2013-09-01 04:32:27 --> XSS Filtering completed
DEBUG - 2013-09-01 04:32:27 --> XSS Filtering completed
DEBUG - 2013-09-01 04:32:27 --> XSS Filtering completed
DEBUG - 2013-09-01 04:32:27 --> XSS Filtering completed
DEBUG - 2013-09-01 04:35:28 --> Config Class Initialized
DEBUG - 2013-09-01 04:35:28 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:35:28 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:35:28 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:35:28 --> URI Class Initialized
DEBUG - 2013-09-01 04:35:28 --> Router Class Initialized
DEBUG - 2013-09-01 04:35:28 --> No URI present. Default controller set.
DEBUG - 2013-09-01 04:35:28 --> Output Class Initialized
DEBUG - 2013-09-01 04:35:28 --> Security Class Initialized
DEBUG - 2013-09-01 04:35:28 --> Input Class Initialized
DEBUG - 2013-09-01 04:35:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:35:28 --> Language Class Initialized
DEBUG - 2013-09-01 04:35:28 --> Loader Class Initialized
DEBUG - 2013-09-01 04:35:28 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:35:28 --> Controller Class Initialized
DEBUG - 2013-09-01 04:35:28 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:35:28 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:35:28 --> Model Class Initialized
DEBUG - 2013-09-01 04:35:28 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:35:28 --> Model Class Initialized
DEBUG - 2013-09-01 04:35:28 --> File loaded: application/views/index.php
DEBUG - 2013-09-01 04:35:28 --> Final output sent to browser
DEBUG - 2013-09-01 04:35:28 --> Total execution time: 0.0640
DEBUG - 2013-09-01 04:35:37 --> Config Class Initialized
DEBUG - 2013-09-01 04:35:37 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:35:37 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:35:37 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:35:37 --> URI Class Initialized
DEBUG - 2013-09-01 04:35:37 --> Router Class Initialized
DEBUG - 2013-09-01 04:35:37 --> Output Class Initialized
DEBUG - 2013-09-01 04:35:37 --> Security Class Initialized
DEBUG - 2013-09-01 04:35:37 --> Input Class Initialized
DEBUG - 2013-09-01 04:35:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:35:37 --> Language Class Initialized
DEBUG - 2013-09-01 04:35:37 --> Loader Class Initialized
DEBUG - 2013-09-01 04:35:37 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:35:37 --> Controller Class Initialized
DEBUG - 2013-09-01 04:35:37 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:35:37 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:35:37 --> Model Class Initialized
DEBUG - 2013-09-01 04:35:37 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:35:37 --> Model Class Initialized
DEBUG - 2013-09-01 04:35:37 --> Model Class Initialized
DEBUG - 2013-09-01 04:35:37 --> XSS Filtering completed
DEBUG - 2013-09-01 04:35:37 --> XSS Filtering completed
DEBUG - 2013-09-01 04:35:37 --> XSS Filtering completed
DEBUG - 2013-09-01 04:35:37 --> XSS Filtering completed
DEBUG - 2013-09-01 04:35:37 --> XSS Filtering completed
DEBUG - 2013-09-01 04:35:37 --> XSS Filtering completed
DEBUG - 2013-09-01 04:35:39 --> Config Class Initialized
DEBUG - 2013-09-01 04:35:39 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:35:39 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:35:39 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:35:39 --> URI Class Initialized
DEBUG - 2013-09-01 04:35:39 --> Router Class Initialized
DEBUG - 2013-09-01 04:35:39 --> Output Class Initialized
DEBUG - 2013-09-01 04:35:39 --> Security Class Initialized
DEBUG - 2013-09-01 04:35:39 --> Input Class Initialized
DEBUG - 2013-09-01 04:35:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:35:39 --> Language Class Initialized
DEBUG - 2013-09-01 04:35:39 --> Loader Class Initialized
DEBUG - 2013-09-01 04:35:39 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:35:39 --> Controller Class Initialized
DEBUG - 2013-09-01 04:35:39 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:35:39 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:35:39 --> Model Class Initialized
DEBUG - 2013-09-01 04:35:39 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:35:39 --> Model Class Initialized
DEBUG - 2013-09-01 04:35:39 --> Model Class Initialized
DEBUG - 2013-09-01 04:35:39 --> XSS Filtering completed
DEBUG - 2013-09-01 04:35:39 --> XSS Filtering completed
DEBUG - 2013-09-01 04:35:41 --> Config Class Initialized
DEBUG - 2013-09-01 04:35:41 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:35:41 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:35:41 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:35:41 --> URI Class Initialized
DEBUG - 2013-09-01 04:35:41 --> Router Class Initialized
DEBUG - 2013-09-01 04:35:41 --> Output Class Initialized
DEBUG - 2013-09-01 04:35:41 --> Security Class Initialized
DEBUG - 2013-09-01 04:35:41 --> Input Class Initialized
DEBUG - 2013-09-01 04:35:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:35:41 --> Language Class Initialized
DEBUG - 2013-09-01 04:35:41 --> Loader Class Initialized
DEBUG - 2013-09-01 04:35:41 --> Config Class Initialized
DEBUG - 2013-09-01 04:35:41 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:35:41 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:35:41 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:35:41 --> URI Class Initialized
DEBUG - 2013-09-01 04:35:41 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:35:41 --> Router Class Initialized
DEBUG - 2013-09-01 04:35:41 --> Controller Class Initialized
DEBUG - 2013-09-01 04:35:41 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:35:41 --> Output Class Initialized
DEBUG - 2013-09-01 04:35:41 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:35:41 --> Security Class Initialized
DEBUG - 2013-09-01 04:35:41 --> Input Class Initialized
DEBUG - 2013-09-01 04:35:41 --> Model Class Initialized
DEBUG - 2013-09-01 04:35:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:35:41 --> Language Class Initialized
DEBUG - 2013-09-01 04:35:41 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:35:41 --> Model Class Initialized
DEBUG - 2013-09-01 04:35:41 --> Model Class Initialized
DEBUG - 2013-09-01 04:35:41 --> XSS Filtering completed
DEBUG - 2013-09-01 04:35:41 --> Loader Class Initialized
DEBUG - 2013-09-01 04:35:41 --> XSS Filtering completed
DEBUG - 2013-09-01 04:35:41 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:35:41 --> Controller Class Initialized
DEBUG - 2013-09-01 04:35:41 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:35:41 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:35:41 --> Model Class Initialized
DEBUG - 2013-09-01 04:35:41 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:35:41 --> Model Class Initialized
DEBUG - 2013-09-01 04:35:41 --> Model Class Initialized
DEBUG - 2013-09-01 04:35:41 --> XSS Filtering completed
DEBUG - 2013-09-01 04:35:41 --> XSS Filtering completed
DEBUG - 2013-09-01 04:35:46 --> Config Class Initialized
DEBUG - 2013-09-01 04:35:46 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:35:46 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:35:46 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:35:46 --> URI Class Initialized
DEBUG - 2013-09-01 04:35:46 --> Router Class Initialized
DEBUG - 2013-09-01 04:35:46 --> Output Class Initialized
DEBUG - 2013-09-01 04:35:46 --> Security Class Initialized
DEBUG - 2013-09-01 04:35:46 --> Input Class Initialized
DEBUG - 2013-09-01 04:35:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:35:46 --> Language Class Initialized
DEBUG - 2013-09-01 04:35:46 --> Loader Class Initialized
DEBUG - 2013-09-01 04:35:46 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:35:46 --> Controller Class Initialized
DEBUG - 2013-09-01 04:35:46 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:35:46 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:35:46 --> Model Class Initialized
DEBUG - 2013-09-01 04:35:46 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:35:46 --> Model Class Initialized
DEBUG - 2013-09-01 04:35:46 --> Model Class Initialized
DEBUG - 2013-09-01 04:35:46 --> XSS Filtering completed
DEBUG - 2013-09-01 04:35:46 --> XSS Filtering completed
DEBUG - 2013-09-01 04:35:51 --> Config Class Initialized
DEBUG - 2013-09-01 04:35:51 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:35:51 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:35:51 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:35:51 --> URI Class Initialized
DEBUG - 2013-09-01 04:35:51 --> Router Class Initialized
DEBUG - 2013-09-01 04:35:51 --> Output Class Initialized
DEBUG - 2013-09-01 04:35:51 --> Security Class Initialized
DEBUG - 2013-09-01 04:35:51 --> Input Class Initialized
DEBUG - 2013-09-01 04:35:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:35:51 --> Language Class Initialized
DEBUG - 2013-09-01 04:35:51 --> Loader Class Initialized
DEBUG - 2013-09-01 04:35:51 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:35:51 --> Controller Class Initialized
DEBUG - 2013-09-01 04:35:51 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:35:51 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:35:51 --> Model Class Initialized
DEBUG - 2013-09-01 04:35:51 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:35:51 --> Model Class Initialized
DEBUG - 2013-09-01 04:35:51 --> Model Class Initialized
DEBUG - 2013-09-01 04:35:51 --> XSS Filtering completed
DEBUG - 2013-09-01 04:35:51 --> XSS Filtering completed
DEBUG - 2013-09-01 04:35:52 --> Config Class Initialized
DEBUG - 2013-09-01 04:35:52 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:35:52 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:35:52 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:35:52 --> URI Class Initialized
DEBUG - 2013-09-01 04:35:52 --> Router Class Initialized
DEBUG - 2013-09-01 04:35:52 --> Output Class Initialized
DEBUG - 2013-09-01 04:35:52 --> Security Class Initialized
DEBUG - 2013-09-01 04:35:52 --> Input Class Initialized
DEBUG - 2013-09-01 04:35:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:35:52 --> Language Class Initialized
DEBUG - 2013-09-01 04:35:52 --> Loader Class Initialized
DEBUG - 2013-09-01 04:35:52 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:35:52 --> Controller Class Initialized
DEBUG - 2013-09-01 04:35:52 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:35:52 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:35:52 --> Model Class Initialized
DEBUG - 2013-09-01 04:35:52 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:35:52 --> Model Class Initialized
DEBUG - 2013-09-01 04:35:52 --> Model Class Initialized
DEBUG - 2013-09-01 04:35:52 --> XSS Filtering completed
DEBUG - 2013-09-01 04:35:52 --> XSS Filtering completed
DEBUG - 2013-09-01 04:58:17 --> Config Class Initialized
DEBUG - 2013-09-01 04:58:17 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:58:17 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:58:17 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:58:17 --> URI Class Initialized
DEBUG - 2013-09-01 04:58:17 --> Router Class Initialized
DEBUG - 2013-09-01 04:58:18 --> Output Class Initialized
DEBUG - 2013-09-01 04:58:18 --> Security Class Initialized
DEBUG - 2013-09-01 04:58:18 --> Input Class Initialized
DEBUG - 2013-09-01 04:58:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:58:18 --> Language Class Initialized
DEBUG - 2013-09-01 04:58:18 --> Loader Class Initialized
DEBUG - 2013-09-01 04:58:18 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:58:18 --> Controller Class Initialized
DEBUG - 2013-09-01 04:58:18 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:58:18 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:58:18 --> Model Class Initialized
DEBUG - 2013-09-01 04:58:18 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:58:18 --> Model Class Initialized
DEBUG - 2013-09-01 04:58:18 --> Model Class Initialized
DEBUG - 2013-09-01 04:58:18 --> XSS Filtering completed
DEBUG - 2013-09-01 04:58:18 --> XSS Filtering completed
DEBUG - 2013-09-01 04:58:19 --> Config Class Initialized
DEBUG - 2013-09-01 04:58:19 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:58:19 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:58:19 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:58:19 --> URI Class Initialized
DEBUG - 2013-09-01 04:58:19 --> Router Class Initialized
DEBUG - 2013-09-01 04:58:19 --> Output Class Initialized
DEBUG - 2013-09-01 04:58:19 --> Security Class Initialized
DEBUG - 2013-09-01 04:58:19 --> Input Class Initialized
DEBUG - 2013-09-01 04:58:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:58:19 --> Language Class Initialized
DEBUG - 2013-09-01 04:58:19 --> Loader Class Initialized
DEBUG - 2013-09-01 04:58:19 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:58:19 --> Controller Class Initialized
DEBUG - 2013-09-01 04:58:19 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:58:19 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:58:19 --> Model Class Initialized
DEBUG - 2013-09-01 04:58:19 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:58:19 --> Model Class Initialized
DEBUG - 2013-09-01 04:58:19 --> Model Class Initialized
DEBUG - 2013-09-01 04:58:31 --> Config Class Initialized
DEBUG - 2013-09-01 04:58:31 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:58:31 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:58:31 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:58:31 --> URI Class Initialized
DEBUG - 2013-09-01 04:58:31 --> Router Class Initialized
DEBUG - 2013-09-01 04:58:31 --> Output Class Initialized
DEBUG - 2013-09-01 04:58:31 --> Security Class Initialized
DEBUG - 2013-09-01 04:58:31 --> Input Class Initialized
DEBUG - 2013-09-01 04:58:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:58:31 --> Language Class Initialized
DEBUG - 2013-09-01 04:58:31 --> Loader Class Initialized
DEBUG - 2013-09-01 04:58:31 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:58:31 --> Controller Class Initialized
DEBUG - 2013-09-01 04:58:31 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:58:31 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:58:31 --> Model Class Initialized
DEBUG - 2013-09-01 04:58:31 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:58:31 --> Model Class Initialized
DEBUG - 2013-09-01 04:58:31 --> File loaded: application/views/admin.php
DEBUG - 2013-09-01 04:58:31 --> Final output sent to browser
DEBUG - 2013-09-01 04:58:31 --> Total execution time: 0.0980
DEBUG - 2013-09-01 04:58:35 --> Config Class Initialized
DEBUG - 2013-09-01 04:58:35 --> Hooks Class Initialized
DEBUG - 2013-09-01 04:58:35 --> Utf8 Class Initialized
DEBUG - 2013-09-01 04:58:35 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 04:58:35 --> URI Class Initialized
DEBUG - 2013-09-01 04:58:35 --> Router Class Initialized
DEBUG - 2013-09-01 04:58:35 --> Output Class Initialized
DEBUG - 2013-09-01 04:58:35 --> Security Class Initialized
DEBUG - 2013-09-01 04:58:35 --> Input Class Initialized
DEBUG - 2013-09-01 04:58:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 04:58:35 --> Language Class Initialized
DEBUG - 2013-09-01 04:58:35 --> Loader Class Initialized
DEBUG - 2013-09-01 04:58:35 --> Database Driver Class Initialized
DEBUG - 2013-09-01 04:58:35 --> Controller Class Initialized
DEBUG - 2013-09-01 04:58:35 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 04:58:35 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 04:58:35 --> Model Class Initialized
DEBUG - 2013-09-01 04:58:35 --> Helper loaded: date_helper
DEBUG - 2013-09-01 04:58:35 --> Model Class Initialized
DEBUG - 2013-09-01 04:58:35 --> File loaded: application/views/admin.php
DEBUG - 2013-09-01 04:58:35 --> Final output sent to browser
DEBUG - 2013-09-01 04:58:35 --> Total execution time: 0.0630
DEBUG - 2013-09-01 05:00:09 --> Config Class Initialized
DEBUG - 2013-09-01 05:00:09 --> Hooks Class Initialized
DEBUG - 2013-09-01 05:00:09 --> Utf8 Class Initialized
DEBUG - 2013-09-01 05:00:09 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 05:00:09 --> URI Class Initialized
DEBUG - 2013-09-01 05:00:09 --> Router Class Initialized
DEBUG - 2013-09-01 05:00:09 --> Output Class Initialized
DEBUG - 2013-09-01 05:00:09 --> Security Class Initialized
DEBUG - 2013-09-01 05:00:09 --> Input Class Initialized
DEBUG - 2013-09-01 05:00:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 05:00:09 --> Language Class Initialized
DEBUG - 2013-09-01 05:00:09 --> Loader Class Initialized
DEBUG - 2013-09-01 05:00:09 --> Database Driver Class Initialized
DEBUG - 2013-09-01 05:00:09 --> Controller Class Initialized
DEBUG - 2013-09-01 05:00:09 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 05:00:09 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 05:00:09 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:09 --> Helper loaded: date_helper
DEBUG - 2013-09-01 05:00:09 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:09 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:09 --> XSS Filtering completed
DEBUG - 2013-09-01 05:00:09 --> XSS Filtering completed
DEBUG - 2013-09-01 05:00:09 --> Config Class Initialized
DEBUG - 2013-09-01 05:00:09 --> Hooks Class Initialized
DEBUG - 2013-09-01 05:00:09 --> Utf8 Class Initialized
DEBUG - 2013-09-01 05:00:09 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 05:00:09 --> URI Class Initialized
DEBUG - 2013-09-01 05:00:09 --> Router Class Initialized
DEBUG - 2013-09-01 05:00:09 --> Output Class Initialized
DEBUG - 2013-09-01 05:00:09 --> Security Class Initialized
DEBUG - 2013-09-01 05:00:09 --> Input Class Initialized
DEBUG - 2013-09-01 05:00:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 05:00:09 --> Language Class Initialized
DEBUG - 2013-09-01 05:00:09 --> Loader Class Initialized
DEBUG - 2013-09-01 05:00:09 --> Database Driver Class Initialized
DEBUG - 2013-09-01 05:00:09 --> Controller Class Initialized
DEBUG - 2013-09-01 05:00:09 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 05:00:09 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 05:00:09 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:09 --> Helper loaded: date_helper
DEBUG - 2013-09-01 05:00:09 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:09 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:09 --> XSS Filtering completed
DEBUG - 2013-09-01 05:00:11 --> Config Class Initialized
DEBUG - 2013-09-01 05:00:11 --> Hooks Class Initialized
DEBUG - 2013-09-01 05:00:11 --> Utf8 Class Initialized
DEBUG - 2013-09-01 05:00:11 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 05:00:11 --> Config Class Initialized
DEBUG - 2013-09-01 05:00:11 --> URI Class Initialized
DEBUG - 2013-09-01 05:00:11 --> Hooks Class Initialized
DEBUG - 2013-09-01 05:00:11 --> Utf8 Class Initialized
DEBUG - 2013-09-01 05:00:11 --> Router Class Initialized
DEBUG - 2013-09-01 05:00:11 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 05:00:11 --> URI Class Initialized
DEBUG - 2013-09-01 05:00:11 --> Output Class Initialized
DEBUG - 2013-09-01 05:00:11 --> Router Class Initialized
DEBUG - 2013-09-01 05:00:11 --> Security Class Initialized
DEBUG - 2013-09-01 05:00:11 --> Output Class Initialized
DEBUG - 2013-09-01 05:00:11 --> Input Class Initialized
DEBUG - 2013-09-01 05:00:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 05:00:11 --> Security Class Initialized
DEBUG - 2013-09-01 05:00:11 --> Language Class Initialized
DEBUG - 2013-09-01 05:00:11 --> Input Class Initialized
DEBUG - 2013-09-01 05:00:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 05:00:11 --> Language Class Initialized
DEBUG - 2013-09-01 05:00:11 --> Loader Class Initialized
DEBUG - 2013-09-01 05:00:11 --> Loader Class Initialized
DEBUG - 2013-09-01 05:00:11 --> Database Driver Class Initialized
DEBUG - 2013-09-01 05:00:11 --> Database Driver Class Initialized
DEBUG - 2013-09-01 05:00:11 --> Controller Class Initialized
DEBUG - 2013-09-01 05:00:11 --> Controller Class Initialized
DEBUG - 2013-09-01 05:00:11 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 05:00:11 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 05:00:11 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 05:00:11 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 05:00:11 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:11 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:11 --> Helper loaded: date_helper
DEBUG - 2013-09-01 05:00:11 --> Helper loaded: date_helper
DEBUG - 2013-09-01 05:00:11 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:11 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:11 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:11 --> XSS Filtering completed
DEBUG - 2013-09-01 05:00:11 --> XSS Filtering completed
DEBUG - 2013-09-01 05:00:11 --> XSS Filtering completed
DEBUG - 2013-09-01 05:00:12 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:12 --> XSS Filtering completed
DEBUG - 2013-09-01 05:00:12 --> XSS Filtering completed
ERROR - 2013-09-01 05:00:12 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 185
ERROR - 2013-09-01 05:00:12 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-01 05:00:12 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-01 05:00:12 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 195
DEBUG - 2013-09-01 05:00:15 --> Config Class Initialized
DEBUG - 2013-09-01 05:00:15 --> Hooks Class Initialized
DEBUG - 2013-09-01 05:00:15 --> Utf8 Class Initialized
DEBUG - 2013-09-01 05:00:15 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 05:00:15 --> URI Class Initialized
DEBUG - 2013-09-01 05:00:15 --> Config Class Initialized
DEBUG - 2013-09-01 05:00:15 --> Router Class Initialized
DEBUG - 2013-09-01 05:00:15 --> Hooks Class Initialized
DEBUG - 2013-09-01 05:00:15 --> Utf8 Class Initialized
DEBUG - 2013-09-01 05:00:15 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 05:00:15 --> Output Class Initialized
DEBUG - 2013-09-01 05:00:15 --> URI Class Initialized
DEBUG - 2013-09-01 05:00:15 --> Security Class Initialized
DEBUG - 2013-09-01 05:00:15 --> Router Class Initialized
DEBUG - 2013-09-01 05:00:15 --> Input Class Initialized
DEBUG - 2013-09-01 05:00:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 05:00:15 --> Output Class Initialized
DEBUG - 2013-09-01 05:00:15 --> Language Class Initialized
DEBUG - 2013-09-01 05:00:15 --> Security Class Initialized
DEBUG - 2013-09-01 05:00:15 --> Input Class Initialized
DEBUG - 2013-09-01 05:00:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 05:00:15 --> Language Class Initialized
DEBUG - 2013-09-01 05:00:15 --> Loader Class Initialized
DEBUG - 2013-09-01 05:00:15 --> Loader Class Initialized
DEBUG - 2013-09-01 05:00:15 --> Database Driver Class Initialized
DEBUG - 2013-09-01 05:00:15 --> Controller Class Initialized
DEBUG - 2013-09-01 05:00:15 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 05:00:15 --> Database Driver Class Initialized
DEBUG - 2013-09-01 05:00:15 --> Controller Class Initialized
DEBUG - 2013-09-01 05:00:15 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 05:00:15 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 05:00:15 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 05:00:15 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:15 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:15 --> Helper loaded: date_helper
DEBUG - 2013-09-01 05:00:15 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:15 --> Helper loaded: date_helper
DEBUG - 2013-09-01 05:00:15 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:15 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:15 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:15 --> XSS Filtering completed
DEBUG - 2013-09-01 05:00:15 --> XSS Filtering completed
DEBUG - 2013-09-01 05:00:15 --> XSS Filtering completed
DEBUG - 2013-09-01 05:00:15 --> XSS Filtering completed
DEBUG - 2013-09-01 05:00:15 --> XSS Filtering completed
ERROR - 2013-09-01 05:00:15 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 185
ERROR - 2013-09-01 05:00:15 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
DEBUG - 2013-09-01 05:00:15 --> XSS Filtering completed
ERROR - 2013-09-01 05:00:15 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-01 05:00:15 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 195
DEBUG - 2013-09-01 05:00:17 --> Config Class Initialized
DEBUG - 2013-09-01 05:00:17 --> Config Class Initialized
DEBUG - 2013-09-01 05:00:17 --> Hooks Class Initialized
DEBUG - 2013-09-01 05:00:17 --> Hooks Class Initialized
DEBUG - 2013-09-01 05:00:17 --> Utf8 Class Initialized
DEBUG - 2013-09-01 05:00:17 --> Utf8 Class Initialized
DEBUG - 2013-09-01 05:00:17 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 05:00:17 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 05:00:17 --> URI Class Initialized
DEBUG - 2013-09-01 05:00:17 --> URI Class Initialized
DEBUG - 2013-09-01 05:00:17 --> Router Class Initialized
DEBUG - 2013-09-01 05:00:17 --> Router Class Initialized
DEBUG - 2013-09-01 05:00:17 --> Output Class Initialized
DEBUG - 2013-09-01 05:00:17 --> Output Class Initialized
DEBUG - 2013-09-01 05:00:17 --> Security Class Initialized
DEBUG - 2013-09-01 05:00:17 --> Security Class Initialized
DEBUG - 2013-09-01 05:00:17 --> Input Class Initialized
DEBUG - 2013-09-01 05:00:17 --> Input Class Initialized
DEBUG - 2013-09-01 05:00:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 05:00:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 05:00:17 --> Language Class Initialized
DEBUG - 2013-09-01 05:00:17 --> Language Class Initialized
DEBUG - 2013-09-01 05:00:17 --> Loader Class Initialized
DEBUG - 2013-09-01 05:00:17 --> Loader Class Initialized
DEBUG - 2013-09-01 05:00:17 --> Database Driver Class Initialized
DEBUG - 2013-09-01 05:00:17 --> Database Driver Class Initialized
DEBUG - 2013-09-01 05:00:17 --> Controller Class Initialized
DEBUG - 2013-09-01 05:00:17 --> Controller Class Initialized
DEBUG - 2013-09-01 05:00:17 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 05:00:17 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 05:00:17 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 05:00:17 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 05:00:17 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:17 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:17 --> Helper loaded: date_helper
DEBUG - 2013-09-01 05:00:17 --> Helper loaded: date_helper
DEBUG - 2013-09-01 05:00:17 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:17 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:17 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:17 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:17 --> XSS Filtering completed
DEBUG - 2013-09-01 05:00:17 --> XSS Filtering completed
DEBUG - 2013-09-01 05:00:17 --> XSS Filtering completed
DEBUG - 2013-09-01 05:00:17 --> XSS Filtering completed
DEBUG - 2013-09-01 05:00:17 --> XSS Filtering completed
ERROR - 2013-09-01 05:00:17 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 185
DEBUG - 2013-09-01 05:00:17 --> XSS Filtering completed
ERROR - 2013-09-01 05:00:17 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-01 05:00:17 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-01 05:00:17 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 195
DEBUG - 2013-09-01 05:00:19 --> Config Class Initialized
DEBUG - 2013-09-01 05:00:19 --> Hooks Class Initialized
DEBUG - 2013-09-01 05:00:19 --> Utf8 Class Initialized
DEBUG - 2013-09-01 05:00:19 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 05:00:19 --> URI Class Initialized
DEBUG - 2013-09-01 05:00:19 --> Config Class Initialized
DEBUG - 2013-09-01 05:00:19 --> Hooks Class Initialized
DEBUG - 2013-09-01 05:00:19 --> Router Class Initialized
DEBUG - 2013-09-01 05:00:19 --> Utf8 Class Initialized
DEBUG - 2013-09-01 05:00:19 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 05:00:19 --> Output Class Initialized
DEBUG - 2013-09-01 05:00:19 --> URI Class Initialized
DEBUG - 2013-09-01 05:00:19 --> Router Class Initialized
DEBUG - 2013-09-01 05:00:19 --> Security Class Initialized
DEBUG - 2013-09-01 05:00:19 --> Input Class Initialized
DEBUG - 2013-09-01 05:00:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 05:00:19 --> Output Class Initialized
DEBUG - 2013-09-01 05:00:19 --> Language Class Initialized
DEBUG - 2013-09-01 05:00:19 --> Security Class Initialized
DEBUG - 2013-09-01 05:00:19 --> Input Class Initialized
DEBUG - 2013-09-01 05:00:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 05:00:19 --> Language Class Initialized
DEBUG - 2013-09-01 05:00:19 --> Loader Class Initialized
DEBUG - 2013-09-01 05:00:19 --> Loader Class Initialized
DEBUG - 2013-09-01 05:00:19 --> Database Driver Class Initialized
DEBUG - 2013-09-01 05:00:19 --> Controller Class Initialized
DEBUG - 2013-09-01 05:00:19 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 05:00:19 --> Database Driver Class Initialized
DEBUG - 2013-09-01 05:00:19 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 05:00:19 --> Controller Class Initialized
DEBUG - 2013-09-01 05:00:19 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 05:00:19 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:19 --> Helper loaded: date_helper
DEBUG - 2013-09-01 05:00:19 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 05:00:19 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:19 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:19 --> Helper loaded: date_helper
DEBUG - 2013-09-01 05:00:19 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:19 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:19 --> XSS Filtering completed
DEBUG - 2013-09-01 05:00:19 --> XSS Filtering completed
DEBUG - 2013-09-01 05:00:19 --> XSS Filtering completed
DEBUG - 2013-09-01 05:00:19 --> XSS Filtering completed
DEBUG - 2013-09-01 05:00:19 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:19 --> XSS Filtering completed
DEBUG - 2013-09-01 05:00:19 --> XSS Filtering completed
ERROR - 2013-09-01 05:00:19 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 185
ERROR - 2013-09-01 05:00:19 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-01 05:00:19 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-01 05:00:19 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 195
DEBUG - 2013-09-01 05:00:20 --> Config Class Initialized
DEBUG - 2013-09-01 05:00:20 --> Config Class Initialized
DEBUG - 2013-09-01 05:00:20 --> Hooks Class Initialized
DEBUG - 2013-09-01 05:00:20 --> Hooks Class Initialized
DEBUG - 2013-09-01 05:00:20 --> Utf8 Class Initialized
DEBUG - 2013-09-01 05:00:20 --> Utf8 Class Initialized
DEBUG - 2013-09-01 05:00:20 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 05:00:20 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 05:00:20 --> URI Class Initialized
DEBUG - 2013-09-01 05:00:20 --> URI Class Initialized
DEBUG - 2013-09-01 05:00:20 --> Router Class Initialized
DEBUG - 2013-09-01 05:00:20 --> Router Class Initialized
DEBUG - 2013-09-01 05:00:20 --> Output Class Initialized
DEBUG - 2013-09-01 05:00:20 --> Output Class Initialized
DEBUG - 2013-09-01 05:00:20 --> Security Class Initialized
DEBUG - 2013-09-01 05:00:20 --> Security Class Initialized
DEBUG - 2013-09-01 05:00:20 --> Input Class Initialized
DEBUG - 2013-09-01 05:00:20 --> Input Class Initialized
DEBUG - 2013-09-01 05:00:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 05:00:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 05:00:20 --> Language Class Initialized
DEBUG - 2013-09-01 05:00:20 --> Language Class Initialized
DEBUG - 2013-09-01 05:00:20 --> Loader Class Initialized
DEBUG - 2013-09-01 05:00:20 --> Loader Class Initialized
DEBUG - 2013-09-01 05:00:20 --> Database Driver Class Initialized
DEBUG - 2013-09-01 05:00:20 --> Database Driver Class Initialized
DEBUG - 2013-09-01 05:00:20 --> Controller Class Initialized
DEBUG - 2013-09-01 05:00:20 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 05:00:20 --> Controller Class Initialized
DEBUG - 2013-09-01 05:00:20 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 05:00:20 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 05:00:20 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 05:00:20 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:20 --> Helper loaded: date_helper
DEBUG - 2013-09-01 05:00:20 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:20 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:20 --> Helper loaded: date_helper
DEBUG - 2013-09-01 05:00:20 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:20 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:20 --> XSS Filtering completed
DEBUG - 2013-09-01 05:00:20 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:20 --> XSS Filtering completed
ERROR - 2013-09-01 05:00:20 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 185
ERROR - 2013-09-01 05:00:20 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
DEBUG - 2013-09-01 05:00:20 --> XSS Filtering completed
ERROR - 2013-09-01 05:00:20 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-01 05:00:20 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 195
DEBUG - 2013-09-01 05:00:20 --> XSS Filtering completed
DEBUG - 2013-09-01 05:00:20 --> XSS Filtering completed
DEBUG - 2013-09-01 05:00:20 --> XSS Filtering completed
DEBUG - 2013-09-01 05:00:22 --> Config Class Initialized
DEBUG - 2013-09-01 05:00:22 --> Config Class Initialized
DEBUG - 2013-09-01 05:00:22 --> Hooks Class Initialized
DEBUG - 2013-09-01 05:00:22 --> Hooks Class Initialized
DEBUG - 2013-09-01 05:00:22 --> Utf8 Class Initialized
DEBUG - 2013-09-01 05:00:22 --> Utf8 Class Initialized
DEBUG - 2013-09-01 05:00:22 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 05:00:22 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 05:00:22 --> URI Class Initialized
DEBUG - 2013-09-01 05:00:22 --> URI Class Initialized
DEBUG - 2013-09-01 05:00:22 --> Router Class Initialized
DEBUG - 2013-09-01 05:00:22 --> Router Class Initialized
DEBUG - 2013-09-01 05:00:22 --> Output Class Initialized
DEBUG - 2013-09-01 05:00:22 --> Output Class Initialized
DEBUG - 2013-09-01 05:00:22 --> Security Class Initialized
DEBUG - 2013-09-01 05:00:22 --> Security Class Initialized
DEBUG - 2013-09-01 05:00:22 --> Input Class Initialized
DEBUG - 2013-09-01 05:00:22 --> Input Class Initialized
DEBUG - 2013-09-01 05:00:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 05:00:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 05:00:22 --> Language Class Initialized
DEBUG - 2013-09-01 05:00:22 --> Language Class Initialized
DEBUG - 2013-09-01 05:00:22 --> Loader Class Initialized
DEBUG - 2013-09-01 05:00:22 --> Loader Class Initialized
DEBUG - 2013-09-01 05:00:22 --> Database Driver Class Initialized
DEBUG - 2013-09-01 05:00:22 --> Database Driver Class Initialized
DEBUG - 2013-09-01 05:00:22 --> Controller Class Initialized
DEBUG - 2013-09-01 05:00:22 --> Controller Class Initialized
DEBUG - 2013-09-01 05:00:22 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 05:00:22 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 05:00:22 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 05:00:22 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 05:00:22 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:22 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:22 --> Helper loaded: date_helper
DEBUG - 2013-09-01 05:00:22 --> Helper loaded: date_helper
DEBUG - 2013-09-01 05:00:22 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:22 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:22 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:22 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:22 --> XSS Filtering completed
DEBUG - 2013-09-01 05:00:22 --> XSS Filtering completed
DEBUG - 2013-09-01 05:00:22 --> XSS Filtering completed
DEBUG - 2013-09-01 05:00:22 --> XSS Filtering completed
DEBUG - 2013-09-01 05:00:22 --> XSS Filtering completed
ERROR - 2013-09-01 05:00:22 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 185
ERROR - 2013-09-01 05:00:22 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
DEBUG - 2013-09-01 05:00:22 --> XSS Filtering completed
ERROR - 2013-09-01 05:00:22 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-01 05:00:22 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 195
DEBUG - 2013-09-01 05:00:35 --> Config Class Initialized
DEBUG - 2013-09-01 05:00:35 --> Hooks Class Initialized
DEBUG - 2013-09-01 05:00:35 --> Utf8 Class Initialized
DEBUG - 2013-09-01 05:00:35 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 05:00:35 --> URI Class Initialized
DEBUG - 2013-09-01 05:00:35 --> Config Class Initialized
DEBUG - 2013-09-01 05:00:35 --> Hooks Class Initialized
DEBUG - 2013-09-01 05:00:35 --> Router Class Initialized
DEBUG - 2013-09-01 05:00:35 --> Utf8 Class Initialized
DEBUG - 2013-09-01 05:00:35 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 05:00:35 --> Output Class Initialized
DEBUG - 2013-09-01 05:00:35 --> URI Class Initialized
DEBUG - 2013-09-01 05:00:35 --> Router Class Initialized
DEBUG - 2013-09-01 05:00:35 --> Security Class Initialized
DEBUG - 2013-09-01 05:00:35 --> Input Class Initialized
DEBUG - 2013-09-01 05:00:35 --> Output Class Initialized
DEBUG - 2013-09-01 05:00:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 05:00:35 --> Language Class Initialized
DEBUG - 2013-09-01 05:00:35 --> Security Class Initialized
DEBUG - 2013-09-01 05:00:35 --> Input Class Initialized
DEBUG - 2013-09-01 05:00:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 05:00:35 --> Language Class Initialized
DEBUG - 2013-09-01 05:00:35 --> Loader Class Initialized
DEBUG - 2013-09-01 05:00:35 --> Loader Class Initialized
DEBUG - 2013-09-01 05:00:35 --> Database Driver Class Initialized
DEBUG - 2013-09-01 05:00:35 --> Database Driver Class Initialized
DEBUG - 2013-09-01 05:00:35 --> Controller Class Initialized
DEBUG - 2013-09-01 05:00:35 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 05:00:35 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 05:00:35 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:35 --> Helper loaded: date_helper
DEBUG - 2013-09-01 05:00:35 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:35 --> Controller Class Initialized
DEBUG - 2013-09-01 05:00:35 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 05:00:35 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:35 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 05:00:35 --> XSS Filtering completed
DEBUG - 2013-09-01 05:00:35 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:35 --> XSS Filtering completed
DEBUG - 2013-09-01 05:00:35 --> XSS Filtering completed
DEBUG - 2013-09-01 05:00:35 --> Helper loaded: date_helper
DEBUG - 2013-09-01 05:00:35 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:35 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:35 --> XSS Filtering completed
DEBUG - 2013-09-01 05:00:35 --> XSS Filtering completed
ERROR - 2013-09-01 05:00:35 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 185
ERROR - 2013-09-01 05:00:35 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-01 05:00:35 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-01 05:00:35 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 195
DEBUG - 2013-09-01 05:00:36 --> Config Class Initialized
DEBUG - 2013-09-01 05:00:36 --> Hooks Class Initialized
DEBUG - 2013-09-01 05:00:36 --> Utf8 Class Initialized
DEBUG - 2013-09-01 05:00:36 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 05:00:36 --> URI Class Initialized
DEBUG - 2013-09-01 05:00:36 --> Router Class Initialized
DEBUG - 2013-09-01 05:00:36 --> Config Class Initialized
DEBUG - 2013-09-01 05:00:36 --> Output Class Initialized
DEBUG - 2013-09-01 05:00:36 --> Hooks Class Initialized
DEBUG - 2013-09-01 05:00:36 --> Utf8 Class Initialized
DEBUG - 2013-09-01 05:00:36 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 05:00:36 --> Security Class Initialized
DEBUG - 2013-09-01 05:00:36 --> URI Class Initialized
DEBUG - 2013-09-01 05:00:36 --> Input Class Initialized
DEBUG - 2013-09-01 05:00:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 05:00:36 --> Router Class Initialized
DEBUG - 2013-09-01 05:00:36 --> Language Class Initialized
DEBUG - 2013-09-01 05:00:36 --> Output Class Initialized
DEBUG - 2013-09-01 05:00:36 --> Security Class Initialized
DEBUG - 2013-09-01 05:00:36 --> Loader Class Initialized
DEBUG - 2013-09-01 05:00:36 --> Input Class Initialized
DEBUG - 2013-09-01 05:00:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 05:00:36 --> Language Class Initialized
DEBUG - 2013-09-01 05:00:36 --> Loader Class Initialized
DEBUG - 2013-09-01 05:00:36 --> Database Driver Class Initialized
DEBUG - 2013-09-01 05:00:36 --> Controller Class Initialized
DEBUG - 2013-09-01 05:00:36 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 05:00:36 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 05:00:36 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:36 --> Helper loaded: date_helper
DEBUG - 2013-09-01 05:00:36 --> Database Driver Class Initialized
DEBUG - 2013-09-01 05:00:36 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:36 --> Controller Class Initialized
DEBUG - 2013-09-01 05:00:36 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 05:00:36 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:36 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 05:00:36 --> XSS Filtering completed
DEBUG - 2013-09-01 05:00:36 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:36 --> XSS Filtering completed
DEBUG - 2013-09-01 05:00:36 --> XSS Filtering completed
DEBUG - 2013-09-01 05:00:36 --> Helper loaded: date_helper
DEBUG - 2013-09-01 05:00:36 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:36 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:36 --> XSS Filtering completed
DEBUG - 2013-09-01 05:00:36 --> XSS Filtering completed
ERROR - 2013-09-01 05:00:36 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 185
ERROR - 2013-09-01 05:00:36 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-01 05:00:36 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-01 05:00:36 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 195
DEBUG - 2013-09-01 05:00:46 --> Config Class Initialized
DEBUG - 2013-09-01 05:00:46 --> Hooks Class Initialized
DEBUG - 2013-09-01 05:00:46 --> Utf8 Class Initialized
DEBUG - 2013-09-01 05:00:46 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 05:00:46 --> URI Class Initialized
DEBUG - 2013-09-01 05:00:46 --> Router Class Initialized
DEBUG - 2013-09-01 05:00:46 --> Output Class Initialized
DEBUG - 2013-09-01 05:00:46 --> Security Class Initialized
DEBUG - 2013-09-01 05:00:46 --> Input Class Initialized
DEBUG - 2013-09-01 05:00:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 05:00:46 --> Language Class Initialized
DEBUG - 2013-09-01 05:00:46 --> Loader Class Initialized
DEBUG - 2013-09-01 05:00:46 --> Database Driver Class Initialized
DEBUG - 2013-09-01 05:00:46 --> Controller Class Initialized
DEBUG - 2013-09-01 05:00:46 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 05:00:46 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 05:00:46 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:46 --> Helper loaded: date_helper
DEBUG - 2013-09-01 05:00:46 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:46 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:46 --> XSS Filtering completed
DEBUG - 2013-09-01 05:00:49 --> Config Class Initialized
DEBUG - 2013-09-01 05:00:49 --> Hooks Class Initialized
DEBUG - 2013-09-01 05:00:49 --> Utf8 Class Initialized
DEBUG - 2013-09-01 05:00:49 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 05:00:49 --> URI Class Initialized
DEBUG - 2013-09-01 05:00:49 --> Router Class Initialized
DEBUG - 2013-09-01 05:00:49 --> Output Class Initialized
DEBUG - 2013-09-01 05:00:49 --> Security Class Initialized
DEBUG - 2013-09-01 05:00:49 --> Input Class Initialized
DEBUG - 2013-09-01 05:00:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 05:00:49 --> Language Class Initialized
DEBUG - 2013-09-01 05:00:49 --> Loader Class Initialized
DEBUG - 2013-09-01 05:00:49 --> Database Driver Class Initialized
DEBUG - 2013-09-01 05:00:49 --> Controller Class Initialized
DEBUG - 2013-09-01 05:00:49 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 05:00:49 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 05:00:49 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:49 --> Helper loaded: date_helper
DEBUG - 2013-09-01 05:00:49 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:49 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:49 --> XSS Filtering completed
DEBUG - 2013-09-01 05:00:49 --> XSS Filtering completed
DEBUG - 2013-09-01 05:00:49 --> XSS Filtering completed
DEBUG - 2013-09-01 05:00:50 --> Config Class Initialized
DEBUG - 2013-09-01 05:00:50 --> Hooks Class Initialized
DEBUG - 2013-09-01 05:00:50 --> Utf8 Class Initialized
DEBUG - 2013-09-01 05:00:50 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 05:00:50 --> URI Class Initialized
DEBUG - 2013-09-01 05:00:50 --> Router Class Initialized
DEBUG - 2013-09-01 05:00:50 --> Output Class Initialized
DEBUG - 2013-09-01 05:00:50 --> Security Class Initialized
DEBUG - 2013-09-01 05:00:50 --> Input Class Initialized
DEBUG - 2013-09-01 05:00:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 05:00:50 --> Language Class Initialized
DEBUG - 2013-09-01 05:00:50 --> Loader Class Initialized
DEBUG - 2013-09-01 05:00:50 --> Database Driver Class Initialized
DEBUG - 2013-09-01 05:00:50 --> Controller Class Initialized
DEBUG - 2013-09-01 05:00:50 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 05:00:50 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 05:00:50 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:50 --> Helper loaded: date_helper
DEBUG - 2013-09-01 05:00:50 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:50 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:50 --> XSS Filtering completed
DEBUG - 2013-09-01 05:00:50 --> XSS Filtering completed
DEBUG - 2013-09-01 05:00:50 --> XSS Filtering completed
DEBUG - 2013-09-01 05:00:52 --> Config Class Initialized
DEBUG - 2013-09-01 05:00:52 --> Hooks Class Initialized
DEBUG - 2013-09-01 05:00:52 --> Utf8 Class Initialized
DEBUG - 2013-09-01 05:00:52 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 05:00:52 --> URI Class Initialized
DEBUG - 2013-09-01 05:00:52 --> Router Class Initialized
DEBUG - 2013-09-01 05:00:52 --> Output Class Initialized
DEBUG - 2013-09-01 05:00:52 --> Security Class Initialized
DEBUG - 2013-09-01 05:00:52 --> Input Class Initialized
DEBUG - 2013-09-01 05:00:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 05:00:52 --> Language Class Initialized
DEBUG - 2013-09-01 05:00:52 --> Loader Class Initialized
DEBUG - 2013-09-01 05:00:52 --> Database Driver Class Initialized
DEBUG - 2013-09-01 05:00:52 --> Controller Class Initialized
DEBUG - 2013-09-01 05:00:52 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 05:00:52 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 05:00:52 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:52 --> Helper loaded: date_helper
DEBUG - 2013-09-01 05:00:52 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:52 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:52 --> XSS Filtering completed
DEBUG - 2013-09-01 05:00:52 --> XSS Filtering completed
DEBUG - 2013-09-01 05:00:53 --> Config Class Initialized
DEBUG - 2013-09-01 05:00:53 --> Hooks Class Initialized
DEBUG - 2013-09-01 05:00:53 --> Utf8 Class Initialized
DEBUG - 2013-09-01 05:00:53 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 05:00:53 --> URI Class Initialized
DEBUG - 2013-09-01 05:00:53 --> Router Class Initialized
DEBUG - 2013-09-01 05:00:53 --> Output Class Initialized
DEBUG - 2013-09-01 05:00:53 --> Security Class Initialized
DEBUG - 2013-09-01 05:00:53 --> Input Class Initialized
DEBUG - 2013-09-01 05:00:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 05:00:53 --> Language Class Initialized
DEBUG - 2013-09-01 05:00:53 --> Loader Class Initialized
DEBUG - 2013-09-01 05:00:53 --> Database Driver Class Initialized
DEBUG - 2013-09-01 05:00:53 --> Controller Class Initialized
DEBUG - 2013-09-01 05:00:53 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 05:00:53 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 05:00:53 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:53 --> Helper loaded: date_helper
DEBUG - 2013-09-01 05:00:53 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:53 --> Model Class Initialized
DEBUG - 2013-09-01 05:00:53 --> XSS Filtering completed
DEBUG - 2013-09-01 05:00:53 --> XSS Filtering completed
DEBUG - 2013-09-01 05:01:03 --> Config Class Initialized
DEBUG - 2013-09-01 05:01:03 --> Hooks Class Initialized
DEBUG - 2013-09-01 05:01:03 --> Utf8 Class Initialized
DEBUG - 2013-09-01 05:01:03 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 05:01:03 --> URI Class Initialized
DEBUG - 2013-09-01 05:01:03 --> Router Class Initialized
DEBUG - 2013-09-01 05:01:03 --> Output Class Initialized
DEBUG - 2013-09-01 05:01:03 --> Security Class Initialized
DEBUG - 2013-09-01 05:01:03 --> Input Class Initialized
DEBUG - 2013-09-01 05:01:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 05:01:03 --> Language Class Initialized
DEBUG - 2013-09-01 05:01:03 --> Loader Class Initialized
DEBUG - 2013-09-01 05:01:03 --> Database Driver Class Initialized
DEBUG - 2013-09-01 05:01:03 --> Controller Class Initialized
DEBUG - 2013-09-01 05:01:03 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 05:01:03 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 05:01:03 --> Model Class Initialized
DEBUG - 2013-09-01 05:01:03 --> Helper loaded: date_helper
DEBUG - 2013-09-01 05:01:03 --> Model Class Initialized
DEBUG - 2013-09-01 05:01:03 --> Model Class Initialized
DEBUG - 2013-09-01 05:04:11 --> Config Class Initialized
DEBUG - 2013-09-01 05:04:11 --> Hooks Class Initialized
DEBUG - 2013-09-01 05:04:11 --> Utf8 Class Initialized
DEBUG - 2013-09-01 05:04:11 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 05:04:11 --> URI Class Initialized
DEBUG - 2013-09-01 05:04:11 --> Router Class Initialized
DEBUG - 2013-09-01 05:04:11 --> Output Class Initialized
DEBUG - 2013-09-01 05:04:11 --> Security Class Initialized
DEBUG - 2013-09-01 05:04:11 --> Input Class Initialized
DEBUG - 2013-09-01 05:04:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 05:04:11 --> Language Class Initialized
DEBUG - 2013-09-01 05:04:11 --> Loader Class Initialized
DEBUG - 2013-09-01 05:04:11 --> Database Driver Class Initialized
DEBUG - 2013-09-01 05:04:11 --> Controller Class Initialized
DEBUG - 2013-09-01 05:04:11 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 05:04:11 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 05:04:11 --> Model Class Initialized
DEBUG - 2013-09-01 05:04:11 --> Helper loaded: date_helper
DEBUG - 2013-09-01 05:04:11 --> Model Class Initialized
DEBUG - 2013-09-01 05:04:12 --> File loaded: application/views/admin.php
DEBUG - 2013-09-01 05:04:12 --> Final output sent to browser
DEBUG - 2013-09-01 05:04:12 --> Total execution time: 0.2890
DEBUG - 2013-09-01 05:04:14 --> Config Class Initialized
DEBUG - 2013-09-01 05:04:14 --> Hooks Class Initialized
DEBUG - 2013-09-01 05:04:14 --> Utf8 Class Initialized
DEBUG - 2013-09-01 05:04:14 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 05:04:14 --> URI Class Initialized
DEBUG - 2013-09-01 05:04:14 --> Router Class Initialized
DEBUG - 2013-09-01 05:04:14 --> No URI present. Default controller set.
DEBUG - 2013-09-01 05:04:14 --> Output Class Initialized
DEBUG - 2013-09-01 05:04:14 --> Security Class Initialized
DEBUG - 2013-09-01 05:04:14 --> Input Class Initialized
DEBUG - 2013-09-01 05:04:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 05:04:14 --> Language Class Initialized
DEBUG - 2013-09-01 05:04:14 --> Loader Class Initialized
DEBUG - 2013-09-01 05:04:14 --> Database Driver Class Initialized
DEBUG - 2013-09-01 05:04:14 --> Controller Class Initialized
DEBUG - 2013-09-01 05:04:14 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 05:04:14 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 05:04:14 --> Model Class Initialized
DEBUG - 2013-09-01 05:04:14 --> Helper loaded: date_helper
DEBUG - 2013-09-01 05:04:14 --> Model Class Initialized
DEBUG - 2013-09-01 05:04:14 --> File loaded: application/views/index.php
DEBUG - 2013-09-01 05:04:14 --> Final output sent to browser
DEBUG - 2013-09-01 05:04:14 --> Total execution time: 0.0620
DEBUG - 2013-09-01 05:24:49 --> Config Class Initialized
DEBUG - 2013-09-01 05:24:49 --> Hooks Class Initialized
DEBUG - 2013-09-01 05:24:49 --> Utf8 Class Initialized
DEBUG - 2013-09-01 05:24:49 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 05:24:49 --> URI Class Initialized
DEBUG - 2013-09-01 05:24:49 --> Router Class Initialized
DEBUG - 2013-09-01 05:24:49 --> Output Class Initialized
DEBUG - 2013-09-01 05:24:49 --> Security Class Initialized
DEBUG - 2013-09-01 05:24:49 --> Input Class Initialized
DEBUG - 2013-09-01 05:24:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 05:24:49 --> Language Class Initialized
DEBUG - 2013-09-01 05:24:49 --> Loader Class Initialized
DEBUG - 2013-09-01 05:24:49 --> Database Driver Class Initialized
DEBUG - 2013-09-01 05:24:49 --> Controller Class Initialized
DEBUG - 2013-09-01 05:24:49 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 05:24:49 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 05:24:49 --> Model Class Initialized
DEBUG - 2013-09-01 05:24:49 --> Helper loaded: date_helper
DEBUG - 2013-09-01 05:24:49 --> Model Class Initialized
DEBUG - 2013-09-01 05:24:49 --> File loaded: application/views/admin.php
DEBUG - 2013-09-01 05:24:49 --> Final output sent to browser
DEBUG - 2013-09-01 05:24:49 --> Total execution time: 0.0670
DEBUG - 2013-09-01 05:25:02 --> Config Class Initialized
DEBUG - 2013-09-01 05:25:02 --> Hooks Class Initialized
DEBUG - 2013-09-01 05:25:02 --> Utf8 Class Initialized
DEBUG - 2013-09-01 05:25:02 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 05:25:02 --> URI Class Initialized
DEBUG - 2013-09-01 05:25:02 --> Router Class Initialized
DEBUG - 2013-09-01 05:25:02 --> No URI present. Default controller set.
DEBUG - 2013-09-01 05:25:02 --> Output Class Initialized
DEBUG - 2013-09-01 05:25:02 --> Security Class Initialized
DEBUG - 2013-09-01 05:25:02 --> Input Class Initialized
DEBUG - 2013-09-01 05:25:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 05:25:02 --> Language Class Initialized
DEBUG - 2013-09-01 05:25:02 --> Loader Class Initialized
DEBUG - 2013-09-01 05:25:02 --> Database Driver Class Initialized
DEBUG - 2013-09-01 05:25:02 --> Controller Class Initialized
DEBUG - 2013-09-01 05:25:02 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 05:25:02 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 05:25:02 --> Model Class Initialized
DEBUG - 2013-09-01 05:25:02 --> Helper loaded: date_helper
DEBUG - 2013-09-01 05:25:02 --> Model Class Initialized
DEBUG - 2013-09-01 05:25:02 --> File loaded: application/views/index.php
DEBUG - 2013-09-01 05:25:02 --> Final output sent to browser
DEBUG - 2013-09-01 05:25:02 --> Total execution time: 0.0600
DEBUG - 2013-09-01 05:59:19 --> Config Class Initialized
DEBUG - 2013-09-01 05:59:19 --> Hooks Class Initialized
DEBUG - 2013-09-01 05:59:19 --> Utf8 Class Initialized
DEBUG - 2013-09-01 05:59:19 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 05:59:19 --> URI Class Initialized
DEBUG - 2013-09-01 05:59:19 --> Router Class Initialized
DEBUG - 2013-09-01 05:59:19 --> Output Class Initialized
DEBUG - 2013-09-01 05:59:19 --> Security Class Initialized
DEBUG - 2013-09-01 05:59:19 --> Input Class Initialized
DEBUG - 2013-09-01 05:59:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 05:59:19 --> Language Class Initialized
DEBUG - 2013-09-01 05:59:19 --> Loader Class Initialized
DEBUG - 2013-09-01 05:59:19 --> Database Driver Class Initialized
DEBUG - 2013-09-01 05:59:19 --> Controller Class Initialized
DEBUG - 2013-09-01 05:59:19 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 05:59:19 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 05:59:19 --> Model Class Initialized
DEBUG - 2013-09-01 05:59:19 --> Helper loaded: date_helper
DEBUG - 2013-09-01 05:59:19 --> Model Class Initialized
DEBUG - 2013-09-01 05:59:19 --> Model Class Initialized
DEBUG - 2013-09-01 05:59:19 --> XSS Filtering completed
DEBUG - 2013-09-01 05:59:19 --> XSS Filtering completed
DEBUG - 2013-09-01 05:59:19 --> XSS Filtering completed
DEBUG - 2013-09-01 05:59:19 --> XSS Filtering completed
DEBUG - 2013-09-01 05:59:19 --> XSS Filtering completed
DEBUG - 2013-09-01 05:59:19 --> XSS Filtering completed
DEBUG - 2013-09-01 06:00:24 --> Config Class Initialized
DEBUG - 2013-09-01 06:00:24 --> Hooks Class Initialized
DEBUG - 2013-09-01 06:00:24 --> Utf8 Class Initialized
DEBUG - 2013-09-01 06:00:24 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 06:00:24 --> URI Class Initialized
DEBUG - 2013-09-01 06:00:24 --> Router Class Initialized
DEBUG - 2013-09-01 06:00:24 --> Output Class Initialized
DEBUG - 2013-09-01 06:00:24 --> Security Class Initialized
DEBUG - 2013-09-01 06:00:24 --> Input Class Initialized
DEBUG - 2013-09-01 06:00:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 06:00:24 --> Language Class Initialized
DEBUG - 2013-09-01 06:00:24 --> Loader Class Initialized
DEBUG - 2013-09-01 06:00:24 --> Database Driver Class Initialized
DEBUG - 2013-09-01 06:00:24 --> Controller Class Initialized
DEBUG - 2013-09-01 06:00:24 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 06:00:24 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 06:00:24 --> Model Class Initialized
DEBUG - 2013-09-01 06:00:24 --> Helper loaded: date_helper
DEBUG - 2013-09-01 06:00:24 --> Model Class Initialized
DEBUG - 2013-09-01 06:00:24 --> File loaded: application/views/admin.php
DEBUG - 2013-09-01 06:00:24 --> Final output sent to browser
DEBUG - 2013-09-01 06:00:24 --> Total execution time: 0.0630
DEBUG - 2013-09-01 06:00:29 --> Config Class Initialized
DEBUG - 2013-09-01 06:00:29 --> Hooks Class Initialized
DEBUG - 2013-09-01 06:00:29 --> Utf8 Class Initialized
DEBUG - 2013-09-01 06:00:29 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 06:00:29 --> URI Class Initialized
DEBUG - 2013-09-01 06:00:29 --> Router Class Initialized
DEBUG - 2013-09-01 06:00:29 --> Output Class Initialized
DEBUG - 2013-09-01 06:00:29 --> Security Class Initialized
DEBUG - 2013-09-01 06:00:29 --> Input Class Initialized
DEBUG - 2013-09-01 06:00:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 06:00:29 --> Language Class Initialized
DEBUG - 2013-09-01 06:00:29 --> Loader Class Initialized
DEBUG - 2013-09-01 06:00:29 --> Database Driver Class Initialized
DEBUG - 2013-09-01 06:00:29 --> Controller Class Initialized
DEBUG - 2013-09-01 06:00:29 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 06:00:29 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 06:00:29 --> Model Class Initialized
DEBUG - 2013-09-01 06:00:29 --> Helper loaded: date_helper
DEBUG - 2013-09-01 06:00:29 --> Model Class Initialized
DEBUG - 2013-09-01 06:00:29 --> Model Class Initialized
DEBUG - 2013-09-01 06:00:29 --> XSS Filtering completed
DEBUG - 2013-09-01 06:00:29 --> XSS Filtering completed
DEBUG - 2013-09-01 06:00:29 --> Config Class Initialized
DEBUG - 2013-09-01 06:00:29 --> Hooks Class Initialized
DEBUG - 2013-09-01 06:00:29 --> Utf8 Class Initialized
DEBUG - 2013-09-01 06:00:29 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 06:00:29 --> Config Class Initialized
DEBUG - 2013-09-01 06:00:29 --> URI Class Initialized
DEBUG - 2013-09-01 06:00:29 --> Hooks Class Initialized
DEBUG - 2013-09-01 06:00:29 --> Router Class Initialized
DEBUG - 2013-09-01 06:00:29 --> Utf8 Class Initialized
DEBUG - 2013-09-01 06:00:29 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 06:00:29 --> URI Class Initialized
DEBUG - 2013-09-01 06:00:29 --> Output Class Initialized
DEBUG - 2013-09-01 06:00:29 --> Router Class Initialized
DEBUG - 2013-09-01 06:00:29 --> Security Class Initialized
DEBUG - 2013-09-01 06:00:29 --> Output Class Initialized
DEBUG - 2013-09-01 06:00:29 --> Input Class Initialized
DEBUG - 2013-09-01 06:00:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 06:00:29 --> Language Class Initialized
DEBUG - 2013-09-01 06:00:29 --> Security Class Initialized
DEBUG - 2013-09-01 06:00:29 --> Input Class Initialized
DEBUG - 2013-09-01 06:00:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 06:00:29 --> Language Class Initialized
DEBUG - 2013-09-01 06:00:29 --> Loader Class Initialized
DEBUG - 2013-09-01 06:00:29 --> Loader Class Initialized
DEBUG - 2013-09-01 06:00:29 --> Database Driver Class Initialized
DEBUG - 2013-09-01 06:00:29 --> Controller Class Initialized
DEBUG - 2013-09-01 06:00:29 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 06:00:29 --> Database Driver Class Initialized
DEBUG - 2013-09-01 06:00:29 --> Controller Class Initialized
DEBUG - 2013-09-01 06:00:29 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 06:00:29 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 06:00:29 --> Model Class Initialized
DEBUG - 2013-09-01 06:00:29 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 06:00:29 --> Helper loaded: date_helper
DEBUG - 2013-09-01 06:00:29 --> Model Class Initialized
DEBUG - 2013-09-01 06:00:29 --> Model Class Initialized
DEBUG - 2013-09-01 06:00:29 --> Helper loaded: date_helper
DEBUG - 2013-09-01 06:00:29 --> Model Class Initialized
DEBUG - 2013-09-01 06:00:29 --> Model Class Initialized
DEBUG - 2013-09-01 06:00:29 --> XSS Filtering completed
DEBUG - 2013-09-01 06:00:29 --> XSS Filtering completed
DEBUG - 2013-09-01 06:00:29 --> Model Class Initialized
DEBUG - 2013-09-01 06:00:29 --> XSS Filtering completed
DEBUG - 2013-09-01 06:00:29 --> XSS Filtering completed
DEBUG - 2013-09-01 06:00:29 --> XSS Filtering completed
ERROR - 2013-09-01 06:00:29 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 185
ERROR - 2013-09-01 06:00:29 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-01 06:00:29 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-01 06:00:29 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 195
DEBUG - 2013-09-01 06:00:49 --> Config Class Initialized
DEBUG - 2013-09-01 06:00:49 --> Hooks Class Initialized
DEBUG - 2013-09-01 06:00:49 --> Utf8 Class Initialized
DEBUG - 2013-09-01 06:00:49 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 06:00:49 --> URI Class Initialized
DEBUG - 2013-09-01 06:00:49 --> Router Class Initialized
DEBUG - 2013-09-01 06:00:49 --> Output Class Initialized
DEBUG - 2013-09-01 06:00:49 --> Security Class Initialized
DEBUG - 2013-09-01 06:00:49 --> Input Class Initialized
DEBUG - 2013-09-01 06:00:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 06:00:49 --> Language Class Initialized
DEBUG - 2013-09-01 06:00:49 --> Loader Class Initialized
DEBUG - 2013-09-01 06:00:49 --> Database Driver Class Initialized
DEBUG - 2013-09-01 06:00:49 --> Controller Class Initialized
DEBUG - 2013-09-01 06:00:49 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 06:00:49 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 06:00:49 --> Model Class Initialized
DEBUG - 2013-09-01 06:00:49 --> Helper loaded: date_helper
DEBUG - 2013-09-01 06:00:49 --> Model Class Initialized
DEBUG - 2013-09-01 06:00:49 --> Model Class Initialized
DEBUG - 2013-09-01 06:00:49 --> XSS Filtering completed
DEBUG - 2013-09-01 06:00:50 --> Config Class Initialized
DEBUG - 2013-09-01 06:00:50 --> Hooks Class Initialized
DEBUG - 2013-09-01 06:00:50 --> Utf8 Class Initialized
DEBUG - 2013-09-01 06:00:50 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 06:00:50 --> URI Class Initialized
DEBUG - 2013-09-01 06:00:50 --> Router Class Initialized
DEBUG - 2013-09-01 06:00:50 --> Output Class Initialized
DEBUG - 2013-09-01 06:00:50 --> Security Class Initialized
DEBUG - 2013-09-01 06:00:50 --> Input Class Initialized
DEBUG - 2013-09-01 06:00:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 06:00:50 --> Language Class Initialized
DEBUG - 2013-09-01 06:00:50 --> Loader Class Initialized
DEBUG - 2013-09-01 06:00:50 --> Database Driver Class Initialized
DEBUG - 2013-09-01 06:00:50 --> Controller Class Initialized
DEBUG - 2013-09-01 06:00:50 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 06:00:50 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 06:00:50 --> Model Class Initialized
DEBUG - 2013-09-01 06:00:50 --> Helper loaded: date_helper
DEBUG - 2013-09-01 06:00:50 --> Model Class Initialized
DEBUG - 2013-09-01 06:00:50 --> Model Class Initialized
DEBUG - 2013-09-01 06:00:50 --> XSS Filtering completed
DEBUG - 2013-09-01 06:00:50 --> XSS Filtering completed
DEBUG - 2013-09-01 06:00:50 --> Config Class Initialized
DEBUG - 2013-09-01 06:00:50 --> Hooks Class Initialized
DEBUG - 2013-09-01 06:00:50 --> Utf8 Class Initialized
DEBUG - 2013-09-01 06:00:50 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 06:00:50 --> URI Class Initialized
DEBUG - 2013-09-01 06:00:50 --> Router Class Initialized
DEBUG - 2013-09-01 06:00:50 --> Output Class Initialized
DEBUG - 2013-09-01 06:00:50 --> Security Class Initialized
DEBUG - 2013-09-01 06:00:50 --> Input Class Initialized
DEBUG - 2013-09-01 06:00:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 06:00:50 --> Language Class Initialized
DEBUG - 2013-09-01 06:00:50 --> Loader Class Initialized
DEBUG - 2013-09-01 06:00:50 --> Database Driver Class Initialized
DEBUG - 2013-09-01 06:00:50 --> Controller Class Initialized
DEBUG - 2013-09-01 06:00:50 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 06:00:50 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 06:00:50 --> Model Class Initialized
DEBUG - 2013-09-01 06:00:50 --> Helper loaded: date_helper
DEBUG - 2013-09-01 06:00:50 --> Model Class Initialized
DEBUG - 2013-09-01 06:00:50 --> Model Class Initialized
DEBUG - 2013-09-01 06:00:50 --> XSS Filtering completed
DEBUG - 2013-09-01 06:00:50 --> XSS Filtering completed
DEBUG - 2013-09-01 06:00:51 --> Config Class Initialized
DEBUG - 2013-09-01 06:00:51 --> Hooks Class Initialized
DEBUG - 2013-09-01 06:00:51 --> Utf8 Class Initialized
DEBUG - 2013-09-01 06:00:51 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 06:00:51 --> URI Class Initialized
DEBUG - 2013-09-01 06:00:51 --> Router Class Initialized
DEBUG - 2013-09-01 06:00:51 --> Output Class Initialized
DEBUG - 2013-09-01 06:00:51 --> Security Class Initialized
DEBUG - 2013-09-01 06:00:51 --> Input Class Initialized
DEBUG - 2013-09-01 06:00:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 06:00:51 --> Language Class Initialized
DEBUG - 2013-09-01 06:00:51 --> Loader Class Initialized
DEBUG - 2013-09-01 06:00:51 --> Database Driver Class Initialized
DEBUG - 2013-09-01 06:00:51 --> Controller Class Initialized
DEBUG - 2013-09-01 06:00:51 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 06:00:51 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 06:00:51 --> Model Class Initialized
DEBUG - 2013-09-01 06:00:51 --> Helper loaded: date_helper
DEBUG - 2013-09-01 06:00:51 --> Model Class Initialized
DEBUG - 2013-09-01 06:00:51 --> Model Class Initialized
DEBUG - 2013-09-01 06:00:51 --> XSS Filtering completed
DEBUG - 2013-09-01 06:00:51 --> XSS Filtering completed
DEBUG - 2013-09-01 06:00:51 --> Config Class Initialized
DEBUG - 2013-09-01 06:00:51 --> Hooks Class Initialized
DEBUG - 2013-09-01 06:00:51 --> Utf8 Class Initialized
DEBUG - 2013-09-01 06:00:51 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 06:00:51 --> URI Class Initialized
DEBUG - 2013-09-01 06:00:51 --> Router Class Initialized
DEBUG - 2013-09-01 06:00:51 --> Output Class Initialized
DEBUG - 2013-09-01 06:00:51 --> Security Class Initialized
DEBUG - 2013-09-01 06:00:51 --> Input Class Initialized
DEBUG - 2013-09-01 06:00:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 06:00:51 --> Language Class Initialized
DEBUG - 2013-09-01 06:00:51 --> Loader Class Initialized
DEBUG - 2013-09-01 06:00:51 --> Database Driver Class Initialized
DEBUG - 2013-09-01 06:00:51 --> Controller Class Initialized
DEBUG - 2013-09-01 06:00:51 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 06:00:51 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 06:00:51 --> Model Class Initialized
DEBUG - 2013-09-01 06:00:51 --> Helper loaded: date_helper
DEBUG - 2013-09-01 06:00:51 --> Model Class Initialized
DEBUG - 2013-09-01 06:00:51 --> Model Class Initialized
DEBUG - 2013-09-01 06:00:51 --> XSS Filtering completed
DEBUG - 2013-09-01 06:00:51 --> XSS Filtering completed
DEBUG - 2013-09-01 06:00:52 --> Config Class Initialized
DEBUG - 2013-09-01 06:00:52 --> Hooks Class Initialized
DEBUG - 2013-09-01 06:00:52 --> Utf8 Class Initialized
DEBUG - 2013-09-01 06:00:52 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 06:00:52 --> URI Class Initialized
DEBUG - 2013-09-01 06:00:52 --> Router Class Initialized
DEBUG - 2013-09-01 06:00:52 --> Output Class Initialized
DEBUG - 2013-09-01 06:00:52 --> Security Class Initialized
DEBUG - 2013-09-01 06:00:52 --> Input Class Initialized
DEBUG - 2013-09-01 06:00:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 06:00:52 --> Language Class Initialized
DEBUG - 2013-09-01 06:00:52 --> Loader Class Initialized
DEBUG - 2013-09-01 06:00:52 --> Database Driver Class Initialized
DEBUG - 2013-09-01 06:00:52 --> Controller Class Initialized
DEBUG - 2013-09-01 06:00:52 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 06:00:52 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 06:00:52 --> Model Class Initialized
DEBUG - 2013-09-01 06:00:52 --> Helper loaded: date_helper
DEBUG - 2013-09-01 06:00:52 --> Model Class Initialized
DEBUG - 2013-09-01 06:00:52 --> Model Class Initialized
DEBUG - 2013-09-01 06:00:52 --> XSS Filtering completed
DEBUG - 2013-09-01 06:00:52 --> XSS Filtering completed
DEBUG - 2013-09-01 06:00:52 --> Config Class Initialized
DEBUG - 2013-09-01 06:00:52 --> Hooks Class Initialized
DEBUG - 2013-09-01 06:00:52 --> Utf8 Class Initialized
DEBUG - 2013-09-01 06:00:52 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 06:00:52 --> URI Class Initialized
DEBUG - 2013-09-01 06:00:52 --> Router Class Initialized
DEBUG - 2013-09-01 06:00:52 --> Output Class Initialized
DEBUG - 2013-09-01 06:00:52 --> Security Class Initialized
DEBUG - 2013-09-01 06:00:52 --> Input Class Initialized
DEBUG - 2013-09-01 06:00:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 06:00:52 --> Language Class Initialized
DEBUG - 2013-09-01 06:00:52 --> Loader Class Initialized
DEBUG - 2013-09-01 06:00:52 --> Database Driver Class Initialized
DEBUG - 2013-09-01 06:00:52 --> Controller Class Initialized
DEBUG - 2013-09-01 06:00:52 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 06:00:52 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 06:00:52 --> Model Class Initialized
DEBUG - 2013-09-01 06:00:52 --> Helper loaded: date_helper
DEBUG - 2013-09-01 06:00:52 --> Model Class Initialized
DEBUG - 2013-09-01 06:00:52 --> Model Class Initialized
DEBUG - 2013-09-01 06:00:52 --> XSS Filtering completed
DEBUG - 2013-09-01 06:00:52 --> XSS Filtering completed
DEBUG - 2013-09-01 06:00:52 --> Config Class Initialized
DEBUG - 2013-09-01 06:00:52 --> Hooks Class Initialized
DEBUG - 2013-09-01 06:00:52 --> Utf8 Class Initialized
DEBUG - 2013-09-01 06:00:52 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 06:00:52 --> URI Class Initialized
DEBUG - 2013-09-01 06:00:52 --> Router Class Initialized
DEBUG - 2013-09-01 06:00:52 --> Output Class Initialized
DEBUG - 2013-09-01 06:00:52 --> Security Class Initialized
DEBUG - 2013-09-01 06:00:52 --> Input Class Initialized
DEBUG - 2013-09-01 06:00:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 06:00:52 --> Language Class Initialized
DEBUG - 2013-09-01 06:00:52 --> Loader Class Initialized
DEBUG - 2013-09-01 06:00:52 --> Database Driver Class Initialized
DEBUG - 2013-09-01 06:00:52 --> Controller Class Initialized
DEBUG - 2013-09-01 06:00:52 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 06:00:52 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 06:00:52 --> Model Class Initialized
DEBUG - 2013-09-01 06:00:52 --> Helper loaded: date_helper
DEBUG - 2013-09-01 06:00:52 --> Model Class Initialized
DEBUG - 2013-09-01 06:00:52 --> Model Class Initialized
DEBUG - 2013-09-01 06:00:52 --> XSS Filtering completed
DEBUG - 2013-09-01 06:00:52 --> XSS Filtering completed
DEBUG - 2013-09-01 06:00:53 --> Config Class Initialized
DEBUG - 2013-09-01 06:00:53 --> Hooks Class Initialized
DEBUG - 2013-09-01 06:00:53 --> Utf8 Class Initialized
DEBUG - 2013-09-01 06:00:53 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 06:00:53 --> URI Class Initialized
DEBUG - 2013-09-01 06:00:53 --> Router Class Initialized
DEBUG - 2013-09-01 06:00:53 --> Output Class Initialized
DEBUG - 2013-09-01 06:00:53 --> Security Class Initialized
DEBUG - 2013-09-01 06:00:53 --> Input Class Initialized
DEBUG - 2013-09-01 06:00:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 06:00:53 --> Language Class Initialized
DEBUG - 2013-09-01 06:00:53 --> Loader Class Initialized
DEBUG - 2013-09-01 06:00:53 --> Database Driver Class Initialized
DEBUG - 2013-09-01 06:00:53 --> Controller Class Initialized
DEBUG - 2013-09-01 06:00:53 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 06:00:53 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 06:00:53 --> Model Class Initialized
DEBUG - 2013-09-01 06:00:53 --> Helper loaded: date_helper
DEBUG - 2013-09-01 06:00:53 --> Model Class Initialized
DEBUG - 2013-09-01 06:00:53 --> Model Class Initialized
DEBUG - 2013-09-01 06:00:53 --> XSS Filtering completed
DEBUG - 2013-09-01 06:00:53 --> XSS Filtering completed
DEBUG - 2013-09-01 06:00:53 --> Config Class Initialized
DEBUG - 2013-09-01 06:00:53 --> Hooks Class Initialized
DEBUG - 2013-09-01 06:00:53 --> Utf8 Class Initialized
DEBUG - 2013-09-01 06:00:53 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 06:00:53 --> URI Class Initialized
DEBUG - 2013-09-01 06:00:53 --> Router Class Initialized
DEBUG - 2013-09-01 06:00:53 --> Output Class Initialized
DEBUG - 2013-09-01 06:00:53 --> Security Class Initialized
DEBUG - 2013-09-01 06:00:53 --> Input Class Initialized
DEBUG - 2013-09-01 06:00:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 06:00:53 --> Language Class Initialized
DEBUG - 2013-09-01 06:00:53 --> Loader Class Initialized
DEBUG - 2013-09-01 06:00:53 --> Database Driver Class Initialized
DEBUG - 2013-09-01 06:00:53 --> Controller Class Initialized
DEBUG - 2013-09-01 06:00:53 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 06:00:53 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 06:00:53 --> Model Class Initialized
DEBUG - 2013-09-01 06:00:53 --> Helper loaded: date_helper
DEBUG - 2013-09-01 06:00:53 --> Model Class Initialized
DEBUG - 2013-09-01 06:00:53 --> Model Class Initialized
DEBUG - 2013-09-01 06:00:53 --> XSS Filtering completed
DEBUG - 2013-09-01 06:00:53 --> XSS Filtering completed
DEBUG - 2013-09-01 06:00:57 --> Config Class Initialized
DEBUG - 2013-09-01 06:00:57 --> Hooks Class Initialized
DEBUG - 2013-09-01 06:00:57 --> Utf8 Class Initialized
DEBUG - 2013-09-01 06:00:57 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 06:00:57 --> Config Class Initialized
DEBUG - 2013-09-01 06:00:57 --> URI Class Initialized
DEBUG - 2013-09-01 06:00:57 --> Hooks Class Initialized
DEBUG - 2013-09-01 06:00:57 --> Router Class Initialized
DEBUG - 2013-09-01 06:00:57 --> Utf8 Class Initialized
DEBUG - 2013-09-01 06:00:57 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 06:00:57 --> URI Class Initialized
DEBUG - 2013-09-01 06:00:57 --> Router Class Initialized
DEBUG - 2013-09-01 06:00:57 --> Output Class Initialized
DEBUG - 2013-09-01 06:00:57 --> Security Class Initialized
DEBUG - 2013-09-01 06:00:57 --> Output Class Initialized
DEBUG - 2013-09-01 06:00:57 --> Input Class Initialized
DEBUG - 2013-09-01 06:00:57 --> Security Class Initialized
DEBUG - 2013-09-01 06:00:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 06:00:57 --> Language Class Initialized
DEBUG - 2013-09-01 06:00:57 --> Input Class Initialized
DEBUG - 2013-09-01 06:00:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 06:00:57 --> Language Class Initialized
DEBUG - 2013-09-01 06:00:57 --> Loader Class Initialized
DEBUG - 2013-09-01 06:00:57 --> Loader Class Initialized
DEBUG - 2013-09-01 06:00:57 --> Database Driver Class Initialized
DEBUG - 2013-09-01 06:00:57 --> Controller Class Initialized
DEBUG - 2013-09-01 06:00:57 --> Database Driver Class Initialized
DEBUG - 2013-09-01 06:00:57 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 06:00:57 --> Controller Class Initialized
DEBUG - 2013-09-01 06:00:57 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 06:00:57 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 06:00:57 --> Model Class Initialized
DEBUG - 2013-09-01 06:00:57 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 06:00:57 --> Helper loaded: date_helper
DEBUG - 2013-09-01 06:00:57 --> Model Class Initialized
DEBUG - 2013-09-01 06:00:57 --> Model Class Initialized
DEBUG - 2013-09-01 06:00:57 --> Helper loaded: date_helper
DEBUG - 2013-09-01 06:00:57 --> Model Class Initialized
DEBUG - 2013-09-01 06:00:57 --> Model Class Initialized
DEBUG - 2013-09-01 06:00:57 --> XSS Filtering completed
DEBUG - 2013-09-01 06:00:57 --> XSS Filtering completed
DEBUG - 2013-09-01 06:00:57 --> Model Class Initialized
DEBUG - 2013-09-01 06:00:57 --> XSS Filtering completed
DEBUG - 2013-09-01 06:00:57 --> XSS Filtering completed
DEBUG - 2013-09-01 06:00:57 --> XSS Filtering completed
ERROR - 2013-09-01 06:00:57 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 185
ERROR - 2013-09-01 06:00:57 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-01 06:00:57 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-01 06:00:57 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 195
DEBUG - 2013-09-01 06:01:00 --> Config Class Initialized
DEBUG - 2013-09-01 06:01:00 --> Hooks Class Initialized
DEBUG - 2013-09-01 06:01:00 --> Utf8 Class Initialized
DEBUG - 2013-09-01 06:01:00 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 06:01:00 --> URI Class Initialized
DEBUG - 2013-09-01 06:01:00 --> Config Class Initialized
DEBUG - 2013-09-01 06:01:00 --> Hooks Class Initialized
DEBUG - 2013-09-01 06:01:00 --> Router Class Initialized
DEBUG - 2013-09-01 06:01:00 --> Utf8 Class Initialized
DEBUG - 2013-09-01 06:01:00 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 06:01:00 --> URI Class Initialized
DEBUG - 2013-09-01 06:01:00 --> Output Class Initialized
DEBUG - 2013-09-01 06:01:00 --> Router Class Initialized
DEBUG - 2013-09-01 06:01:00 --> Security Class Initialized
DEBUG - 2013-09-01 06:01:00 --> Output Class Initialized
DEBUG - 2013-09-01 06:01:00 --> Input Class Initialized
DEBUG - 2013-09-01 06:01:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 06:01:00 --> Language Class Initialized
DEBUG - 2013-09-01 06:01:00 --> Security Class Initialized
DEBUG - 2013-09-01 06:01:00 --> Input Class Initialized
DEBUG - 2013-09-01 06:01:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 06:01:00 --> Language Class Initialized
DEBUG - 2013-09-01 06:01:00 --> Loader Class Initialized
DEBUG - 2013-09-01 06:01:00 --> Loader Class Initialized
DEBUG - 2013-09-01 06:01:00 --> Database Driver Class Initialized
DEBUG - 2013-09-01 06:01:00 --> Database Driver Class Initialized
DEBUG - 2013-09-01 06:01:00 --> Controller Class Initialized
DEBUG - 2013-09-01 06:01:00 --> Controller Class Initialized
DEBUG - 2013-09-01 06:01:00 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 06:01:00 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 06:01:00 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 06:01:00 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 06:01:00 --> Model Class Initialized
DEBUG - 2013-09-01 06:01:00 --> Model Class Initialized
DEBUG - 2013-09-01 06:01:00 --> Helper loaded: date_helper
DEBUG - 2013-09-01 06:01:00 --> Helper loaded: date_helper
DEBUG - 2013-09-01 06:01:00 --> Model Class Initialized
DEBUG - 2013-09-01 06:01:00 --> Model Class Initialized
DEBUG - 2013-09-01 06:01:00 --> Model Class Initialized
DEBUG - 2013-09-01 06:01:00 --> Model Class Initialized
DEBUG - 2013-09-01 06:01:00 --> XSS Filtering completed
DEBUG - 2013-09-01 06:01:00 --> XSS Filtering completed
DEBUG - 2013-09-01 06:01:00 --> XSS Filtering completed
ERROR - 2013-09-01 06:01:00 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 185
ERROR - 2013-09-01 06:01:00 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-01 06:01:00 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-01 06:01:00 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 195
DEBUG - 2013-09-01 06:01:02 --> Config Class Initialized
DEBUG - 2013-09-01 06:01:02 --> Hooks Class Initialized
DEBUG - 2013-09-01 06:01:02 --> Utf8 Class Initialized
DEBUG - 2013-09-01 06:01:02 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 06:01:02 --> URI Class Initialized
DEBUG - 2013-09-01 06:01:02 --> Router Class Initialized
DEBUG - 2013-09-01 06:01:02 --> Config Class Initialized
DEBUG - 2013-09-01 06:01:02 --> Hooks Class Initialized
DEBUG - 2013-09-01 06:01:02 --> Utf8 Class Initialized
DEBUG - 2013-09-01 06:01:02 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 06:01:02 --> Output Class Initialized
DEBUG - 2013-09-01 06:01:02 --> URI Class Initialized
DEBUG - 2013-09-01 06:01:02 --> Security Class Initialized
DEBUG - 2013-09-01 06:01:02 --> Router Class Initialized
DEBUG - 2013-09-01 06:01:02 --> Input Class Initialized
DEBUG - 2013-09-01 06:01:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 06:01:02 --> Language Class Initialized
DEBUG - 2013-09-01 06:01:02 --> Output Class Initialized
DEBUG - 2013-09-01 06:01:02 --> Security Class Initialized
DEBUG - 2013-09-01 06:01:02 --> Input Class Initialized
DEBUG - 2013-09-01 06:01:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 06:01:02 --> Language Class Initialized
DEBUG - 2013-09-01 06:01:02 --> Loader Class Initialized
DEBUG - 2013-09-01 06:01:02 --> Loader Class Initialized
DEBUG - 2013-09-01 06:01:02 --> Database Driver Class Initialized
DEBUG - 2013-09-01 06:01:02 --> Controller Class Initialized
DEBUG - 2013-09-01 06:01:02 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 06:01:02 --> Database Driver Class Initialized
DEBUG - 2013-09-01 06:01:02 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 06:01:02 --> Controller Class Initialized
DEBUG - 2013-09-01 06:01:02 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 06:01:02 --> Model Class Initialized
DEBUG - 2013-09-01 06:01:02 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 06:01:02 --> Helper loaded: date_helper
DEBUG - 2013-09-01 06:01:02 --> Model Class Initialized
DEBUG - 2013-09-01 06:01:02 --> Model Class Initialized
DEBUG - 2013-09-01 06:01:02 --> Helper loaded: date_helper
DEBUG - 2013-09-01 06:01:02 --> Model Class Initialized
DEBUG - 2013-09-01 06:01:02 --> Model Class Initialized
DEBUG - 2013-09-01 06:01:02 --> XSS Filtering completed
DEBUG - 2013-09-01 06:01:02 --> XSS Filtering completed
DEBUG - 2013-09-01 06:01:02 --> Model Class Initialized
DEBUG - 2013-09-01 06:01:02 --> XSS Filtering completed
ERROR - 2013-09-01 06:01:02 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 185
ERROR - 2013-09-01 06:01:02 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-01 06:01:02 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-01 06:01:02 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 195
DEBUG - 2013-09-01 06:01:04 --> Config Class Initialized
DEBUG - 2013-09-01 06:01:04 --> Hooks Class Initialized
DEBUG - 2013-09-01 06:01:04 --> Utf8 Class Initialized
DEBUG - 2013-09-01 06:01:04 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 06:01:04 --> URI Class Initialized
DEBUG - 2013-09-01 06:01:04 --> Config Class Initialized
DEBUG - 2013-09-01 06:01:04 --> Router Class Initialized
DEBUG - 2013-09-01 06:01:04 --> Hooks Class Initialized
DEBUG - 2013-09-01 06:01:04 --> Utf8 Class Initialized
DEBUG - 2013-09-01 06:01:04 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 06:01:04 --> Output Class Initialized
DEBUG - 2013-09-01 06:01:04 --> URI Class Initialized
DEBUG - 2013-09-01 06:01:04 --> Security Class Initialized
DEBUG - 2013-09-01 06:01:04 --> Router Class Initialized
DEBUG - 2013-09-01 06:01:04 --> Input Class Initialized
DEBUG - 2013-09-01 06:01:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 06:01:04 --> Output Class Initialized
DEBUG - 2013-09-01 06:01:04 --> Language Class Initialized
DEBUG - 2013-09-01 06:01:04 --> Security Class Initialized
DEBUG - 2013-09-01 06:01:04 --> Input Class Initialized
DEBUG - 2013-09-01 06:01:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 06:01:04 --> Language Class Initialized
DEBUG - 2013-09-01 06:01:04 --> Loader Class Initialized
DEBUG - 2013-09-01 06:01:04 --> Loader Class Initialized
DEBUG - 2013-09-01 06:01:04 --> Database Driver Class Initialized
DEBUG - 2013-09-01 06:01:04 --> Controller Class Initialized
DEBUG - 2013-09-01 06:01:04 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 06:01:04 --> Database Driver Class Initialized
DEBUG - 2013-09-01 06:01:04 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 06:01:04 --> Controller Class Initialized
DEBUG - 2013-09-01 06:01:04 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 06:01:04 --> Model Class Initialized
DEBUG - 2013-09-01 06:01:04 --> Helper loaded: date_helper
DEBUG - 2013-09-01 06:01:04 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 06:01:04 --> Model Class Initialized
DEBUG - 2013-09-01 06:01:04 --> Model Class Initialized
DEBUG - 2013-09-01 06:01:04 --> Model Class Initialized
DEBUG - 2013-09-01 06:01:04 --> Helper loaded: date_helper
DEBUG - 2013-09-01 06:01:04 --> Model Class Initialized
DEBUG - 2013-09-01 06:01:04 --> XSS Filtering completed
DEBUG - 2013-09-01 06:01:04 --> XSS Filtering completed
DEBUG - 2013-09-01 06:01:04 --> Model Class Initialized
DEBUG - 2013-09-01 06:01:04 --> XSS Filtering completed
ERROR - 2013-09-01 06:01:04 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 185
ERROR - 2013-09-01 06:01:04 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-01 06:01:04 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-01 06:01:04 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 195
DEBUG - 2013-09-01 06:01:24 --> Config Class Initialized
DEBUG - 2013-09-01 06:01:24 --> Hooks Class Initialized
DEBUG - 2013-09-01 06:01:24 --> Utf8 Class Initialized
DEBUG - 2013-09-01 06:01:24 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 06:01:24 --> URI Class Initialized
DEBUG - 2013-09-01 06:01:24 --> Config Class Initialized
DEBUG - 2013-09-01 06:01:24 --> Hooks Class Initialized
DEBUG - 2013-09-01 06:01:24 --> Router Class Initialized
DEBUG - 2013-09-01 06:01:24 --> Utf8 Class Initialized
DEBUG - 2013-09-01 06:01:24 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 06:01:24 --> URI Class Initialized
DEBUG - 2013-09-01 06:01:24 --> Output Class Initialized
DEBUG - 2013-09-01 06:01:24 --> Router Class Initialized
DEBUG - 2013-09-01 06:01:24 --> Security Class Initialized
DEBUG - 2013-09-01 06:01:24 --> Input Class Initialized
DEBUG - 2013-09-01 06:01:24 --> Output Class Initialized
DEBUG - 2013-09-01 06:01:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 06:01:24 --> Language Class Initialized
DEBUG - 2013-09-01 06:01:24 --> Security Class Initialized
DEBUG - 2013-09-01 06:01:24 --> Input Class Initialized
DEBUG - 2013-09-01 06:01:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 06:01:24 --> Language Class Initialized
DEBUG - 2013-09-01 06:01:24 --> Loader Class Initialized
DEBUG - 2013-09-01 06:01:24 --> Loader Class Initialized
DEBUG - 2013-09-01 06:01:24 --> Database Driver Class Initialized
DEBUG - 2013-09-01 06:01:24 --> Controller Class Initialized
DEBUG - 2013-09-01 06:01:24 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 06:01:24 --> Database Driver Class Initialized
DEBUG - 2013-09-01 06:01:24 --> Controller Class Initialized
DEBUG - 2013-09-01 06:01:24 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 06:01:24 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 06:01:24 --> Model Class Initialized
DEBUG - 2013-09-01 06:01:24 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 06:01:24 --> Helper loaded: date_helper
DEBUG - 2013-09-01 06:01:24 --> Model Class Initialized
DEBUG - 2013-09-01 06:01:24 --> Model Class Initialized
DEBUG - 2013-09-01 06:01:24 --> Helper loaded: date_helper
DEBUG - 2013-09-01 06:01:24 --> Model Class Initialized
DEBUG - 2013-09-01 06:01:24 --> Model Class Initialized
DEBUG - 2013-09-01 06:01:24 --> XSS Filtering completed
DEBUG - 2013-09-01 06:01:24 --> Model Class Initialized
DEBUG - 2013-09-01 06:01:24 --> XSS Filtering completed
DEBUG - 2013-09-01 06:01:24 --> XSS Filtering completed
DEBUG - 2013-09-01 06:01:24 --> XSS Filtering completed
DEBUG - 2013-09-01 06:01:24 --> XSS Filtering completed
DEBUG - 2013-09-01 06:01:24 --> XSS Filtering completed
ERROR - 2013-09-01 06:01:24 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 185
ERROR - 2013-09-01 06:01:24 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-01 06:01:24 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-01 06:01:24 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 195
DEBUG - 2013-09-01 06:01:26 --> Config Class Initialized
DEBUG - 2013-09-01 06:01:26 --> Hooks Class Initialized
DEBUG - 2013-09-01 06:01:26 --> Utf8 Class Initialized
DEBUG - 2013-09-01 06:01:26 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 06:01:26 --> URI Class Initialized
DEBUG - 2013-09-01 06:01:26 --> Router Class Initialized
DEBUG - 2013-09-01 06:01:26 --> Config Class Initialized
DEBUG - 2013-09-01 06:01:26 --> Hooks Class Initialized
DEBUG - 2013-09-01 06:01:26 --> Utf8 Class Initialized
DEBUG - 2013-09-01 06:01:26 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 06:01:26 --> Output Class Initialized
DEBUG - 2013-09-01 06:01:26 --> URI Class Initialized
DEBUG - 2013-09-01 06:01:26 --> Security Class Initialized
DEBUG - 2013-09-01 06:01:26 --> Router Class Initialized
DEBUG - 2013-09-01 06:01:26 --> Input Class Initialized
DEBUG - 2013-09-01 06:01:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 06:01:26 --> Output Class Initialized
DEBUG - 2013-09-01 06:01:26 --> Language Class Initialized
DEBUG - 2013-09-01 06:01:26 --> Security Class Initialized
DEBUG - 2013-09-01 06:01:26 --> Input Class Initialized
DEBUG - 2013-09-01 06:01:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 06:01:26 --> Language Class Initialized
DEBUG - 2013-09-01 06:01:26 --> Loader Class Initialized
DEBUG - 2013-09-01 06:01:26 --> Loader Class Initialized
DEBUG - 2013-09-01 06:01:26 --> Database Driver Class Initialized
DEBUG - 2013-09-01 06:01:26 --> Controller Class Initialized
DEBUG - 2013-09-01 06:01:26 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 06:01:26 --> Database Driver Class Initialized
DEBUG - 2013-09-01 06:01:26 --> Controller Class Initialized
DEBUG - 2013-09-01 06:01:26 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 06:01:26 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 06:01:26 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 06:01:26 --> Model Class Initialized
DEBUG - 2013-09-01 06:01:26 --> Model Class Initialized
DEBUG - 2013-09-01 06:01:26 --> Helper loaded: date_helper
DEBUG - 2013-09-01 06:01:26 --> Model Class Initialized
DEBUG - 2013-09-01 06:01:26 --> Helper loaded: date_helper
DEBUG - 2013-09-01 06:01:26 --> Model Class Initialized
DEBUG - 2013-09-01 06:01:26 --> Model Class Initialized
DEBUG - 2013-09-01 06:01:26 --> Model Class Initialized
DEBUG - 2013-09-01 06:01:26 --> XSS Filtering completed
DEBUG - 2013-09-01 06:01:26 --> XSS Filtering completed
DEBUG - 2013-09-01 06:01:26 --> XSS Filtering completed
DEBUG - 2013-09-01 06:01:26 --> XSS Filtering completed
DEBUG - 2013-09-01 06:01:26 --> XSS Filtering completed
DEBUG - 2013-09-01 06:01:26 --> XSS Filtering completed
ERROR - 2013-09-01 06:01:26 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 185
ERROR - 2013-09-01 06:01:26 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-01 06:01:26 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-01 06:01:26 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 195
DEBUG - 2013-09-01 06:01:29 --> Config Class Initialized
DEBUG - 2013-09-01 06:01:29 --> Hooks Class Initialized
DEBUG - 2013-09-01 06:01:29 --> Utf8 Class Initialized
DEBUG - 2013-09-01 06:01:29 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 06:01:29 --> URI Class Initialized
DEBUG - 2013-09-01 06:01:29 --> Router Class Initialized
DEBUG - 2013-09-01 06:01:29 --> Config Class Initialized
DEBUG - 2013-09-01 06:01:29 --> Hooks Class Initialized
DEBUG - 2013-09-01 06:01:29 --> Utf8 Class Initialized
DEBUG - 2013-09-01 06:01:29 --> Output Class Initialized
DEBUG - 2013-09-01 06:01:29 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 06:01:29 --> URI Class Initialized
DEBUG - 2013-09-01 06:01:29 --> Security Class Initialized
DEBUG - 2013-09-01 06:01:29 --> Router Class Initialized
DEBUG - 2013-09-01 06:01:29 --> Input Class Initialized
DEBUG - 2013-09-01 06:01:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 06:01:29 --> Language Class Initialized
DEBUG - 2013-09-01 06:01:29 --> Output Class Initialized
DEBUG - 2013-09-01 06:01:29 --> Security Class Initialized
DEBUG - 2013-09-01 06:01:29 --> Input Class Initialized
DEBUG - 2013-09-01 06:01:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 06:01:29 --> Language Class Initialized
DEBUG - 2013-09-01 06:01:29 --> Loader Class Initialized
DEBUG - 2013-09-01 06:01:29 --> Loader Class Initialized
DEBUG - 2013-09-01 06:01:29 --> Database Driver Class Initialized
DEBUG - 2013-09-01 06:01:29 --> Controller Class Initialized
DEBUG - 2013-09-01 06:01:29 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 06:01:29 --> Database Driver Class Initialized
DEBUG - 2013-09-01 06:01:29 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 06:01:29 --> Controller Class Initialized
DEBUG - 2013-09-01 06:01:29 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 06:01:29 --> Model Class Initialized
DEBUG - 2013-09-01 06:01:29 --> Helper loaded: date_helper
DEBUG - 2013-09-01 06:01:29 --> Model Class Initialized
DEBUG - 2013-09-01 06:01:29 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 06:01:29 --> Model Class Initialized
DEBUG - 2013-09-01 06:01:29 --> Model Class Initialized
DEBUG - 2013-09-01 06:01:29 --> Helper loaded: date_helper
DEBUG - 2013-09-01 06:01:29 --> Model Class Initialized
DEBUG - 2013-09-01 06:01:29 --> XSS Filtering completed
DEBUG - 2013-09-01 06:01:29 --> XSS Filtering completed
DEBUG - 2013-09-01 06:01:29 --> XSS Filtering completed
DEBUG - 2013-09-01 06:01:29 --> XSS Filtering completed
DEBUG - 2013-09-01 06:01:29 --> Model Class Initialized
DEBUG - 2013-09-01 06:01:29 --> XSS Filtering completed
DEBUG - 2013-09-01 06:01:29 --> XSS Filtering completed
ERROR - 2013-09-01 06:01:29 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 185
ERROR - 2013-09-01 06:01:29 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-01 06:01:29 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-01 06:01:29 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 195
DEBUG - 2013-09-01 06:01:34 --> Config Class Initialized
DEBUG - 2013-09-01 06:01:34 --> Hooks Class Initialized
DEBUG - 2013-09-01 06:01:34 --> Utf8 Class Initialized
DEBUG - 2013-09-01 06:01:34 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 06:01:34 --> Config Class Initialized
DEBUG - 2013-09-01 06:01:34 --> URI Class Initialized
DEBUG - 2013-09-01 06:01:34 --> Hooks Class Initialized
DEBUG - 2013-09-01 06:01:34 --> Utf8 Class Initialized
DEBUG - 2013-09-01 06:01:34 --> Router Class Initialized
DEBUG - 2013-09-01 06:01:34 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 06:01:34 --> URI Class Initialized
DEBUG - 2013-09-01 06:01:34 --> Output Class Initialized
DEBUG - 2013-09-01 06:01:34 --> Router Class Initialized
DEBUG - 2013-09-01 06:01:34 --> Security Class Initialized
DEBUG - 2013-09-01 06:01:34 --> Output Class Initialized
DEBUG - 2013-09-01 06:01:34 --> Input Class Initialized
DEBUG - 2013-09-01 06:01:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 06:01:34 --> Security Class Initialized
DEBUG - 2013-09-01 06:01:34 --> Language Class Initialized
DEBUG - 2013-09-01 06:01:34 --> Input Class Initialized
DEBUG - 2013-09-01 06:01:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 06:01:34 --> Language Class Initialized
DEBUG - 2013-09-01 06:01:34 --> Loader Class Initialized
DEBUG - 2013-09-01 06:01:34 --> Loader Class Initialized
DEBUG - 2013-09-01 06:01:34 --> Database Driver Class Initialized
DEBUG - 2013-09-01 06:01:34 --> Database Driver Class Initialized
DEBUG - 2013-09-01 06:01:34 --> Controller Class Initialized
DEBUG - 2013-09-01 06:01:34 --> Controller Class Initialized
DEBUG - 2013-09-01 06:01:34 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 06:01:34 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 06:01:34 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 06:01:34 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 06:01:34 --> Model Class Initialized
DEBUG - 2013-09-01 06:01:34 --> Model Class Initialized
DEBUG - 2013-09-01 06:01:34 --> Helper loaded: date_helper
DEBUG - 2013-09-01 06:01:34 --> Helper loaded: date_helper
DEBUG - 2013-09-01 06:01:34 --> Model Class Initialized
DEBUG - 2013-09-01 06:01:34 --> Model Class Initialized
DEBUG - 2013-09-01 06:01:34 --> Model Class Initialized
DEBUG - 2013-09-01 06:01:34 --> Model Class Initialized
DEBUG - 2013-09-01 06:01:34 --> XSS Filtering completed
DEBUG - 2013-09-01 06:01:34 --> XSS Filtering completed
DEBUG - 2013-09-01 06:01:34 --> XSS Filtering completed
DEBUG - 2013-09-01 06:01:34 --> XSS Filtering completed
ERROR - 2013-09-01 06:01:34 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 185
DEBUG - 2013-09-01 06:01:34 --> XSS Filtering completed
ERROR - 2013-09-01 06:01:34 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-01 06:01:34 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-01 06:01:34 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 195
DEBUG - 2013-09-01 06:01:37 --> Config Class Initialized
DEBUG - 2013-09-01 06:01:37 --> Hooks Class Initialized
DEBUG - 2013-09-01 06:01:37 --> Utf8 Class Initialized
DEBUG - 2013-09-01 06:01:37 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 06:01:37 --> URI Class Initialized
DEBUG - 2013-09-01 06:01:37 --> Config Class Initialized
DEBUG - 2013-09-01 06:01:37 --> Router Class Initialized
DEBUG - 2013-09-01 06:01:37 --> Hooks Class Initialized
DEBUG - 2013-09-01 06:01:37 --> Utf8 Class Initialized
DEBUG - 2013-09-01 06:01:37 --> UTF-8 Support Enabled
DEBUG - 2013-09-01 06:01:37 --> Output Class Initialized
DEBUG - 2013-09-01 06:01:37 --> URI Class Initialized
DEBUG - 2013-09-01 06:01:37 --> Security Class Initialized
DEBUG - 2013-09-01 06:01:37 --> Router Class Initialized
DEBUG - 2013-09-01 06:01:37 --> Input Class Initialized
DEBUG - 2013-09-01 06:01:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 06:01:37 --> Output Class Initialized
DEBUG - 2013-09-01 06:01:37 --> Language Class Initialized
DEBUG - 2013-09-01 06:01:37 --> Security Class Initialized
DEBUG - 2013-09-01 06:01:37 --> Input Class Initialized
DEBUG - 2013-09-01 06:01:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-01 06:01:37 --> Language Class Initialized
DEBUG - 2013-09-01 06:01:37 --> Loader Class Initialized
DEBUG - 2013-09-01 06:01:37 --> Loader Class Initialized
DEBUG - 2013-09-01 06:01:37 --> Database Driver Class Initialized
DEBUG - 2013-09-01 06:01:37 --> Controller Class Initialized
DEBUG - 2013-09-01 06:01:37 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 06:01:37 --> Database Driver Class Initialized
DEBUG - 2013-09-01 06:01:37 --> Controller Class Initialized
DEBUG - 2013-09-01 06:01:37 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-01 06:01:37 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 06:01:37 --> Model Class Initialized
DEBUG - 2013-09-01 06:01:37 --> Helper loaded: inflector_helper
DEBUG - 2013-09-01 06:01:37 --> Helper loaded: date_helper
DEBUG - 2013-09-01 06:01:37 --> Model Class Initialized
DEBUG - 2013-09-01 06:01:37 --> Model Class Initialized
DEBUG - 2013-09-01 06:01:37 --> Helper loaded: date_helper
DEBUG - 2013-09-01 06:01:37 --> Model Class Initialized
DEBUG - 2013-09-01 06:01:37 --> Model Class Initialized
DEBUG - 2013-09-01 06:01:37 --> Model Class Initialized
DEBUG - 2013-09-01 06:01:37 --> XSS Filtering completed
DEBUG - 2013-09-01 06:01:37 --> XSS Filtering completed
DEBUG - 2013-09-01 06:01:38 --> XSS Filtering completed
DEBUG - 2013-09-01 06:01:38 --> XSS Filtering completed
DEBUG - 2013-09-01 06:01:38 --> XSS Filtering completed
ERROR - 2013-09-01 06:01:38 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 185
ERROR - 2013-09-01 06:01:38 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-01 06:01:38 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 190
ERROR - 2013-09-01 06:01:38 --> Severity: Notice  --> Undefined variable: grouping C:\xampp2\htdocs\bigas2hack\application\controllers\users.php 195
