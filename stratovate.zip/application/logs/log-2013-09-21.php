<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-09-21 04:19:47 --> Config Class Initialized
DEBUG - 2013-09-21 04:19:47 --> Hooks Class Initialized
DEBUG - 2013-09-21 04:19:47 --> Utf8 Class Initialized
DEBUG - 2013-09-21 04:19:47 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 04:19:47 --> URI Class Initialized
DEBUG - 2013-09-21 04:19:47 --> Router Class Initialized
DEBUG - 2013-09-21 04:19:47 --> No URI present. Default controller set.
DEBUG - 2013-09-21 04:19:47 --> Output Class Initialized
DEBUG - 2013-09-21 04:19:47 --> Security Class Initialized
DEBUG - 2013-09-21 04:19:47 --> Input Class Initialized
DEBUG - 2013-09-21 04:19:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 04:19:47 --> Language Class Initialized
DEBUG - 2013-09-21 04:19:47 --> Loader Class Initialized
DEBUG - 2013-09-21 04:19:47 --> Database Driver Class Initialized
DEBUG - 2013-09-21 04:19:48 --> Controller Class Initialized
DEBUG - 2013-09-21 04:19:48 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 04:19:48 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 04:19:48 --> Model Class Initialized
DEBUG - 2013-09-21 04:19:48 --> Helper loaded: date_helper
DEBUG - 2013-09-21 04:19:48 --> Model Class Initialized
DEBUG - 2013-09-21 04:19:48 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 04:19:48 --> Final output sent to browser
DEBUG - 2013-09-21 04:19:48 --> Total execution time: 0.7800
DEBUG - 2013-09-21 04:20:30 --> Config Class Initialized
DEBUG - 2013-09-21 04:20:30 --> Hooks Class Initialized
DEBUG - 2013-09-21 04:20:30 --> Utf8 Class Initialized
DEBUG - 2013-09-21 04:20:30 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 04:20:30 --> URI Class Initialized
DEBUG - 2013-09-21 04:20:30 --> Router Class Initialized
DEBUG - 2013-09-21 04:20:30 --> Output Class Initialized
DEBUG - 2013-09-21 04:20:30 --> Security Class Initialized
DEBUG - 2013-09-21 04:20:30 --> Input Class Initialized
DEBUG - 2013-09-21 04:20:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 04:20:30 --> Language Class Initialized
DEBUG - 2013-09-21 04:20:30 --> Loader Class Initialized
DEBUG - 2013-09-21 04:20:30 --> Database Driver Class Initialized
DEBUG - 2013-09-21 04:20:30 --> Controller Class Initialized
DEBUG - 2013-09-21 04:20:30 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 04:20:30 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 04:20:30 --> Model Class Initialized
DEBUG - 2013-09-21 04:20:30 --> Helper loaded: date_helper
DEBUG - 2013-09-21 04:20:30 --> Model Class Initialized
DEBUG - 2013-09-21 04:20:30 --> Database Driver Class Initialized
DEBUG - 2013-09-21 04:20:30 --> Controller Class Initialized
DEBUG - 2013-09-21 04:20:30 --> Database Driver Class Initialized
DEBUG - 2013-09-21 04:20:30 --> Controller Class Initialized
DEBUG - 2013-09-21 04:20:30 --> Model Class Initialized
DEBUG - 2013-09-21 04:20:30 --> Model Class Initialized
DEBUG - 2013-09-21 04:20:30 --> Database Driver Class Initialized
DEBUG - 2013-09-21 04:20:30 --> Controller Class Initialized
DEBUG - 2013-09-21 04:20:30 --> Config Class Initialized
DEBUG - 2013-09-21 04:20:30 --> Hooks Class Initialized
DEBUG - 2013-09-21 04:20:30 --> Utf8 Class Initialized
DEBUG - 2013-09-21 04:20:30 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 04:20:30 --> URI Class Initialized
DEBUG - 2013-09-21 04:20:30 --> Router Class Initialized
DEBUG - 2013-09-21 04:20:30 --> Output Class Initialized
DEBUG - 2013-09-21 04:20:30 --> Security Class Initialized
DEBUG - 2013-09-21 04:20:30 --> Input Class Initialized
DEBUG - 2013-09-21 04:20:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 04:20:30 --> Language Class Initialized
DEBUG - 2013-09-21 04:20:30 --> Loader Class Initialized
DEBUG - 2013-09-21 04:20:30 --> Database Driver Class Initialized
DEBUG - 2013-09-21 04:20:30 --> Controller Class Initialized
DEBUG - 2013-09-21 04:20:30 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 04:20:30 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 04:20:30 --> Model Class Initialized
DEBUG - 2013-09-21 04:20:30 --> Helper loaded: date_helper
DEBUG - 2013-09-21 04:20:30 --> Model Class Initialized
DEBUG - 2013-09-21 04:20:30 --> Database Driver Class Initialized
DEBUG - 2013-09-21 04:20:30 --> Controller Class Initialized
DEBUG - 2013-09-21 04:20:30 --> Database Driver Class Initialized
DEBUG - 2013-09-21 04:20:30 --> Controller Class Initialized
DEBUG - 2013-09-21 04:20:30 --> Model Class Initialized
DEBUG - 2013-09-21 04:20:30 --> Model Class Initialized
DEBUG - 2013-09-21 04:20:30 --> Database Driver Class Initialized
DEBUG - 2013-09-21 04:20:30 --> Controller Class Initialized
DEBUG - 2013-09-21 06:47:45 --> Config Class Initialized
DEBUG - 2013-09-21 06:47:45 --> Hooks Class Initialized
DEBUG - 2013-09-21 06:47:45 --> Utf8 Class Initialized
DEBUG - 2013-09-21 06:47:45 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 06:47:45 --> URI Class Initialized
DEBUG - 2013-09-21 06:47:45 --> Router Class Initialized
DEBUG - 2013-09-21 06:47:45 --> Output Class Initialized
DEBUG - 2013-09-21 06:47:45 --> Security Class Initialized
DEBUG - 2013-09-21 06:47:45 --> Input Class Initialized
DEBUG - 2013-09-21 06:47:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 06:47:45 --> Language Class Initialized
DEBUG - 2013-09-21 06:47:45 --> Loader Class Initialized
DEBUG - 2013-09-21 06:47:45 --> Database Driver Class Initialized
DEBUG - 2013-09-21 06:47:45 --> Controller Class Initialized
DEBUG - 2013-09-21 06:47:45 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 06:47:45 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 06:47:45 --> Model Class Initialized
DEBUG - 2013-09-21 06:47:45 --> Helper loaded: date_helper
DEBUG - 2013-09-21 06:47:45 --> Model Class Initialized
DEBUG - 2013-09-21 06:47:45 --> Database Driver Class Initialized
DEBUG - 2013-09-21 06:47:45 --> Controller Class Initialized
DEBUG - 2013-09-21 06:47:45 --> Model Class Initialized
DEBUG - 2013-09-21 06:47:45 --> Model Class Initialized
DEBUG - 2013-09-21 06:47:45 --> Database Driver Class Initialized
DEBUG - 2013-09-21 06:47:45 --> Controller Class Initialized
DEBUG - 2013-09-21 06:47:45 --> Config Class Initialized
DEBUG - 2013-09-21 06:47:45 --> Hooks Class Initialized
DEBUG - 2013-09-21 06:47:45 --> Utf8 Class Initialized
DEBUG - 2013-09-21 06:47:45 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 06:47:45 --> URI Class Initialized
DEBUG - 2013-09-21 06:47:45 --> Router Class Initialized
DEBUG - 2013-09-21 06:47:45 --> Output Class Initialized
DEBUG - 2013-09-21 06:47:45 --> Security Class Initialized
DEBUG - 2013-09-21 06:47:45 --> Input Class Initialized
DEBUG - 2013-09-21 06:47:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 06:47:45 --> Language Class Initialized
DEBUG - 2013-09-21 06:47:45 --> Loader Class Initialized
DEBUG - 2013-09-21 06:47:45 --> Database Driver Class Initialized
DEBUG - 2013-09-21 06:47:45 --> Controller Class Initialized
DEBUG - 2013-09-21 06:47:45 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 06:47:45 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 06:47:45 --> Model Class Initialized
DEBUG - 2013-09-21 06:47:45 --> Helper loaded: date_helper
DEBUG - 2013-09-21 06:47:45 --> Model Class Initialized
DEBUG - 2013-09-21 06:47:45 --> Database Driver Class Initialized
DEBUG - 2013-09-21 06:47:45 --> Controller Class Initialized
DEBUG - 2013-09-21 06:47:45 --> Model Class Initialized
DEBUG - 2013-09-21 06:47:45 --> Model Class Initialized
DEBUG - 2013-09-21 06:47:45 --> Database Driver Class Initialized
DEBUG - 2013-09-21 06:47:45 --> Controller Class Initialized
DEBUG - 2013-09-21 07:47:40 --> Config Class Initialized
DEBUG - 2013-09-21 07:47:40 --> Hooks Class Initialized
DEBUG - 2013-09-21 07:47:40 --> Utf8 Class Initialized
DEBUG - 2013-09-21 07:47:40 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 07:47:40 --> URI Class Initialized
DEBUG - 2013-09-21 07:47:40 --> Router Class Initialized
DEBUG - 2013-09-21 07:47:40 --> Output Class Initialized
DEBUG - 2013-09-21 07:47:40 --> Security Class Initialized
DEBUG - 2013-09-21 07:47:40 --> Input Class Initialized
DEBUG - 2013-09-21 07:47:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 07:47:40 --> Language Class Initialized
DEBUG - 2013-09-21 07:47:40 --> Loader Class Initialized
DEBUG - 2013-09-21 07:47:40 --> Database Driver Class Initialized
DEBUG - 2013-09-21 07:47:40 --> Controller Class Initialized
DEBUG - 2013-09-21 07:47:40 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 07:47:40 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 07:47:40 --> Model Class Initialized
DEBUG - 2013-09-21 07:47:40 --> Helper loaded: date_helper
DEBUG - 2013-09-21 07:47:50 --> Config Class Initialized
DEBUG - 2013-09-21 07:47:50 --> Hooks Class Initialized
DEBUG - 2013-09-21 07:47:50 --> Utf8 Class Initialized
DEBUG - 2013-09-21 07:47:50 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 07:47:50 --> URI Class Initialized
DEBUG - 2013-09-21 07:47:50 --> Router Class Initialized
DEBUG - 2013-09-21 07:47:50 --> Output Class Initialized
DEBUG - 2013-09-21 07:47:50 --> Security Class Initialized
DEBUG - 2013-09-21 07:47:50 --> Input Class Initialized
DEBUG - 2013-09-21 07:47:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 07:47:50 --> Language Class Initialized
DEBUG - 2013-09-21 07:47:50 --> Loader Class Initialized
DEBUG - 2013-09-21 07:47:50 --> Database Driver Class Initialized
DEBUG - 2013-09-21 07:47:50 --> Controller Class Initialized
DEBUG - 2013-09-21 07:47:50 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 07:47:50 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 07:47:50 --> Model Class Initialized
DEBUG - 2013-09-21 07:47:50 --> Helper loaded: date_helper
DEBUG - 2013-09-21 07:48:15 --> Config Class Initialized
DEBUG - 2013-09-21 07:48:15 --> Hooks Class Initialized
DEBUG - 2013-09-21 07:48:15 --> Utf8 Class Initialized
DEBUG - 2013-09-21 07:48:15 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 07:48:15 --> URI Class Initialized
DEBUG - 2013-09-21 07:48:15 --> Router Class Initialized
DEBUG - 2013-09-21 07:48:15 --> Output Class Initialized
DEBUG - 2013-09-21 07:48:15 --> Security Class Initialized
DEBUG - 2013-09-21 07:48:15 --> Input Class Initialized
DEBUG - 2013-09-21 07:48:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 07:48:15 --> Language Class Initialized
DEBUG - 2013-09-21 07:48:15 --> Loader Class Initialized
DEBUG - 2013-09-21 07:48:15 --> Database Driver Class Initialized
DEBUG - 2013-09-21 07:48:15 --> Controller Class Initialized
DEBUG - 2013-09-21 07:48:15 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 07:48:15 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 07:48:15 --> Model Class Initialized
DEBUG - 2013-09-21 07:48:15 --> Helper loaded: date_helper
DEBUG - 2013-09-21 07:48:15 --> Model Class Initialized
DEBUG - 2013-09-21 07:48:15 --> Model Class Initialized
DEBUG - 2013-09-21 07:48:15 --> Config Class Initialized
DEBUG - 2013-09-21 07:48:15 --> Hooks Class Initialized
DEBUG - 2013-09-21 07:48:15 --> Utf8 Class Initialized
DEBUG - 2013-09-21 07:48:15 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 07:48:15 --> URI Class Initialized
DEBUG - 2013-09-21 07:48:15 --> Router Class Initialized
DEBUG - 2013-09-21 07:48:15 --> Output Class Initialized
DEBUG - 2013-09-21 07:48:15 --> Security Class Initialized
DEBUG - 2013-09-21 07:48:15 --> Input Class Initialized
DEBUG - 2013-09-21 07:48:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 07:48:15 --> Language Class Initialized
DEBUG - 2013-09-21 07:48:15 --> Loader Class Initialized
DEBUG - 2013-09-21 07:48:15 --> Database Driver Class Initialized
DEBUG - 2013-09-21 07:48:15 --> Controller Class Initialized
DEBUG - 2013-09-21 07:48:15 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 07:48:15 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 07:48:15 --> Model Class Initialized
DEBUG - 2013-09-21 07:48:15 --> Helper loaded: date_helper
DEBUG - 2013-09-21 07:48:15 --> Model Class Initialized
DEBUG - 2013-09-21 07:48:15 --> Model Class Initialized
DEBUG - 2013-09-21 07:48:38 --> Config Class Initialized
DEBUG - 2013-09-21 07:48:38 --> Hooks Class Initialized
DEBUG - 2013-09-21 07:48:38 --> Utf8 Class Initialized
DEBUG - 2013-09-21 07:48:38 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 07:48:38 --> URI Class Initialized
DEBUG - 2013-09-21 07:48:38 --> Router Class Initialized
ERROR - 2013-09-21 07:48:38 --> 404 Page Not Found --> login
DEBUG - 2013-09-21 07:48:44 --> Config Class Initialized
DEBUG - 2013-09-21 07:48:44 --> Hooks Class Initialized
DEBUG - 2013-09-21 07:48:44 --> Utf8 Class Initialized
DEBUG - 2013-09-21 07:48:44 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 07:48:44 --> URI Class Initialized
DEBUG - 2013-09-21 07:48:44 --> Router Class Initialized
DEBUG - 2013-09-21 07:48:44 --> Output Class Initialized
DEBUG - 2013-09-21 07:48:44 --> Security Class Initialized
DEBUG - 2013-09-21 07:48:44 --> Input Class Initialized
DEBUG - 2013-09-21 07:48:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 07:48:44 --> Language Class Initialized
DEBUG - 2013-09-21 07:48:44 --> Loader Class Initialized
DEBUG - 2013-09-21 07:48:44 --> Database Driver Class Initialized
DEBUG - 2013-09-21 07:48:44 --> Controller Class Initialized
DEBUG - 2013-09-21 07:48:44 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 07:48:44 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 07:48:44 --> Model Class Initialized
DEBUG - 2013-09-21 07:48:44 --> Helper loaded: date_helper
DEBUG - 2013-09-21 07:48:44 --> Model Class Initialized
DEBUG - 2013-09-21 07:48:44 --> Model Class Initialized
DEBUG - 2013-09-21 07:49:01 --> Config Class Initialized
DEBUG - 2013-09-21 07:49:01 --> Hooks Class Initialized
DEBUG - 2013-09-21 07:49:01 --> Utf8 Class Initialized
DEBUG - 2013-09-21 07:49:01 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 07:49:01 --> URI Class Initialized
DEBUG - 2013-09-21 07:49:01 --> Router Class Initialized
DEBUG - 2013-09-21 07:49:01 --> Output Class Initialized
DEBUG - 2013-09-21 07:49:01 --> Security Class Initialized
DEBUG - 2013-09-21 07:49:01 --> Input Class Initialized
DEBUG - 2013-09-21 07:49:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 07:49:01 --> Language Class Initialized
DEBUG - 2013-09-21 07:49:01 --> Loader Class Initialized
DEBUG - 2013-09-21 07:49:01 --> Database Driver Class Initialized
DEBUG - 2013-09-21 07:49:01 --> Controller Class Initialized
DEBUG - 2013-09-21 07:49:01 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 07:49:01 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 07:49:02 --> Model Class Initialized
DEBUG - 2013-09-21 07:49:02 --> Helper loaded: date_helper
DEBUG - 2013-09-21 07:49:02 --> Model Class Initialized
DEBUG - 2013-09-21 07:49:02 --> Model Class Initialized
DEBUG - 2013-09-21 07:49:02 --> XSS Filtering completed
DEBUG - 2013-09-21 07:49:02 --> XSS Filtering completed
ERROR - 2013-09-21 07:49:02 --> Severity: Notice  --> Undefined index: name C:\xampp2\htdocs\stratovate\application\models\users_model.php 53
ERROR - 2013-09-21 07:49:02 --> Severity: Notice  --> Use of undefined constant ROLE_VISITOR - assumed 'ROLE_VISITOR' C:\xampp2\htdocs\stratovate\application\models\users_model.php 53
DEBUG - 2013-09-21 07:49:40 --> Config Class Initialized
DEBUG - 2013-09-21 07:49:40 --> Hooks Class Initialized
DEBUG - 2013-09-21 07:49:40 --> Utf8 Class Initialized
DEBUG - 2013-09-21 07:49:40 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 07:49:40 --> URI Class Initialized
DEBUG - 2013-09-21 07:49:40 --> Router Class Initialized
DEBUG - 2013-09-21 07:49:40 --> Output Class Initialized
DEBUG - 2013-09-21 07:49:40 --> Security Class Initialized
DEBUG - 2013-09-21 07:49:40 --> Input Class Initialized
DEBUG - 2013-09-21 07:49:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 07:49:40 --> Language Class Initialized
DEBUG - 2013-09-21 07:49:40 --> Loader Class Initialized
DEBUG - 2013-09-21 07:49:40 --> Database Driver Class Initialized
DEBUG - 2013-09-21 07:49:40 --> Controller Class Initialized
DEBUG - 2013-09-21 07:49:40 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 07:49:40 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 07:49:40 --> Model Class Initialized
DEBUG - 2013-09-21 07:49:40 --> Helper loaded: date_helper
DEBUG - 2013-09-21 07:49:40 --> Model Class Initialized
DEBUG - 2013-09-21 07:49:40 --> Model Class Initialized
DEBUG - 2013-09-21 07:49:40 --> XSS Filtering completed
DEBUG - 2013-09-21 07:49:40 --> XSS Filtering completed
DEBUG - 2013-09-21 07:49:57 --> Config Class Initialized
DEBUG - 2013-09-21 07:49:57 --> Hooks Class Initialized
DEBUG - 2013-09-21 07:49:57 --> Utf8 Class Initialized
DEBUG - 2013-09-21 07:49:57 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 07:49:57 --> URI Class Initialized
DEBUG - 2013-09-21 07:49:57 --> Router Class Initialized
DEBUG - 2013-09-21 07:49:57 --> Output Class Initialized
DEBUG - 2013-09-21 07:49:57 --> Security Class Initialized
DEBUG - 2013-09-21 07:49:57 --> Input Class Initialized
DEBUG - 2013-09-21 07:49:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 07:49:57 --> Language Class Initialized
DEBUG - 2013-09-21 07:49:57 --> Loader Class Initialized
DEBUG - 2013-09-21 07:49:57 --> Database Driver Class Initialized
DEBUG - 2013-09-21 07:49:57 --> Controller Class Initialized
DEBUG - 2013-09-21 07:49:57 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 07:49:57 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 07:49:57 --> Model Class Initialized
DEBUG - 2013-09-21 07:49:57 --> Helper loaded: date_helper
DEBUG - 2013-09-21 07:49:57 --> Model Class Initialized
DEBUG - 2013-09-21 07:49:57 --> Model Class Initialized
DEBUG - 2013-09-21 07:49:57 --> XSS Filtering completed
DEBUG - 2013-09-21 07:49:57 --> XSS Filtering completed
DEBUG - 2013-09-21 07:49:58 --> Config Class Initialized
DEBUG - 2013-09-21 07:49:58 --> Hooks Class Initialized
DEBUG - 2013-09-21 07:49:58 --> Utf8 Class Initialized
DEBUG - 2013-09-21 07:49:58 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 07:49:58 --> URI Class Initialized
DEBUG - 2013-09-21 07:49:58 --> Router Class Initialized
DEBUG - 2013-09-21 07:49:58 --> Output Class Initialized
DEBUG - 2013-09-21 07:49:58 --> Security Class Initialized
DEBUG - 2013-09-21 07:49:58 --> Input Class Initialized
DEBUG - 2013-09-21 07:49:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 07:49:58 --> Language Class Initialized
DEBUG - 2013-09-21 07:49:58 --> Loader Class Initialized
DEBUG - 2013-09-21 07:49:58 --> Database Driver Class Initialized
DEBUG - 2013-09-21 07:49:58 --> Controller Class Initialized
DEBUG - 2013-09-21 07:49:58 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 07:49:58 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 07:49:58 --> Model Class Initialized
DEBUG - 2013-09-21 07:49:58 --> Helper loaded: date_helper
DEBUG - 2013-09-21 07:49:58 --> Model Class Initialized
DEBUG - 2013-09-21 07:49:58 --> Model Class Initialized
DEBUG - 2013-09-21 07:49:58 --> XSS Filtering completed
DEBUG - 2013-09-21 07:49:58 --> XSS Filtering completed
DEBUG - 2013-09-21 07:50:27 --> Config Class Initialized
DEBUG - 2013-09-21 07:50:27 --> Hooks Class Initialized
DEBUG - 2013-09-21 07:50:27 --> Utf8 Class Initialized
DEBUG - 2013-09-21 07:50:27 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 07:50:27 --> URI Class Initialized
DEBUG - 2013-09-21 07:50:27 --> Router Class Initialized
DEBUG - 2013-09-21 07:50:27 --> Output Class Initialized
DEBUG - 2013-09-21 07:50:27 --> Security Class Initialized
DEBUG - 2013-09-21 07:50:27 --> Input Class Initialized
DEBUG - 2013-09-21 07:50:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 07:50:27 --> Language Class Initialized
DEBUG - 2013-09-21 07:50:27 --> Loader Class Initialized
DEBUG - 2013-09-21 07:50:27 --> Database Driver Class Initialized
DEBUG - 2013-09-21 07:50:27 --> Controller Class Initialized
DEBUG - 2013-09-21 07:50:27 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 07:50:27 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 07:50:27 --> Model Class Initialized
DEBUG - 2013-09-21 07:50:27 --> Helper loaded: date_helper
DEBUG - 2013-09-21 07:50:27 --> Model Class Initialized
DEBUG - 2013-09-21 07:50:27 --> Model Class Initialized
DEBUG - 2013-09-21 07:50:27 --> XSS Filtering completed
DEBUG - 2013-09-21 07:50:27 --> XSS Filtering completed
DEBUG - 2013-09-21 07:50:28 --> DB Transaction Failure
ERROR - 2013-09-21 07:50:28 --> Query error: Unknown column 'username' in 'where clause'
DEBUG - 2013-09-21 07:50:28 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-09-21 07:50:53 --> Config Class Initialized
DEBUG - 2013-09-21 07:50:53 --> Hooks Class Initialized
DEBUG - 2013-09-21 07:50:53 --> Utf8 Class Initialized
DEBUG - 2013-09-21 07:50:53 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 07:50:53 --> URI Class Initialized
DEBUG - 2013-09-21 07:50:53 --> Router Class Initialized
DEBUG - 2013-09-21 07:50:53 --> Output Class Initialized
DEBUG - 2013-09-21 07:50:53 --> Security Class Initialized
DEBUG - 2013-09-21 07:50:53 --> Input Class Initialized
DEBUG - 2013-09-21 07:50:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 07:50:53 --> Language Class Initialized
DEBUG - 2013-09-21 07:50:53 --> Loader Class Initialized
DEBUG - 2013-09-21 07:50:53 --> Database Driver Class Initialized
DEBUG - 2013-09-21 07:50:53 --> Controller Class Initialized
DEBUG - 2013-09-21 07:50:53 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 07:50:53 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 07:50:53 --> Model Class Initialized
DEBUG - 2013-09-21 07:50:53 --> Helper loaded: date_helper
DEBUG - 2013-09-21 07:50:53 --> Model Class Initialized
DEBUG - 2013-09-21 07:50:53 --> Model Class Initialized
DEBUG - 2013-09-21 07:50:53 --> XSS Filtering completed
DEBUG - 2013-09-21 07:50:53 --> XSS Filtering completed
DEBUG - 2013-09-21 07:51:07 --> Config Class Initialized
DEBUG - 2013-09-21 07:51:07 --> Hooks Class Initialized
DEBUG - 2013-09-21 07:51:07 --> Utf8 Class Initialized
DEBUG - 2013-09-21 07:51:07 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 07:51:07 --> URI Class Initialized
DEBUG - 2013-09-21 07:51:07 --> Router Class Initialized
DEBUG - 2013-09-21 07:51:07 --> Output Class Initialized
DEBUG - 2013-09-21 07:51:07 --> Security Class Initialized
DEBUG - 2013-09-21 07:51:07 --> Input Class Initialized
DEBUG - 2013-09-21 07:51:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 07:51:07 --> Language Class Initialized
DEBUG - 2013-09-21 07:51:07 --> Loader Class Initialized
DEBUG - 2013-09-21 07:51:07 --> Database Driver Class Initialized
DEBUG - 2013-09-21 07:51:07 --> Controller Class Initialized
DEBUG - 2013-09-21 07:51:07 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 07:51:07 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 07:51:07 --> Model Class Initialized
DEBUG - 2013-09-21 07:51:07 --> Helper loaded: date_helper
DEBUG - 2013-09-21 07:51:07 --> Model Class Initialized
DEBUG - 2013-09-21 07:51:07 --> Model Class Initialized
DEBUG - 2013-09-21 07:51:07 --> XSS Filtering completed
DEBUG - 2013-09-21 07:51:07 --> XSS Filtering completed
DEBUG - 2013-09-21 07:51:19 --> Config Class Initialized
DEBUG - 2013-09-21 07:51:19 --> Hooks Class Initialized
DEBUG - 2013-09-21 07:51:19 --> Utf8 Class Initialized
DEBUG - 2013-09-21 07:51:19 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 07:51:19 --> URI Class Initialized
DEBUG - 2013-09-21 07:51:19 --> Router Class Initialized
DEBUG - 2013-09-21 07:51:19 --> Output Class Initialized
DEBUG - 2013-09-21 07:51:19 --> Security Class Initialized
DEBUG - 2013-09-21 07:51:19 --> Input Class Initialized
DEBUG - 2013-09-21 07:51:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 07:51:19 --> Language Class Initialized
DEBUG - 2013-09-21 07:51:19 --> Loader Class Initialized
DEBUG - 2013-09-21 07:51:19 --> Database Driver Class Initialized
DEBUG - 2013-09-21 07:51:19 --> Controller Class Initialized
DEBUG - 2013-09-21 07:51:19 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 07:51:19 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 07:51:19 --> Model Class Initialized
DEBUG - 2013-09-21 07:51:19 --> Helper loaded: date_helper
DEBUG - 2013-09-21 07:51:19 --> Model Class Initialized
DEBUG - 2013-09-21 07:51:19 --> Model Class Initialized
DEBUG - 2013-09-21 07:51:19 --> XSS Filtering completed
DEBUG - 2013-09-21 07:51:19 --> XSS Filtering completed
DEBUG - 2013-09-21 07:51:39 --> Config Class Initialized
DEBUG - 2013-09-21 07:51:39 --> Hooks Class Initialized
DEBUG - 2013-09-21 07:51:39 --> Utf8 Class Initialized
DEBUG - 2013-09-21 07:51:39 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 07:51:39 --> URI Class Initialized
DEBUG - 2013-09-21 07:51:39 --> Router Class Initialized
DEBUG - 2013-09-21 07:51:39 --> Output Class Initialized
DEBUG - 2013-09-21 07:51:39 --> Security Class Initialized
DEBUG - 2013-09-21 07:51:39 --> Input Class Initialized
DEBUG - 2013-09-21 07:51:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 07:51:39 --> Language Class Initialized
DEBUG - 2013-09-21 07:51:39 --> Loader Class Initialized
DEBUG - 2013-09-21 07:51:39 --> Database Driver Class Initialized
DEBUG - 2013-09-21 07:51:39 --> Controller Class Initialized
DEBUG - 2013-09-21 07:51:39 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 07:51:39 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 07:51:39 --> Model Class Initialized
DEBUG - 2013-09-21 07:51:39 --> Helper loaded: date_helper
DEBUG - 2013-09-21 07:51:39 --> Model Class Initialized
DEBUG - 2013-09-21 07:51:39 --> Model Class Initialized
DEBUG - 2013-09-21 07:51:39 --> XSS Filtering completed
DEBUG - 2013-09-21 07:51:39 --> XSS Filtering completed
DEBUG - 2013-09-21 07:51:45 --> Config Class Initialized
DEBUG - 2013-09-21 07:51:45 --> Hooks Class Initialized
DEBUG - 2013-09-21 07:51:45 --> Utf8 Class Initialized
DEBUG - 2013-09-21 07:51:45 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 07:51:45 --> URI Class Initialized
DEBUG - 2013-09-21 07:51:45 --> Router Class Initialized
DEBUG - 2013-09-21 07:51:45 --> Output Class Initialized
DEBUG - 2013-09-21 07:51:45 --> Security Class Initialized
DEBUG - 2013-09-21 07:51:45 --> Input Class Initialized
DEBUG - 2013-09-21 07:51:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 07:51:45 --> Language Class Initialized
DEBUG - 2013-09-21 07:51:45 --> Loader Class Initialized
DEBUG - 2013-09-21 07:51:45 --> Database Driver Class Initialized
DEBUG - 2013-09-21 07:51:45 --> Controller Class Initialized
DEBUG - 2013-09-21 07:51:45 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 07:51:45 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 07:51:45 --> Model Class Initialized
DEBUG - 2013-09-21 07:51:45 --> Helper loaded: date_helper
DEBUG - 2013-09-21 07:51:45 --> Model Class Initialized
DEBUG - 2013-09-21 07:51:45 --> Model Class Initialized
DEBUG - 2013-09-21 07:51:45 --> XSS Filtering completed
DEBUG - 2013-09-21 07:51:45 --> XSS Filtering completed
DEBUG - 2013-09-21 07:51:55 --> Config Class Initialized
DEBUG - 2013-09-21 07:51:55 --> Hooks Class Initialized
DEBUG - 2013-09-21 07:51:55 --> Utf8 Class Initialized
DEBUG - 2013-09-21 07:51:55 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 07:51:55 --> URI Class Initialized
DEBUG - 2013-09-21 07:51:55 --> Router Class Initialized
DEBUG - 2013-09-21 07:51:55 --> Output Class Initialized
DEBUG - 2013-09-21 07:51:55 --> Security Class Initialized
DEBUG - 2013-09-21 07:51:55 --> Input Class Initialized
DEBUG - 2013-09-21 07:51:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 07:51:55 --> Language Class Initialized
DEBUG - 2013-09-21 07:51:55 --> Loader Class Initialized
DEBUG - 2013-09-21 07:51:55 --> Database Driver Class Initialized
DEBUG - 2013-09-21 07:51:55 --> Controller Class Initialized
DEBUG - 2013-09-21 07:51:55 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 07:51:55 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 07:51:55 --> Model Class Initialized
DEBUG - 2013-09-21 07:51:55 --> Helper loaded: date_helper
DEBUG - 2013-09-21 07:51:55 --> Model Class Initialized
DEBUG - 2013-09-21 07:51:55 --> Model Class Initialized
DEBUG - 2013-09-21 07:51:55 --> Model Class Initialized
ERROR - 2013-09-21 07:51:55 --> Severity: Notice  --> Undefined variable: d C:\xampp2\htdocs\stratovate\application\models\clients_model.php 33
ERROR - 2013-09-21 07:51:55 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp2\htdocs\stratovate\application\models\clients_model.php 33
DEBUG - 2013-09-21 07:52:17 --> Config Class Initialized
DEBUG - 2013-09-21 07:52:17 --> Hooks Class Initialized
DEBUG - 2013-09-21 07:52:17 --> Utf8 Class Initialized
DEBUG - 2013-09-21 07:52:17 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 07:52:17 --> URI Class Initialized
DEBUG - 2013-09-21 07:52:17 --> Router Class Initialized
DEBUG - 2013-09-21 07:52:17 --> Output Class Initialized
DEBUG - 2013-09-21 07:52:17 --> Security Class Initialized
DEBUG - 2013-09-21 07:52:17 --> Input Class Initialized
DEBUG - 2013-09-21 07:52:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 07:52:17 --> Language Class Initialized
DEBUG - 2013-09-21 07:52:17 --> Loader Class Initialized
DEBUG - 2013-09-21 07:52:17 --> Database Driver Class Initialized
DEBUG - 2013-09-21 07:52:17 --> Controller Class Initialized
DEBUG - 2013-09-21 07:52:17 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 07:52:17 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 07:52:17 --> Model Class Initialized
DEBUG - 2013-09-21 07:52:17 --> Helper loaded: date_helper
DEBUG - 2013-09-21 07:52:17 --> Model Class Initialized
DEBUG - 2013-09-21 07:52:17 --> Model Class Initialized
DEBUG - 2013-09-21 07:52:17 --> Model Class Initialized
DEBUG - 2013-09-21 07:52:17 --> Config Class Initialized
DEBUG - 2013-09-21 07:52:17 --> Hooks Class Initialized
DEBUG - 2013-09-21 07:52:17 --> Utf8 Class Initialized
DEBUG - 2013-09-21 07:52:17 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 07:52:17 --> URI Class Initialized
DEBUG - 2013-09-21 07:52:17 --> Router Class Initialized
DEBUG - 2013-09-21 07:52:17 --> Output Class Initialized
DEBUG - 2013-09-21 07:52:17 --> Security Class Initialized
DEBUG - 2013-09-21 07:52:17 --> Input Class Initialized
DEBUG - 2013-09-21 07:52:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 07:52:17 --> Language Class Initialized
DEBUG - 2013-09-21 07:52:17 --> Loader Class Initialized
DEBUG - 2013-09-21 07:52:17 --> Database Driver Class Initialized
DEBUG - 2013-09-21 07:52:17 --> Controller Class Initialized
DEBUG - 2013-09-21 07:52:17 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 07:52:17 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 07:52:17 --> Model Class Initialized
DEBUG - 2013-09-21 07:52:17 --> Helper loaded: date_helper
DEBUG - 2013-09-21 07:52:17 --> Model Class Initialized
DEBUG - 2013-09-21 07:52:17 --> Model Class Initialized
DEBUG - 2013-09-21 07:52:17 --> Model Class Initialized
DEBUG - 2013-09-21 07:54:48 --> Config Class Initialized
DEBUG - 2013-09-21 07:54:48 --> Hooks Class Initialized
DEBUG - 2013-09-21 07:54:48 --> Utf8 Class Initialized
DEBUG - 2013-09-21 07:54:48 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 07:54:48 --> URI Class Initialized
DEBUG - 2013-09-21 07:54:48 --> Router Class Initialized
DEBUG - 2013-09-21 07:54:48 --> Output Class Initialized
DEBUG - 2013-09-21 07:54:48 --> Security Class Initialized
DEBUG - 2013-09-21 07:54:48 --> Input Class Initialized
DEBUG - 2013-09-21 07:54:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 07:54:48 --> Language Class Initialized
DEBUG - 2013-09-21 07:54:48 --> Loader Class Initialized
DEBUG - 2013-09-21 07:54:48 --> Database Driver Class Initialized
DEBUG - 2013-09-21 07:54:48 --> Controller Class Initialized
DEBUG - 2013-09-21 07:54:48 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 07:54:48 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 07:54:48 --> Model Class Initialized
DEBUG - 2013-09-21 07:54:48 --> Helper loaded: date_helper
DEBUG - 2013-09-21 07:54:48 --> Model Class Initialized
DEBUG - 2013-09-21 07:54:48 --> Model Class Initialized
DEBUG - 2013-09-21 07:54:59 --> Config Class Initialized
DEBUG - 2013-09-21 07:54:59 --> Hooks Class Initialized
DEBUG - 2013-09-21 07:54:59 --> Utf8 Class Initialized
DEBUG - 2013-09-21 07:54:59 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 07:54:59 --> URI Class Initialized
DEBUG - 2013-09-21 07:54:59 --> Router Class Initialized
DEBUG - 2013-09-21 07:54:59 --> Output Class Initialized
DEBUG - 2013-09-21 07:54:59 --> Security Class Initialized
DEBUG - 2013-09-21 07:54:59 --> Input Class Initialized
DEBUG - 2013-09-21 07:54:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 07:54:59 --> Language Class Initialized
DEBUG - 2013-09-21 07:54:59 --> Loader Class Initialized
DEBUG - 2013-09-21 07:54:59 --> Database Driver Class Initialized
DEBUG - 2013-09-21 07:54:59 --> Controller Class Initialized
DEBUG - 2013-09-21 07:54:59 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 07:54:59 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 07:54:59 --> Model Class Initialized
DEBUG - 2013-09-21 07:54:59 --> Helper loaded: date_helper
DEBUG - 2013-09-21 07:54:59 --> Model Class Initialized
DEBUG - 2013-09-21 07:54:59 --> Model Class Initialized
DEBUG - 2013-09-21 07:55:18 --> Config Class Initialized
DEBUG - 2013-09-21 07:55:18 --> Hooks Class Initialized
DEBUG - 2013-09-21 07:55:18 --> Utf8 Class Initialized
DEBUG - 2013-09-21 07:55:18 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 07:55:18 --> URI Class Initialized
DEBUG - 2013-09-21 07:55:18 --> Router Class Initialized
DEBUG - 2013-09-21 07:55:18 --> Output Class Initialized
DEBUG - 2013-09-21 07:55:18 --> Security Class Initialized
DEBUG - 2013-09-21 07:55:18 --> Input Class Initialized
DEBUG - 2013-09-21 07:55:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 07:55:18 --> Language Class Initialized
DEBUG - 2013-09-21 07:55:18 --> Loader Class Initialized
DEBUG - 2013-09-21 07:55:18 --> Database Driver Class Initialized
DEBUG - 2013-09-21 07:55:18 --> Controller Class Initialized
DEBUG - 2013-09-21 07:55:18 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 07:55:18 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 07:55:18 --> Model Class Initialized
DEBUG - 2013-09-21 07:55:18 --> Helper loaded: date_helper
DEBUG - 2013-09-21 07:55:18 --> Model Class Initialized
DEBUG - 2013-09-21 07:55:18 --> Model Class Initialized
DEBUG - 2013-09-21 07:55:18 --> XSS Filtering completed
DEBUG - 2013-09-21 07:55:18 --> XSS Filtering completed
DEBUG - 2013-09-21 07:55:18 --> XSS Filtering completed
DEBUG - 2013-09-21 07:55:31 --> Config Class Initialized
DEBUG - 2013-09-21 07:55:31 --> Hooks Class Initialized
DEBUG - 2013-09-21 07:55:31 --> Utf8 Class Initialized
DEBUG - 2013-09-21 07:55:31 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 07:55:31 --> URI Class Initialized
DEBUG - 2013-09-21 07:55:31 --> Router Class Initialized
DEBUG - 2013-09-21 07:55:31 --> Output Class Initialized
DEBUG - 2013-09-21 07:55:31 --> Security Class Initialized
DEBUG - 2013-09-21 07:55:31 --> Input Class Initialized
DEBUG - 2013-09-21 07:55:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 07:55:31 --> Language Class Initialized
DEBUG - 2013-09-21 07:55:31 --> Loader Class Initialized
DEBUG - 2013-09-21 07:55:31 --> Database Driver Class Initialized
DEBUG - 2013-09-21 07:55:31 --> Controller Class Initialized
DEBUG - 2013-09-21 07:55:31 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 07:55:31 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 07:55:31 --> Model Class Initialized
DEBUG - 2013-09-21 07:55:31 --> Helper loaded: date_helper
DEBUG - 2013-09-21 07:55:31 --> Model Class Initialized
DEBUG - 2013-09-21 07:55:31 --> Model Class Initialized
DEBUG - 2013-09-21 07:55:31 --> XSS Filtering completed
DEBUG - 2013-09-21 07:55:31 --> XSS Filtering completed
DEBUG - 2013-09-21 07:55:31 --> XSS Filtering completed
DEBUG - 2013-09-21 07:56:01 --> Config Class Initialized
DEBUG - 2013-09-21 07:56:01 --> Hooks Class Initialized
DEBUG - 2013-09-21 07:56:01 --> Utf8 Class Initialized
DEBUG - 2013-09-21 07:56:01 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 07:56:01 --> URI Class Initialized
DEBUG - 2013-09-21 07:56:01 --> Router Class Initialized
DEBUG - 2013-09-21 07:56:01 --> Output Class Initialized
DEBUG - 2013-09-21 07:56:01 --> Security Class Initialized
DEBUG - 2013-09-21 07:56:01 --> Input Class Initialized
DEBUG - 2013-09-21 07:56:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 07:56:01 --> Language Class Initialized
DEBUG - 2013-09-21 07:56:01 --> Loader Class Initialized
DEBUG - 2013-09-21 07:56:01 --> Database Driver Class Initialized
DEBUG - 2013-09-21 07:56:01 --> Controller Class Initialized
DEBUG - 2013-09-21 07:56:01 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 07:56:01 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 07:56:01 --> Model Class Initialized
DEBUG - 2013-09-21 07:56:01 --> Helper loaded: date_helper
DEBUG - 2013-09-21 07:56:01 --> Model Class Initialized
DEBUG - 2013-09-21 07:56:01 --> Model Class Initialized
DEBUG - 2013-09-21 07:56:01 --> XSS Filtering completed
DEBUG - 2013-09-21 07:56:01 --> XSS Filtering completed
DEBUG - 2013-09-21 07:56:01 --> XSS Filtering completed
DEBUG - 2013-09-21 08:06:52 --> Config Class Initialized
DEBUG - 2013-09-21 08:06:52 --> Hooks Class Initialized
DEBUG - 2013-09-21 08:06:52 --> Utf8 Class Initialized
DEBUG - 2013-09-21 08:06:52 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 08:06:52 --> URI Class Initialized
DEBUG - 2013-09-21 08:06:52 --> Router Class Initialized
DEBUG - 2013-09-21 08:06:52 --> Output Class Initialized
DEBUG - 2013-09-21 08:06:52 --> Security Class Initialized
DEBUG - 2013-09-21 08:06:52 --> Input Class Initialized
DEBUG - 2013-09-21 08:06:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 08:06:52 --> Language Class Initialized
DEBUG - 2013-09-21 08:06:52 --> Loader Class Initialized
DEBUG - 2013-09-21 08:06:52 --> Database Driver Class Initialized
DEBUG - 2013-09-21 08:06:52 --> Controller Class Initialized
DEBUG - 2013-09-21 08:06:52 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 08:06:52 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 08:08:10 --> Config Class Initialized
DEBUG - 2013-09-21 08:08:10 --> Hooks Class Initialized
DEBUG - 2013-09-21 08:08:10 --> Utf8 Class Initialized
DEBUG - 2013-09-21 08:08:10 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 08:08:10 --> URI Class Initialized
DEBUG - 2013-09-21 08:08:10 --> Router Class Initialized
DEBUG - 2013-09-21 08:08:10 --> Output Class Initialized
DEBUG - 2013-09-21 08:08:10 --> Security Class Initialized
DEBUG - 2013-09-21 08:08:10 --> Input Class Initialized
DEBUG - 2013-09-21 08:08:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 08:08:10 --> Language Class Initialized
DEBUG - 2013-09-21 08:08:10 --> Loader Class Initialized
DEBUG - 2013-09-21 08:08:10 --> Database Driver Class Initialized
DEBUG - 2013-09-21 08:08:10 --> Controller Class Initialized
DEBUG - 2013-09-21 08:08:10 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 08:08:10 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 08:08:10 --> Model Class Initialized
DEBUG - 2013-09-21 08:08:10 --> Helper loaded: date_helper
DEBUG - 2013-09-21 08:08:10 --> Model Class Initialized
DEBUG - 2013-09-21 08:08:10 --> Model Class Initialized
DEBUG - 2013-09-21 08:08:29 --> Config Class Initialized
DEBUG - 2013-09-21 08:08:29 --> Hooks Class Initialized
DEBUG - 2013-09-21 08:08:29 --> Utf8 Class Initialized
DEBUG - 2013-09-21 08:08:29 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 08:08:29 --> URI Class Initialized
DEBUG - 2013-09-21 08:08:29 --> Router Class Initialized
DEBUG - 2013-09-21 08:08:29 --> Output Class Initialized
DEBUG - 2013-09-21 08:08:29 --> Security Class Initialized
DEBUG - 2013-09-21 08:08:29 --> Input Class Initialized
DEBUG - 2013-09-21 08:08:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 08:08:29 --> Language Class Initialized
DEBUG - 2013-09-21 08:08:29 --> Loader Class Initialized
DEBUG - 2013-09-21 08:08:29 --> Database Driver Class Initialized
DEBUG - 2013-09-21 08:08:29 --> Controller Class Initialized
DEBUG - 2013-09-21 08:08:29 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 08:08:29 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 08:08:29 --> Model Class Initialized
DEBUG - 2013-09-21 08:08:29 --> Helper loaded: date_helper
DEBUG - 2013-09-21 08:08:29 --> Model Class Initialized
DEBUG - 2013-09-21 08:08:29 --> Model Class Initialized
DEBUG - 2013-09-21 08:08:29 --> Model Class Initialized
DEBUG - 2013-09-21 08:08:29 --> XSS Filtering completed
DEBUG - 2013-09-21 08:08:29 --> XSS Filtering completed
DEBUG - 2013-09-21 08:09:18 --> Config Class Initialized
DEBUG - 2013-09-21 08:09:18 --> Hooks Class Initialized
DEBUG - 2013-09-21 08:09:18 --> Utf8 Class Initialized
DEBUG - 2013-09-21 08:09:18 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 08:09:18 --> URI Class Initialized
DEBUG - 2013-09-21 08:09:18 --> Router Class Initialized
DEBUG - 2013-09-21 08:09:18 --> Output Class Initialized
DEBUG - 2013-09-21 08:09:18 --> Security Class Initialized
DEBUG - 2013-09-21 08:09:18 --> Input Class Initialized
DEBUG - 2013-09-21 08:09:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 08:09:18 --> Language Class Initialized
DEBUG - 2013-09-21 08:09:18 --> Loader Class Initialized
DEBUG - 2013-09-21 08:09:18 --> Database Driver Class Initialized
DEBUG - 2013-09-21 08:09:18 --> Controller Class Initialized
DEBUG - 2013-09-21 08:09:18 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 08:09:18 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 08:09:18 --> Model Class Initialized
DEBUG - 2013-09-21 08:09:18 --> Helper loaded: date_helper
DEBUG - 2013-09-21 08:09:18 --> Model Class Initialized
DEBUG - 2013-09-21 08:09:18 --> Model Class Initialized
DEBUG - 2013-09-21 08:09:18 --> Model Class Initialized
DEBUG - 2013-09-21 08:09:18 --> XSS Filtering completed
DEBUG - 2013-09-21 08:09:18 --> XSS Filtering completed
DEBUG - 2013-09-21 08:16:24 --> Config Class Initialized
DEBUG - 2013-09-21 08:16:24 --> Hooks Class Initialized
DEBUG - 2013-09-21 08:16:24 --> Utf8 Class Initialized
DEBUG - 2013-09-21 08:16:24 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 08:16:24 --> URI Class Initialized
DEBUG - 2013-09-21 08:16:24 --> Router Class Initialized
DEBUG - 2013-09-21 08:16:24 --> Output Class Initialized
DEBUG - 2013-09-21 08:16:24 --> Security Class Initialized
DEBUG - 2013-09-21 08:16:24 --> Input Class Initialized
DEBUG - 2013-09-21 08:16:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 08:16:24 --> Language Class Initialized
DEBUG - 2013-09-21 08:16:24 --> Loader Class Initialized
DEBUG - 2013-09-21 08:16:24 --> Database Driver Class Initialized
DEBUG - 2013-09-21 08:16:24 --> Controller Class Initialized
DEBUG - 2013-09-21 08:16:24 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 08:16:24 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 08:16:24 --> Model Class Initialized
DEBUG - 2013-09-21 08:16:24 --> Helper loaded: date_helper
DEBUG - 2013-09-21 08:16:24 --> Model Class Initialized
DEBUG - 2013-09-21 08:16:24 --> Model Class Initialized
DEBUG - 2013-09-21 08:16:24 --> Config Class Initialized
DEBUG - 2013-09-21 08:16:24 --> Hooks Class Initialized
DEBUG - 2013-09-21 08:16:24 --> Utf8 Class Initialized
DEBUG - 2013-09-21 08:16:24 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 08:16:24 --> URI Class Initialized
DEBUG - 2013-09-21 08:16:24 --> Router Class Initialized
DEBUG - 2013-09-21 08:16:24 --> Output Class Initialized
DEBUG - 2013-09-21 08:16:24 --> Security Class Initialized
DEBUG - 2013-09-21 08:16:24 --> Input Class Initialized
DEBUG - 2013-09-21 08:16:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 08:16:24 --> Language Class Initialized
DEBUG - 2013-09-21 08:16:24 --> Loader Class Initialized
DEBUG - 2013-09-21 08:16:24 --> Database Driver Class Initialized
DEBUG - 2013-09-21 08:16:24 --> Controller Class Initialized
DEBUG - 2013-09-21 08:16:24 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 08:16:24 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 08:16:24 --> Model Class Initialized
DEBUG - 2013-09-21 08:16:24 --> Helper loaded: date_helper
DEBUG - 2013-09-21 08:16:24 --> Model Class Initialized
DEBUG - 2013-09-21 08:16:24 --> Model Class Initialized
DEBUG - 2013-09-21 08:16:39 --> Config Class Initialized
DEBUG - 2013-09-21 08:16:39 --> Hooks Class Initialized
DEBUG - 2013-09-21 08:16:39 --> Utf8 Class Initialized
DEBUG - 2013-09-21 08:16:39 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 08:16:39 --> URI Class Initialized
DEBUG - 2013-09-21 08:16:39 --> Router Class Initialized
DEBUG - 2013-09-21 08:16:39 --> Output Class Initialized
DEBUG - 2013-09-21 08:16:39 --> Security Class Initialized
DEBUG - 2013-09-21 08:16:39 --> Input Class Initialized
DEBUG - 2013-09-21 08:16:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 08:16:39 --> Language Class Initialized
DEBUG - 2013-09-21 08:16:39 --> Loader Class Initialized
DEBUG - 2013-09-21 08:16:39 --> Database Driver Class Initialized
DEBUG - 2013-09-21 08:16:39 --> Controller Class Initialized
DEBUG - 2013-09-21 08:16:39 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 08:16:39 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 08:16:39 --> Model Class Initialized
DEBUG - 2013-09-21 08:16:39 --> Helper loaded: date_helper
DEBUG - 2013-09-21 08:16:39 --> Model Class Initialized
DEBUG - 2013-09-21 08:16:39 --> Model Class Initialized
DEBUG - 2013-09-21 08:16:39 --> Model Class Initialized
ERROR - 2013-09-21 08:16:39 --> Severity: Notice  --> Undefined property: Features::$clients_model C:\xampp2\htdocs\stratovate\application\controllers\features.php 23
DEBUG - 2013-09-21 08:16:46 --> Config Class Initialized
DEBUG - 2013-09-21 08:16:46 --> Hooks Class Initialized
DEBUG - 2013-09-21 08:16:46 --> Utf8 Class Initialized
DEBUG - 2013-09-21 08:16:46 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 08:16:46 --> URI Class Initialized
DEBUG - 2013-09-21 08:16:46 --> Router Class Initialized
DEBUG - 2013-09-21 08:16:46 --> Output Class Initialized
DEBUG - 2013-09-21 08:16:46 --> Security Class Initialized
DEBUG - 2013-09-21 08:16:46 --> Input Class Initialized
DEBUG - 2013-09-21 08:16:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 08:16:46 --> Language Class Initialized
DEBUG - 2013-09-21 08:16:46 --> Loader Class Initialized
DEBUG - 2013-09-21 08:16:46 --> Database Driver Class Initialized
DEBUG - 2013-09-21 08:16:46 --> Controller Class Initialized
DEBUG - 2013-09-21 08:16:46 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 08:16:46 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 08:16:46 --> Model Class Initialized
DEBUG - 2013-09-21 08:16:46 --> Helper loaded: date_helper
DEBUG - 2013-09-21 08:16:46 --> Model Class Initialized
DEBUG - 2013-09-21 08:16:46 --> Model Class Initialized
DEBUG - 2013-09-21 08:16:46 --> Model Class Initialized
DEBUG - 2013-09-21 08:16:46 --> DB Transaction Failure
ERROR - 2013-09-21 08:16:46 --> Query error: Unknown column 'name' in 'field list'
DEBUG - 2013-09-21 08:16:46 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-09-21 08:17:12 --> Config Class Initialized
DEBUG - 2013-09-21 08:17:12 --> Hooks Class Initialized
DEBUG - 2013-09-21 08:17:12 --> Utf8 Class Initialized
DEBUG - 2013-09-21 08:17:12 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 08:17:12 --> URI Class Initialized
DEBUG - 2013-09-21 08:17:12 --> Router Class Initialized
DEBUG - 2013-09-21 08:17:12 --> Output Class Initialized
DEBUG - 2013-09-21 08:17:12 --> Security Class Initialized
DEBUG - 2013-09-21 08:17:12 --> Input Class Initialized
DEBUG - 2013-09-21 08:17:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 08:17:12 --> Language Class Initialized
DEBUG - 2013-09-21 08:17:12 --> Loader Class Initialized
DEBUG - 2013-09-21 08:17:12 --> Database Driver Class Initialized
DEBUG - 2013-09-21 08:17:12 --> Controller Class Initialized
DEBUG - 2013-09-21 08:17:12 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 08:17:12 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 08:17:12 --> Model Class Initialized
DEBUG - 2013-09-21 08:17:12 --> Helper loaded: date_helper
DEBUG - 2013-09-21 08:17:12 --> Model Class Initialized
ERROR - 2013-09-21 08:17:12 --> Severity: Notice  --> Use of undefined constant TABLE_FEATURES - assumed 'TABLE_FEATURES' C:\xampp2\htdocs\stratovate\application\models\features_model.php 10
DEBUG - 2013-09-21 08:17:12 --> Model Class Initialized
DEBUG - 2013-09-21 08:17:12 --> Model Class Initialized
DEBUG - 2013-09-21 08:17:12 --> DB Transaction Failure
ERROR - 2013-09-21 08:17:12 --> Query error: Table 'youphoric.table_features' doesn't exist
DEBUG - 2013-09-21 08:17:12 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-09-21 08:17:40 --> Config Class Initialized
DEBUG - 2013-09-21 08:17:40 --> Hooks Class Initialized
DEBUG - 2013-09-21 08:17:40 --> Utf8 Class Initialized
DEBUG - 2013-09-21 08:17:40 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 08:17:40 --> URI Class Initialized
DEBUG - 2013-09-21 08:17:40 --> Router Class Initialized
DEBUG - 2013-09-21 08:17:40 --> Output Class Initialized
DEBUG - 2013-09-21 08:17:40 --> Security Class Initialized
DEBUG - 2013-09-21 08:17:40 --> Input Class Initialized
DEBUG - 2013-09-21 08:17:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 08:17:40 --> Language Class Initialized
DEBUG - 2013-09-21 08:17:40 --> Loader Class Initialized
DEBUG - 2013-09-21 08:17:40 --> Database Driver Class Initialized
DEBUG - 2013-09-21 08:17:40 --> Controller Class Initialized
DEBUG - 2013-09-21 08:17:40 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 08:17:40 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 08:17:40 --> Model Class Initialized
DEBUG - 2013-09-21 08:17:40 --> Helper loaded: date_helper
DEBUG - 2013-09-21 08:17:40 --> Model Class Initialized
DEBUG - 2013-09-21 08:17:40 --> Model Class Initialized
DEBUG - 2013-09-21 08:17:40 --> Model Class Initialized
DEBUG - 2013-09-21 08:17:40 --> Config Class Initialized
DEBUG - 2013-09-21 08:17:40 --> Hooks Class Initialized
DEBUG - 2013-09-21 08:17:40 --> Utf8 Class Initialized
DEBUG - 2013-09-21 08:17:40 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 08:17:40 --> URI Class Initialized
DEBUG - 2013-09-21 08:17:40 --> Router Class Initialized
DEBUG - 2013-09-21 08:17:40 --> Output Class Initialized
DEBUG - 2013-09-21 08:17:40 --> Security Class Initialized
DEBUG - 2013-09-21 08:17:40 --> Input Class Initialized
DEBUG - 2013-09-21 08:17:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 08:17:40 --> Language Class Initialized
DEBUG - 2013-09-21 08:17:40 --> Loader Class Initialized
DEBUG - 2013-09-21 08:17:40 --> Database Driver Class Initialized
DEBUG - 2013-09-21 08:17:40 --> Controller Class Initialized
DEBUG - 2013-09-21 08:17:40 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 08:17:40 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 08:17:40 --> Model Class Initialized
DEBUG - 2013-09-21 08:17:40 --> Helper loaded: date_helper
DEBUG - 2013-09-21 08:17:40 --> Model Class Initialized
DEBUG - 2013-09-21 08:17:40 --> Model Class Initialized
DEBUG - 2013-09-21 08:17:40 --> Model Class Initialized
DEBUG - 2013-09-21 08:20:31 --> Config Class Initialized
DEBUG - 2013-09-21 08:20:31 --> Hooks Class Initialized
DEBUG - 2013-09-21 08:20:31 --> Utf8 Class Initialized
DEBUG - 2013-09-21 08:20:31 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 08:20:31 --> URI Class Initialized
DEBUG - 2013-09-21 08:20:31 --> Router Class Initialized
DEBUG - 2013-09-21 08:20:31 --> Output Class Initialized
DEBUG - 2013-09-21 08:20:31 --> Security Class Initialized
DEBUG - 2013-09-21 08:20:31 --> Input Class Initialized
DEBUG - 2013-09-21 08:20:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 08:20:31 --> Language Class Initialized
DEBUG - 2013-09-21 08:20:31 --> Loader Class Initialized
DEBUG - 2013-09-21 08:20:31 --> Database Driver Class Initialized
DEBUG - 2013-09-21 08:20:31 --> Controller Class Initialized
DEBUG - 2013-09-21 08:20:31 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 08:20:31 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 08:20:31 --> Model Class Initialized
DEBUG - 2013-09-21 08:20:31 --> Helper loaded: date_helper
DEBUG - 2013-09-21 08:20:31 --> Model Class Initialized
DEBUG - 2013-09-21 08:20:31 --> Model Class Initialized
DEBUG - 2013-09-21 08:20:31 --> Model Class Initialized
DEBUG - 2013-09-21 08:20:31 --> Config Class Initialized
DEBUG - 2013-09-21 08:20:31 --> Hooks Class Initialized
DEBUG - 2013-09-21 08:20:31 --> Utf8 Class Initialized
DEBUG - 2013-09-21 08:20:31 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 08:20:31 --> URI Class Initialized
DEBUG - 2013-09-21 08:20:31 --> Router Class Initialized
DEBUG - 2013-09-21 08:20:31 --> Output Class Initialized
DEBUG - 2013-09-21 08:20:31 --> Security Class Initialized
DEBUG - 2013-09-21 08:20:31 --> Input Class Initialized
DEBUG - 2013-09-21 08:20:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 08:20:31 --> Language Class Initialized
DEBUG - 2013-09-21 08:20:31 --> Loader Class Initialized
DEBUG - 2013-09-21 08:20:31 --> Database Driver Class Initialized
DEBUG - 2013-09-21 08:20:31 --> Controller Class Initialized
DEBUG - 2013-09-21 08:20:31 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 08:20:31 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 08:20:31 --> Model Class Initialized
DEBUG - 2013-09-21 08:20:31 --> Helper loaded: date_helper
DEBUG - 2013-09-21 08:20:31 --> Model Class Initialized
DEBUG - 2013-09-21 08:20:31 --> Model Class Initialized
DEBUG - 2013-09-21 08:20:31 --> Model Class Initialized
DEBUG - 2013-09-21 08:20:43 --> Config Class Initialized
DEBUG - 2013-09-21 08:20:43 --> Hooks Class Initialized
DEBUG - 2013-09-21 08:20:43 --> Utf8 Class Initialized
DEBUG - 2013-09-21 08:20:43 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 08:20:43 --> URI Class Initialized
DEBUG - 2013-09-21 08:20:43 --> Router Class Initialized
ERROR - 2013-09-21 08:20:43 --> 404 Page Not Found --> establishments
DEBUG - 2013-09-21 08:20:48 --> Config Class Initialized
DEBUG - 2013-09-21 08:20:48 --> Hooks Class Initialized
DEBUG - 2013-09-21 08:20:48 --> Utf8 Class Initialized
DEBUG - 2013-09-21 08:20:48 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 08:20:48 --> URI Class Initialized
DEBUG - 2013-09-21 08:20:48 --> Router Class Initialized
DEBUG - 2013-09-21 08:20:48 --> Output Class Initialized
DEBUG - 2013-09-21 08:20:48 --> Security Class Initialized
DEBUG - 2013-09-21 08:20:48 --> Input Class Initialized
DEBUG - 2013-09-21 08:20:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 08:20:48 --> Language Class Initialized
DEBUG - 2013-09-21 08:20:48 --> Loader Class Initialized
DEBUG - 2013-09-21 08:20:48 --> Database Driver Class Initialized
DEBUG - 2013-09-21 08:20:48 --> Controller Class Initialized
DEBUG - 2013-09-21 08:20:48 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 08:20:48 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 08:20:48 --> Model Class Initialized
DEBUG - 2013-09-21 08:20:48 --> Helper loaded: date_helper
DEBUG - 2013-09-21 08:20:48 --> Model Class Initialized
DEBUG - 2013-09-21 08:20:48 --> Model Class Initialized
DEBUG - 2013-09-21 08:20:49 --> Config Class Initialized
DEBUG - 2013-09-21 08:20:49 --> Hooks Class Initialized
DEBUG - 2013-09-21 08:20:49 --> Utf8 Class Initialized
DEBUG - 2013-09-21 08:20:49 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 08:20:49 --> URI Class Initialized
DEBUG - 2013-09-21 08:20:49 --> Router Class Initialized
DEBUG - 2013-09-21 08:20:49 --> Output Class Initialized
DEBUG - 2013-09-21 08:20:49 --> Security Class Initialized
DEBUG - 2013-09-21 08:20:49 --> Input Class Initialized
DEBUG - 2013-09-21 08:20:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 08:20:49 --> Language Class Initialized
DEBUG - 2013-09-21 08:20:49 --> Loader Class Initialized
DEBUG - 2013-09-21 08:20:49 --> Database Driver Class Initialized
DEBUG - 2013-09-21 08:20:49 --> Controller Class Initialized
DEBUG - 2013-09-21 08:20:49 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 08:20:49 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 08:20:49 --> Model Class Initialized
DEBUG - 2013-09-21 08:20:49 --> Helper loaded: date_helper
DEBUG - 2013-09-21 08:20:49 --> Model Class Initialized
DEBUG - 2013-09-21 08:20:49 --> Model Class Initialized
DEBUG - 2013-09-21 08:23:33 --> Config Class Initialized
DEBUG - 2013-09-21 08:23:33 --> Hooks Class Initialized
DEBUG - 2013-09-21 08:23:33 --> Utf8 Class Initialized
DEBUG - 2013-09-21 08:23:33 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 08:23:33 --> URI Class Initialized
DEBUG - 2013-09-21 08:23:33 --> Router Class Initialized
DEBUG - 2013-09-21 08:23:33 --> Output Class Initialized
DEBUG - 2013-09-21 08:23:33 --> Security Class Initialized
DEBUG - 2013-09-21 08:23:33 --> Input Class Initialized
DEBUG - 2013-09-21 08:23:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 08:23:33 --> Language Class Initialized
DEBUG - 2013-09-21 08:23:33 --> Loader Class Initialized
DEBUG - 2013-09-21 08:23:33 --> Database Driver Class Initialized
DEBUG - 2013-09-21 08:23:33 --> Controller Class Initialized
DEBUG - 2013-09-21 08:23:33 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 08:23:33 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 08:23:33 --> Model Class Initialized
DEBUG - 2013-09-21 08:23:33 --> Helper loaded: date_helper
DEBUG - 2013-09-21 08:23:33 --> Model Class Initialized
DEBUG - 2013-09-21 08:23:33 --> Model Class Initialized
DEBUG - 2013-09-21 08:23:33 --> Config Class Initialized
DEBUG - 2013-09-21 08:23:33 --> Hooks Class Initialized
DEBUG - 2013-09-21 08:23:33 --> Utf8 Class Initialized
DEBUG - 2013-09-21 08:23:33 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 08:23:33 --> URI Class Initialized
DEBUG - 2013-09-21 08:23:33 --> Router Class Initialized
DEBUG - 2013-09-21 08:23:33 --> Output Class Initialized
DEBUG - 2013-09-21 08:23:33 --> Security Class Initialized
DEBUG - 2013-09-21 08:23:33 --> Input Class Initialized
DEBUG - 2013-09-21 08:23:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 08:23:33 --> Language Class Initialized
DEBUG - 2013-09-21 08:23:33 --> Loader Class Initialized
DEBUG - 2013-09-21 08:23:33 --> Database Driver Class Initialized
DEBUG - 2013-09-21 08:23:33 --> Controller Class Initialized
DEBUG - 2013-09-21 08:23:33 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 08:23:33 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 08:23:33 --> Model Class Initialized
DEBUG - 2013-09-21 08:23:33 --> Helper loaded: date_helper
DEBUG - 2013-09-21 08:23:33 --> Model Class Initialized
DEBUG - 2013-09-21 08:23:33 --> Model Class Initialized
DEBUG - 2013-09-21 08:23:41 --> Config Class Initialized
DEBUG - 2013-09-21 08:23:41 --> Hooks Class Initialized
DEBUG - 2013-09-21 08:23:41 --> Utf8 Class Initialized
DEBUG - 2013-09-21 08:23:41 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 08:23:41 --> URI Class Initialized
DEBUG - 2013-09-21 08:23:41 --> Router Class Initialized
DEBUG - 2013-09-21 08:23:41 --> Output Class Initialized
DEBUG - 2013-09-21 08:23:41 --> Security Class Initialized
DEBUG - 2013-09-21 08:23:41 --> Input Class Initialized
DEBUG - 2013-09-21 08:23:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 08:23:41 --> Language Class Initialized
DEBUG - 2013-09-21 08:23:41 --> Loader Class Initialized
DEBUG - 2013-09-21 08:23:41 --> Database Driver Class Initialized
DEBUG - 2013-09-21 08:23:41 --> Controller Class Initialized
DEBUG - 2013-09-21 08:23:41 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 08:23:41 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 08:23:41 --> Model Class Initialized
DEBUG - 2013-09-21 08:23:41 --> Helper loaded: date_helper
DEBUG - 2013-09-21 08:23:41 --> Model Class Initialized
DEBUG - 2013-09-21 08:23:41 --> Model Class Initialized
DEBUG - 2013-09-21 08:23:41 --> DB Transaction Failure
ERROR - 2013-09-21 08:23:41 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1= 'admin'
LIMIT 10' at line 3
DEBUG - 2013-09-21 08:23:41 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-09-21 08:23:47 --> Config Class Initialized
DEBUG - 2013-09-21 08:23:47 --> Hooks Class Initialized
DEBUG - 2013-09-21 08:23:47 --> Utf8 Class Initialized
DEBUG - 2013-09-21 08:23:47 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 08:23:47 --> URI Class Initialized
DEBUG - 2013-09-21 08:23:47 --> Router Class Initialized
DEBUG - 2013-09-21 08:23:47 --> Output Class Initialized
DEBUG - 2013-09-21 08:23:47 --> Security Class Initialized
DEBUG - 2013-09-21 08:23:47 --> Input Class Initialized
DEBUG - 2013-09-21 08:23:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 08:23:47 --> Language Class Initialized
DEBUG - 2013-09-21 08:23:47 --> Loader Class Initialized
DEBUG - 2013-09-21 08:23:47 --> Database Driver Class Initialized
DEBUG - 2013-09-21 08:23:47 --> Controller Class Initialized
DEBUG - 2013-09-21 08:23:47 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 08:23:47 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 08:23:47 --> Model Class Initialized
DEBUG - 2013-09-21 08:23:47 --> Helper loaded: date_helper
DEBUG - 2013-09-21 08:23:47 --> Model Class Initialized
DEBUG - 2013-09-21 08:23:47 --> Model Class Initialized
DEBUG - 2013-09-21 08:23:47 --> Config Class Initialized
DEBUG - 2013-09-21 08:23:47 --> Hooks Class Initialized
DEBUG - 2013-09-21 08:23:47 --> Utf8 Class Initialized
DEBUG - 2013-09-21 08:23:47 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 08:23:47 --> URI Class Initialized
DEBUG - 2013-09-21 08:23:47 --> Router Class Initialized
DEBUG - 2013-09-21 08:23:47 --> Output Class Initialized
DEBUG - 2013-09-21 08:23:47 --> Security Class Initialized
DEBUG - 2013-09-21 08:23:47 --> Input Class Initialized
DEBUG - 2013-09-21 08:23:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 08:23:47 --> Language Class Initialized
DEBUG - 2013-09-21 08:23:47 --> Loader Class Initialized
DEBUG - 2013-09-21 08:23:47 --> Database Driver Class Initialized
DEBUG - 2013-09-21 08:23:47 --> Controller Class Initialized
DEBUG - 2013-09-21 08:23:47 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 08:23:47 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 08:23:47 --> Model Class Initialized
DEBUG - 2013-09-21 08:23:47 --> Helper loaded: date_helper
DEBUG - 2013-09-21 08:23:47 --> Model Class Initialized
DEBUG - 2013-09-21 08:23:47 --> Model Class Initialized
DEBUG - 2013-09-21 08:55:40 --> Config Class Initialized
DEBUG - 2013-09-21 08:55:40 --> Hooks Class Initialized
DEBUG - 2013-09-21 08:55:40 --> Utf8 Class Initialized
DEBUG - 2013-09-21 08:55:40 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 08:55:40 --> URI Class Initialized
DEBUG - 2013-09-21 08:55:40 --> Router Class Initialized
DEBUG - 2013-09-21 08:55:40 --> No URI present. Default controller set.
DEBUG - 2013-09-21 08:55:40 --> Output Class Initialized
DEBUG - 2013-09-21 08:55:40 --> Security Class Initialized
DEBUG - 2013-09-21 08:55:40 --> Input Class Initialized
DEBUG - 2013-09-21 08:55:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 08:55:40 --> Language Class Initialized
DEBUG - 2013-09-21 08:55:40 --> Loader Class Initialized
DEBUG - 2013-09-21 08:55:40 --> Database Driver Class Initialized
DEBUG - 2013-09-21 08:55:40 --> Controller Class Initialized
DEBUG - 2013-09-21 08:55:40 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 08:55:40 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 08:55:40 --> Model Class Initialized
DEBUG - 2013-09-21 08:55:40 --> Helper loaded: date_helper
DEBUG - 2013-09-21 08:55:40 --> Model Class Initialized
DEBUG - 2013-09-21 08:55:40 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 08:55:40 --> Final output sent to browser
DEBUG - 2013-09-21 08:55:40 --> Total execution time: 0.0350
DEBUG - 2013-09-21 08:56:06 --> Config Class Initialized
DEBUG - 2013-09-21 08:56:06 --> Hooks Class Initialized
DEBUG - 2013-09-21 08:56:06 --> Utf8 Class Initialized
DEBUG - 2013-09-21 08:56:06 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 08:56:06 --> URI Class Initialized
DEBUG - 2013-09-21 08:56:06 --> Router Class Initialized
DEBUG - 2013-09-21 08:56:06 --> No URI present. Default controller set.
DEBUG - 2013-09-21 08:56:06 --> Output Class Initialized
DEBUG - 2013-09-21 08:56:06 --> Security Class Initialized
DEBUG - 2013-09-21 08:56:06 --> Input Class Initialized
DEBUG - 2013-09-21 08:56:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 08:56:06 --> Language Class Initialized
DEBUG - 2013-09-21 08:56:06 --> Loader Class Initialized
DEBUG - 2013-09-21 08:56:06 --> Database Driver Class Initialized
DEBUG - 2013-09-21 08:56:06 --> Controller Class Initialized
DEBUG - 2013-09-21 08:56:06 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 08:56:06 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 08:56:06 --> Model Class Initialized
DEBUG - 2013-09-21 08:56:06 --> Helper loaded: date_helper
DEBUG - 2013-09-21 08:56:06 --> Model Class Initialized
DEBUG - 2013-09-21 08:56:06 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 08:56:06 --> Final output sent to browser
DEBUG - 2013-09-21 08:56:06 --> Total execution time: 0.0360
DEBUG - 2013-09-21 08:56:07 --> Config Class Initialized
DEBUG - 2013-09-21 08:56:07 --> Hooks Class Initialized
DEBUG - 2013-09-21 08:56:07 --> Utf8 Class Initialized
DEBUG - 2013-09-21 08:56:07 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 08:56:07 --> URI Class Initialized
DEBUG - 2013-09-21 08:56:07 --> Router Class Initialized
DEBUG - 2013-09-21 08:56:07 --> No URI present. Default controller set.
DEBUG - 2013-09-21 08:56:07 --> Output Class Initialized
DEBUG - 2013-09-21 08:56:07 --> Security Class Initialized
DEBUG - 2013-09-21 08:56:07 --> Input Class Initialized
DEBUG - 2013-09-21 08:56:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 08:56:07 --> Language Class Initialized
DEBUG - 2013-09-21 08:56:07 --> Loader Class Initialized
DEBUG - 2013-09-21 08:56:07 --> Database Driver Class Initialized
DEBUG - 2013-09-21 08:56:07 --> Controller Class Initialized
DEBUG - 2013-09-21 08:56:07 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 08:56:07 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 08:56:07 --> Model Class Initialized
DEBUG - 2013-09-21 08:56:07 --> Helper loaded: date_helper
DEBUG - 2013-09-21 08:56:07 --> Model Class Initialized
DEBUG - 2013-09-21 08:56:07 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 08:56:07 --> Final output sent to browser
DEBUG - 2013-09-21 08:56:07 --> Total execution time: 0.0340
DEBUG - 2013-09-21 08:56:55 --> Config Class Initialized
DEBUG - 2013-09-21 08:56:55 --> Hooks Class Initialized
DEBUG - 2013-09-21 08:56:55 --> Utf8 Class Initialized
DEBUG - 2013-09-21 08:56:55 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 08:56:55 --> URI Class Initialized
DEBUG - 2013-09-21 08:56:55 --> Router Class Initialized
DEBUG - 2013-09-21 08:56:55 --> No URI present. Default controller set.
DEBUG - 2013-09-21 08:56:55 --> Output Class Initialized
DEBUG - 2013-09-21 08:56:55 --> Security Class Initialized
DEBUG - 2013-09-21 08:56:55 --> Input Class Initialized
DEBUG - 2013-09-21 08:56:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 08:56:55 --> Language Class Initialized
DEBUG - 2013-09-21 08:56:55 --> Loader Class Initialized
DEBUG - 2013-09-21 08:56:55 --> Database Driver Class Initialized
DEBUG - 2013-09-21 08:56:55 --> Controller Class Initialized
DEBUG - 2013-09-21 08:56:55 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 08:56:55 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 08:56:55 --> Model Class Initialized
DEBUG - 2013-09-21 08:56:55 --> Helper loaded: date_helper
DEBUG - 2013-09-21 08:56:55 --> Model Class Initialized
DEBUG - 2013-09-21 08:56:55 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 08:56:55 --> Final output sent to browser
DEBUG - 2013-09-21 08:56:55 --> Total execution time: 0.0330
DEBUG - 2013-09-21 08:57:05 --> Config Class Initialized
DEBUG - 2013-09-21 08:57:05 --> Hooks Class Initialized
DEBUG - 2013-09-21 08:57:05 --> Utf8 Class Initialized
DEBUG - 2013-09-21 08:57:05 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 08:57:05 --> URI Class Initialized
DEBUG - 2013-09-21 08:57:05 --> Router Class Initialized
DEBUG - 2013-09-21 08:57:05 --> No URI present. Default controller set.
DEBUG - 2013-09-21 08:57:05 --> Output Class Initialized
DEBUG - 2013-09-21 08:57:05 --> Security Class Initialized
DEBUG - 2013-09-21 08:57:05 --> Input Class Initialized
DEBUG - 2013-09-21 08:57:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 08:57:05 --> Language Class Initialized
DEBUG - 2013-09-21 08:57:05 --> Loader Class Initialized
DEBUG - 2013-09-21 08:57:05 --> Database Driver Class Initialized
DEBUG - 2013-09-21 08:57:05 --> Controller Class Initialized
DEBUG - 2013-09-21 08:57:05 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 08:57:05 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 08:57:05 --> Model Class Initialized
DEBUG - 2013-09-21 08:57:05 --> Helper loaded: date_helper
DEBUG - 2013-09-21 08:57:05 --> Model Class Initialized
DEBUG - 2013-09-21 08:57:05 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 08:57:05 --> Final output sent to browser
DEBUG - 2013-09-21 08:57:05 --> Total execution time: 0.0340
DEBUG - 2013-09-21 08:57:05 --> Config Class Initialized
DEBUG - 2013-09-21 08:57:05 --> Hooks Class Initialized
DEBUG - 2013-09-21 08:57:05 --> Utf8 Class Initialized
DEBUG - 2013-09-21 08:57:05 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 08:57:05 --> URI Class Initialized
DEBUG - 2013-09-21 08:57:05 --> Router Class Initialized
DEBUG - 2013-09-21 08:57:05 --> No URI present. Default controller set.
DEBUG - 2013-09-21 08:57:05 --> Output Class Initialized
DEBUG - 2013-09-21 08:57:05 --> Security Class Initialized
DEBUG - 2013-09-21 08:57:05 --> Input Class Initialized
DEBUG - 2013-09-21 08:57:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 08:57:05 --> Language Class Initialized
DEBUG - 2013-09-21 08:57:05 --> Loader Class Initialized
DEBUG - 2013-09-21 08:57:05 --> Database Driver Class Initialized
DEBUG - 2013-09-21 08:57:05 --> Controller Class Initialized
DEBUG - 2013-09-21 08:57:05 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 08:57:05 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 08:57:05 --> Model Class Initialized
DEBUG - 2013-09-21 08:57:05 --> Helper loaded: date_helper
DEBUG - 2013-09-21 08:57:05 --> Model Class Initialized
DEBUG - 2013-09-21 08:57:05 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 08:57:05 --> Final output sent to browser
DEBUG - 2013-09-21 08:57:05 --> Total execution time: 0.0340
DEBUG - 2013-09-21 08:57:05 --> Config Class Initialized
DEBUG - 2013-09-21 08:57:05 --> Hooks Class Initialized
DEBUG - 2013-09-21 08:57:05 --> Utf8 Class Initialized
DEBUG - 2013-09-21 08:57:06 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 08:57:06 --> URI Class Initialized
DEBUG - 2013-09-21 08:57:06 --> Router Class Initialized
DEBUG - 2013-09-21 08:57:06 --> No URI present. Default controller set.
DEBUG - 2013-09-21 08:57:06 --> Output Class Initialized
DEBUG - 2013-09-21 08:57:06 --> Security Class Initialized
DEBUG - 2013-09-21 08:57:06 --> Input Class Initialized
DEBUG - 2013-09-21 08:57:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 08:57:06 --> Language Class Initialized
DEBUG - 2013-09-21 08:57:06 --> Loader Class Initialized
DEBUG - 2013-09-21 08:57:06 --> Database Driver Class Initialized
DEBUG - 2013-09-21 08:57:06 --> Controller Class Initialized
DEBUG - 2013-09-21 08:57:06 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 08:57:06 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 08:57:06 --> Model Class Initialized
DEBUG - 2013-09-21 08:57:06 --> Helper loaded: date_helper
DEBUG - 2013-09-21 08:57:06 --> Model Class Initialized
DEBUG - 2013-09-21 08:57:06 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 08:57:06 --> Final output sent to browser
DEBUG - 2013-09-21 08:57:06 --> Total execution time: 0.0330
DEBUG - 2013-09-21 08:57:07 --> Config Class Initialized
DEBUG - 2013-09-21 08:57:07 --> Hooks Class Initialized
DEBUG - 2013-09-21 08:57:07 --> Utf8 Class Initialized
DEBUG - 2013-09-21 08:57:07 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 08:57:07 --> URI Class Initialized
DEBUG - 2013-09-21 08:57:07 --> Router Class Initialized
DEBUG - 2013-09-21 08:57:07 --> No URI present. Default controller set.
DEBUG - 2013-09-21 08:57:07 --> Output Class Initialized
DEBUG - 2013-09-21 08:57:07 --> Security Class Initialized
DEBUG - 2013-09-21 08:57:07 --> Input Class Initialized
DEBUG - 2013-09-21 08:57:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 08:57:07 --> Language Class Initialized
DEBUG - 2013-09-21 08:57:07 --> Loader Class Initialized
DEBUG - 2013-09-21 08:57:07 --> Database Driver Class Initialized
DEBUG - 2013-09-21 08:57:07 --> Controller Class Initialized
DEBUG - 2013-09-21 08:57:07 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 08:57:07 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 08:57:07 --> Model Class Initialized
DEBUG - 2013-09-21 08:57:07 --> Helper loaded: date_helper
DEBUG - 2013-09-21 08:57:07 --> Model Class Initialized
DEBUG - 2013-09-21 08:57:07 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 08:57:07 --> Final output sent to browser
DEBUG - 2013-09-21 08:57:07 --> Total execution time: 0.0340
DEBUG - 2013-09-21 08:57:53 --> Config Class Initialized
DEBUG - 2013-09-21 08:57:53 --> Hooks Class Initialized
DEBUG - 2013-09-21 08:57:53 --> Utf8 Class Initialized
DEBUG - 2013-09-21 08:57:53 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 08:57:53 --> URI Class Initialized
DEBUG - 2013-09-21 08:57:53 --> Router Class Initialized
DEBUG - 2013-09-21 08:57:53 --> No URI present. Default controller set.
DEBUG - 2013-09-21 08:57:53 --> Output Class Initialized
DEBUG - 2013-09-21 08:57:53 --> Security Class Initialized
DEBUG - 2013-09-21 08:57:53 --> Input Class Initialized
DEBUG - 2013-09-21 08:57:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 08:57:53 --> Language Class Initialized
DEBUG - 2013-09-21 08:57:53 --> Loader Class Initialized
DEBUG - 2013-09-21 08:57:53 --> Database Driver Class Initialized
DEBUG - 2013-09-21 08:57:53 --> Controller Class Initialized
DEBUG - 2013-09-21 08:57:53 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 08:57:53 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 08:57:53 --> Model Class Initialized
DEBUG - 2013-09-21 08:57:53 --> Helper loaded: date_helper
DEBUG - 2013-09-21 08:57:53 --> Model Class Initialized
DEBUG - 2013-09-21 08:57:53 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 08:57:53 --> Final output sent to browser
DEBUG - 2013-09-21 08:57:53 --> Total execution time: 0.0330
DEBUG - 2013-09-21 09:00:52 --> Config Class Initialized
DEBUG - 2013-09-21 09:00:52 --> Hooks Class Initialized
DEBUG - 2013-09-21 09:00:52 --> Utf8 Class Initialized
DEBUG - 2013-09-21 09:00:52 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 09:00:52 --> URI Class Initialized
DEBUG - 2013-09-21 09:00:52 --> Router Class Initialized
DEBUG - 2013-09-21 09:00:52 --> No URI present. Default controller set.
DEBUG - 2013-09-21 09:00:52 --> Output Class Initialized
DEBUG - 2013-09-21 09:00:52 --> Security Class Initialized
DEBUG - 2013-09-21 09:00:52 --> Input Class Initialized
DEBUG - 2013-09-21 09:00:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 09:00:52 --> Language Class Initialized
DEBUG - 2013-09-21 09:00:52 --> Loader Class Initialized
DEBUG - 2013-09-21 09:00:52 --> Database Driver Class Initialized
DEBUG - 2013-09-21 09:00:52 --> Controller Class Initialized
DEBUG - 2013-09-21 09:00:52 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 09:00:52 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 09:00:52 --> Model Class Initialized
DEBUG - 2013-09-21 09:00:52 --> Helper loaded: date_helper
DEBUG - 2013-09-21 09:00:52 --> Model Class Initialized
DEBUG - 2013-09-21 09:00:52 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 09:00:52 --> Final output sent to browser
DEBUG - 2013-09-21 09:00:52 --> Total execution time: 0.0350
DEBUG - 2013-09-21 09:01:21 --> Config Class Initialized
DEBUG - 2013-09-21 09:01:21 --> Hooks Class Initialized
DEBUG - 2013-09-21 09:01:21 --> Utf8 Class Initialized
DEBUG - 2013-09-21 09:01:21 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 09:01:21 --> URI Class Initialized
DEBUG - 2013-09-21 09:01:21 --> Router Class Initialized
DEBUG - 2013-09-21 09:01:21 --> No URI present. Default controller set.
DEBUG - 2013-09-21 09:01:21 --> Output Class Initialized
DEBUG - 2013-09-21 09:01:21 --> Security Class Initialized
DEBUG - 2013-09-21 09:01:21 --> Input Class Initialized
DEBUG - 2013-09-21 09:01:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 09:01:21 --> Language Class Initialized
DEBUG - 2013-09-21 09:01:21 --> Loader Class Initialized
DEBUG - 2013-09-21 09:01:21 --> Database Driver Class Initialized
DEBUG - 2013-09-21 09:01:21 --> Controller Class Initialized
DEBUG - 2013-09-21 09:01:21 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 09:01:21 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 09:01:21 --> Model Class Initialized
DEBUG - 2013-09-21 09:01:21 --> Helper loaded: date_helper
DEBUG - 2013-09-21 09:01:21 --> Model Class Initialized
DEBUG - 2013-09-21 09:01:21 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 09:01:21 --> Final output sent to browser
DEBUG - 2013-09-21 09:01:21 --> Total execution time: 0.0330
DEBUG - 2013-09-21 09:01:46 --> Config Class Initialized
DEBUG - 2013-09-21 09:01:46 --> Hooks Class Initialized
DEBUG - 2013-09-21 09:01:46 --> Utf8 Class Initialized
DEBUG - 2013-09-21 09:01:46 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 09:01:46 --> URI Class Initialized
DEBUG - 2013-09-21 09:01:46 --> Router Class Initialized
DEBUG - 2013-09-21 09:01:46 --> No URI present. Default controller set.
DEBUG - 2013-09-21 09:01:46 --> Output Class Initialized
DEBUG - 2013-09-21 09:01:46 --> Security Class Initialized
DEBUG - 2013-09-21 09:01:46 --> Input Class Initialized
DEBUG - 2013-09-21 09:01:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 09:01:46 --> Language Class Initialized
DEBUG - 2013-09-21 09:01:46 --> Loader Class Initialized
DEBUG - 2013-09-21 09:01:46 --> Database Driver Class Initialized
DEBUG - 2013-09-21 09:01:46 --> Controller Class Initialized
DEBUG - 2013-09-21 09:01:46 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 09:01:46 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 09:01:46 --> Model Class Initialized
DEBUG - 2013-09-21 09:01:46 --> Helper loaded: date_helper
DEBUG - 2013-09-21 09:01:46 --> Model Class Initialized
DEBUG - 2013-09-21 09:01:46 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 09:01:46 --> Final output sent to browser
DEBUG - 2013-09-21 09:01:46 --> Total execution time: 0.0340
DEBUG - 2013-09-21 09:01:56 --> Config Class Initialized
DEBUG - 2013-09-21 09:01:56 --> Hooks Class Initialized
DEBUG - 2013-09-21 09:01:56 --> Utf8 Class Initialized
DEBUG - 2013-09-21 09:01:56 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 09:01:56 --> URI Class Initialized
DEBUG - 2013-09-21 09:01:56 --> Router Class Initialized
DEBUG - 2013-09-21 09:01:56 --> No URI present. Default controller set.
DEBUG - 2013-09-21 09:01:56 --> Output Class Initialized
DEBUG - 2013-09-21 09:01:56 --> Security Class Initialized
DEBUG - 2013-09-21 09:01:56 --> Input Class Initialized
DEBUG - 2013-09-21 09:01:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 09:01:56 --> Language Class Initialized
DEBUG - 2013-09-21 09:01:56 --> Loader Class Initialized
DEBUG - 2013-09-21 09:01:56 --> Database Driver Class Initialized
DEBUG - 2013-09-21 09:01:56 --> Controller Class Initialized
DEBUG - 2013-09-21 09:01:56 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 09:01:56 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 09:01:56 --> Model Class Initialized
DEBUG - 2013-09-21 09:01:56 --> Helper loaded: date_helper
DEBUG - 2013-09-21 09:01:56 --> Model Class Initialized
DEBUG - 2013-09-21 09:01:56 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 09:01:56 --> Final output sent to browser
DEBUG - 2013-09-21 09:01:56 --> Total execution time: 0.0340
DEBUG - 2013-09-21 09:04:37 --> Config Class Initialized
DEBUG - 2013-09-21 09:04:37 --> Hooks Class Initialized
DEBUG - 2013-09-21 09:04:37 --> Utf8 Class Initialized
DEBUG - 2013-09-21 09:04:37 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 09:04:37 --> URI Class Initialized
DEBUG - 2013-09-21 09:04:37 --> Router Class Initialized
DEBUG - 2013-09-21 09:04:37 --> No URI present. Default controller set.
DEBUG - 2013-09-21 09:04:37 --> Output Class Initialized
DEBUG - 2013-09-21 09:04:37 --> Security Class Initialized
DEBUG - 2013-09-21 09:04:37 --> Input Class Initialized
DEBUG - 2013-09-21 09:04:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 09:04:37 --> Language Class Initialized
DEBUG - 2013-09-21 09:04:37 --> Loader Class Initialized
DEBUG - 2013-09-21 09:04:37 --> Database Driver Class Initialized
DEBUG - 2013-09-21 09:04:37 --> Controller Class Initialized
DEBUG - 2013-09-21 09:04:37 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 09:04:37 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 09:04:37 --> Model Class Initialized
DEBUG - 2013-09-21 09:04:37 --> Helper loaded: date_helper
DEBUG - 2013-09-21 09:04:37 --> Model Class Initialized
DEBUG - 2013-09-21 09:04:37 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 09:04:37 --> Final output sent to browser
DEBUG - 2013-09-21 09:04:37 --> Total execution time: 0.0340
DEBUG - 2013-09-21 09:05:04 --> Config Class Initialized
DEBUG - 2013-09-21 09:05:04 --> Hooks Class Initialized
DEBUG - 2013-09-21 09:05:04 --> Utf8 Class Initialized
DEBUG - 2013-09-21 09:05:04 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 09:05:04 --> URI Class Initialized
DEBUG - 2013-09-21 09:05:04 --> Router Class Initialized
DEBUG - 2013-09-21 09:05:04 --> No URI present. Default controller set.
DEBUG - 2013-09-21 09:05:04 --> Output Class Initialized
DEBUG - 2013-09-21 09:05:04 --> Security Class Initialized
DEBUG - 2013-09-21 09:05:04 --> Input Class Initialized
DEBUG - 2013-09-21 09:05:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 09:05:04 --> Language Class Initialized
DEBUG - 2013-09-21 09:05:04 --> Loader Class Initialized
DEBUG - 2013-09-21 09:05:04 --> Database Driver Class Initialized
DEBUG - 2013-09-21 09:05:04 --> Controller Class Initialized
DEBUG - 2013-09-21 09:05:04 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 09:05:04 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 09:05:04 --> Model Class Initialized
DEBUG - 2013-09-21 09:05:04 --> Helper loaded: date_helper
DEBUG - 2013-09-21 09:05:04 --> Model Class Initialized
DEBUG - 2013-09-21 09:05:04 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 09:05:04 --> Final output sent to browser
DEBUG - 2013-09-21 09:05:04 --> Total execution time: 0.0340
DEBUG - 2013-09-21 09:24:03 --> Config Class Initialized
DEBUG - 2013-09-21 09:24:03 --> Hooks Class Initialized
DEBUG - 2013-09-21 09:24:03 --> Utf8 Class Initialized
DEBUG - 2013-09-21 09:24:03 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 09:24:03 --> URI Class Initialized
DEBUG - 2013-09-21 09:24:03 --> Router Class Initialized
DEBUG - 2013-09-21 09:24:03 --> No URI present. Default controller set.
DEBUG - 2013-09-21 09:24:03 --> Output Class Initialized
DEBUG - 2013-09-21 09:24:03 --> Security Class Initialized
DEBUG - 2013-09-21 09:24:03 --> Input Class Initialized
DEBUG - 2013-09-21 09:24:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 09:24:03 --> Language Class Initialized
DEBUG - 2013-09-21 09:24:03 --> Loader Class Initialized
DEBUG - 2013-09-21 09:24:03 --> Database Driver Class Initialized
DEBUG - 2013-09-21 09:24:03 --> Controller Class Initialized
DEBUG - 2013-09-21 09:24:03 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 09:24:03 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 09:24:03 --> Model Class Initialized
DEBUG - 2013-09-21 09:24:03 --> Helper loaded: date_helper
DEBUG - 2013-09-21 09:24:03 --> Model Class Initialized
DEBUG - 2013-09-21 09:24:03 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 09:24:03 --> Final output sent to browser
DEBUG - 2013-09-21 09:24:03 --> Total execution time: 0.0370
DEBUG - 2013-09-21 09:24:42 --> Config Class Initialized
DEBUG - 2013-09-21 09:24:42 --> Hooks Class Initialized
DEBUG - 2013-09-21 09:24:42 --> Utf8 Class Initialized
DEBUG - 2013-09-21 09:24:42 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 09:24:42 --> URI Class Initialized
DEBUG - 2013-09-21 09:24:42 --> Router Class Initialized
DEBUG - 2013-09-21 09:24:42 --> No URI present. Default controller set.
DEBUG - 2013-09-21 09:24:42 --> Output Class Initialized
DEBUG - 2013-09-21 09:24:42 --> Security Class Initialized
DEBUG - 2013-09-21 09:24:42 --> Input Class Initialized
DEBUG - 2013-09-21 09:24:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 09:24:42 --> Language Class Initialized
DEBUG - 2013-09-21 09:24:42 --> Loader Class Initialized
DEBUG - 2013-09-21 09:24:42 --> Database Driver Class Initialized
DEBUG - 2013-09-21 09:24:42 --> Controller Class Initialized
DEBUG - 2013-09-21 09:24:42 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 09:24:42 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 09:24:42 --> Model Class Initialized
DEBUG - 2013-09-21 09:24:42 --> Helper loaded: date_helper
DEBUG - 2013-09-21 09:24:42 --> Model Class Initialized
DEBUG - 2013-09-21 09:24:42 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 09:24:42 --> Final output sent to browser
DEBUG - 2013-09-21 09:24:42 --> Total execution time: 0.0350
DEBUG - 2013-09-21 09:25:50 --> Config Class Initialized
DEBUG - 2013-09-21 09:25:50 --> Hooks Class Initialized
DEBUG - 2013-09-21 09:25:50 --> Utf8 Class Initialized
DEBUG - 2013-09-21 09:25:50 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 09:25:50 --> URI Class Initialized
DEBUG - 2013-09-21 09:25:50 --> Router Class Initialized
DEBUG - 2013-09-21 09:25:50 --> No URI present. Default controller set.
DEBUG - 2013-09-21 09:25:50 --> Output Class Initialized
DEBUG - 2013-09-21 09:25:50 --> Security Class Initialized
DEBUG - 2013-09-21 09:25:50 --> Input Class Initialized
DEBUG - 2013-09-21 09:25:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 09:25:50 --> Language Class Initialized
DEBUG - 2013-09-21 09:25:50 --> Loader Class Initialized
DEBUG - 2013-09-21 09:25:50 --> Database Driver Class Initialized
DEBUG - 2013-09-21 09:25:50 --> Controller Class Initialized
DEBUG - 2013-09-21 09:25:50 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 09:25:50 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 09:25:50 --> Model Class Initialized
DEBUG - 2013-09-21 09:25:50 --> Helper loaded: date_helper
DEBUG - 2013-09-21 09:25:50 --> Model Class Initialized
DEBUG - 2013-09-21 09:25:50 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 09:25:50 --> Final output sent to browser
DEBUG - 2013-09-21 09:25:50 --> Total execution time: 0.0350
DEBUG - 2013-09-21 09:25:57 --> Config Class Initialized
DEBUG - 2013-09-21 09:25:57 --> Hooks Class Initialized
DEBUG - 2013-09-21 09:25:57 --> Utf8 Class Initialized
DEBUG - 2013-09-21 09:25:57 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 09:25:57 --> URI Class Initialized
DEBUG - 2013-09-21 09:25:57 --> Router Class Initialized
DEBUG - 2013-09-21 09:25:57 --> No URI present. Default controller set.
DEBUG - 2013-09-21 09:25:57 --> Output Class Initialized
DEBUG - 2013-09-21 09:25:57 --> Security Class Initialized
DEBUG - 2013-09-21 09:25:57 --> Input Class Initialized
DEBUG - 2013-09-21 09:25:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 09:25:57 --> Language Class Initialized
DEBUG - 2013-09-21 09:25:57 --> Loader Class Initialized
DEBUG - 2013-09-21 09:25:57 --> Database Driver Class Initialized
DEBUG - 2013-09-21 09:25:57 --> Controller Class Initialized
DEBUG - 2013-09-21 09:25:57 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 09:25:57 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 09:25:57 --> Model Class Initialized
DEBUG - 2013-09-21 09:25:57 --> Helper loaded: date_helper
DEBUG - 2013-09-21 09:25:57 --> Model Class Initialized
DEBUG - 2013-09-21 09:25:57 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 09:25:57 --> Final output sent to browser
DEBUG - 2013-09-21 09:25:57 --> Total execution time: 0.0340
DEBUG - 2013-09-21 09:26:10 --> Config Class Initialized
DEBUG - 2013-09-21 09:26:10 --> Hooks Class Initialized
DEBUG - 2013-09-21 09:26:10 --> Utf8 Class Initialized
DEBUG - 2013-09-21 09:26:10 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 09:26:10 --> URI Class Initialized
DEBUG - 2013-09-21 09:26:10 --> Router Class Initialized
DEBUG - 2013-09-21 09:26:10 --> No URI present. Default controller set.
DEBUG - 2013-09-21 09:26:10 --> Output Class Initialized
DEBUG - 2013-09-21 09:26:10 --> Security Class Initialized
DEBUG - 2013-09-21 09:26:10 --> Input Class Initialized
DEBUG - 2013-09-21 09:26:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 09:26:10 --> Language Class Initialized
DEBUG - 2013-09-21 09:26:10 --> Loader Class Initialized
DEBUG - 2013-09-21 09:26:10 --> Database Driver Class Initialized
DEBUG - 2013-09-21 09:26:10 --> Controller Class Initialized
DEBUG - 2013-09-21 09:26:10 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 09:26:10 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 09:26:10 --> Model Class Initialized
DEBUG - 2013-09-21 09:26:10 --> Helper loaded: date_helper
DEBUG - 2013-09-21 09:26:10 --> Model Class Initialized
DEBUG - 2013-09-21 09:26:10 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 09:26:10 --> Final output sent to browser
DEBUG - 2013-09-21 09:26:10 --> Total execution time: 0.0340
DEBUG - 2013-09-21 09:26:12 --> Config Class Initialized
DEBUG - 2013-09-21 09:26:12 --> Hooks Class Initialized
DEBUG - 2013-09-21 09:26:12 --> Utf8 Class Initialized
DEBUG - 2013-09-21 09:26:12 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 09:26:12 --> URI Class Initialized
DEBUG - 2013-09-21 09:26:12 --> Router Class Initialized
DEBUG - 2013-09-21 09:26:12 --> No URI present. Default controller set.
DEBUG - 2013-09-21 09:26:12 --> Output Class Initialized
DEBUG - 2013-09-21 09:26:12 --> Security Class Initialized
DEBUG - 2013-09-21 09:26:12 --> Input Class Initialized
DEBUG - 2013-09-21 09:26:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 09:26:12 --> Language Class Initialized
DEBUG - 2013-09-21 09:26:12 --> Loader Class Initialized
DEBUG - 2013-09-21 09:26:12 --> Database Driver Class Initialized
DEBUG - 2013-09-21 09:26:12 --> Controller Class Initialized
DEBUG - 2013-09-21 09:26:12 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 09:26:12 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 09:26:12 --> Model Class Initialized
DEBUG - 2013-09-21 09:26:12 --> Helper loaded: date_helper
DEBUG - 2013-09-21 09:26:12 --> Model Class Initialized
DEBUG - 2013-09-21 09:26:12 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 09:26:12 --> Final output sent to browser
DEBUG - 2013-09-21 09:26:12 --> Total execution time: 0.0340
DEBUG - 2013-09-21 09:26:33 --> Config Class Initialized
DEBUG - 2013-09-21 09:26:33 --> Hooks Class Initialized
DEBUG - 2013-09-21 09:26:33 --> Utf8 Class Initialized
DEBUG - 2013-09-21 09:26:33 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 09:26:33 --> URI Class Initialized
DEBUG - 2013-09-21 09:26:33 --> Router Class Initialized
DEBUG - 2013-09-21 09:26:33 --> No URI present. Default controller set.
DEBUG - 2013-09-21 09:26:33 --> Output Class Initialized
DEBUG - 2013-09-21 09:26:33 --> Security Class Initialized
DEBUG - 2013-09-21 09:26:33 --> Input Class Initialized
DEBUG - 2013-09-21 09:26:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 09:26:33 --> Language Class Initialized
DEBUG - 2013-09-21 09:26:33 --> Loader Class Initialized
DEBUG - 2013-09-21 09:26:33 --> Database Driver Class Initialized
DEBUG - 2013-09-21 09:26:33 --> Controller Class Initialized
DEBUG - 2013-09-21 09:26:33 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 09:26:33 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 09:26:33 --> Model Class Initialized
DEBUG - 2013-09-21 09:26:33 --> Helper loaded: date_helper
DEBUG - 2013-09-21 09:26:33 --> Model Class Initialized
DEBUG - 2013-09-21 09:26:33 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 09:26:33 --> Final output sent to browser
DEBUG - 2013-09-21 09:26:33 --> Total execution time: 0.0340
DEBUG - 2013-09-21 09:26:43 --> Config Class Initialized
DEBUG - 2013-09-21 09:26:43 --> Hooks Class Initialized
DEBUG - 2013-09-21 09:26:43 --> Utf8 Class Initialized
DEBUG - 2013-09-21 09:26:43 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 09:26:43 --> URI Class Initialized
DEBUG - 2013-09-21 09:26:43 --> Router Class Initialized
DEBUG - 2013-09-21 09:26:44 --> No URI present. Default controller set.
DEBUG - 2013-09-21 09:26:44 --> Output Class Initialized
DEBUG - 2013-09-21 09:26:44 --> Security Class Initialized
DEBUG - 2013-09-21 09:26:44 --> Input Class Initialized
DEBUG - 2013-09-21 09:26:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 09:26:44 --> Language Class Initialized
DEBUG - 2013-09-21 09:26:44 --> Loader Class Initialized
DEBUG - 2013-09-21 09:26:44 --> Database Driver Class Initialized
DEBUG - 2013-09-21 09:26:44 --> Controller Class Initialized
DEBUG - 2013-09-21 09:26:44 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 09:26:44 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 09:26:44 --> Model Class Initialized
DEBUG - 2013-09-21 09:26:44 --> Helper loaded: date_helper
DEBUG - 2013-09-21 09:26:44 --> Model Class Initialized
DEBUG - 2013-09-21 09:26:44 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 09:26:44 --> Final output sent to browser
DEBUG - 2013-09-21 09:26:44 --> Total execution time: 0.0330
DEBUG - 2013-09-21 09:26:45 --> Config Class Initialized
DEBUG - 2013-09-21 09:26:45 --> Hooks Class Initialized
DEBUG - 2013-09-21 09:26:45 --> Utf8 Class Initialized
DEBUG - 2013-09-21 09:26:45 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 09:26:45 --> URI Class Initialized
DEBUG - 2013-09-21 09:26:45 --> Router Class Initialized
DEBUG - 2013-09-21 09:26:45 --> No URI present. Default controller set.
DEBUG - 2013-09-21 09:26:45 --> Output Class Initialized
DEBUG - 2013-09-21 09:26:45 --> Security Class Initialized
DEBUG - 2013-09-21 09:26:45 --> Input Class Initialized
DEBUG - 2013-09-21 09:26:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 09:26:45 --> Language Class Initialized
DEBUG - 2013-09-21 09:26:45 --> Loader Class Initialized
DEBUG - 2013-09-21 09:26:45 --> Database Driver Class Initialized
DEBUG - 2013-09-21 09:26:45 --> Controller Class Initialized
DEBUG - 2013-09-21 09:26:45 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 09:26:45 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 09:26:45 --> Model Class Initialized
DEBUG - 2013-09-21 09:26:45 --> Helper loaded: date_helper
DEBUG - 2013-09-21 09:26:45 --> Model Class Initialized
DEBUG - 2013-09-21 09:26:45 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 09:26:45 --> Final output sent to browser
DEBUG - 2013-09-21 09:26:45 --> Total execution time: 0.0340
DEBUG - 2013-09-21 09:26:52 --> Config Class Initialized
DEBUG - 2013-09-21 09:26:52 --> Hooks Class Initialized
DEBUG - 2013-09-21 09:26:52 --> Utf8 Class Initialized
DEBUG - 2013-09-21 09:26:52 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 09:26:52 --> URI Class Initialized
DEBUG - 2013-09-21 09:26:52 --> Router Class Initialized
DEBUG - 2013-09-21 09:26:52 --> No URI present. Default controller set.
DEBUG - 2013-09-21 09:26:52 --> Output Class Initialized
DEBUG - 2013-09-21 09:26:52 --> Security Class Initialized
DEBUG - 2013-09-21 09:26:52 --> Input Class Initialized
DEBUG - 2013-09-21 09:26:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 09:26:52 --> Language Class Initialized
DEBUG - 2013-09-21 09:26:52 --> Loader Class Initialized
DEBUG - 2013-09-21 09:26:52 --> Database Driver Class Initialized
DEBUG - 2013-09-21 09:26:52 --> Controller Class Initialized
DEBUG - 2013-09-21 09:26:52 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 09:26:52 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 09:26:52 --> Model Class Initialized
DEBUG - 2013-09-21 09:26:52 --> Helper loaded: date_helper
DEBUG - 2013-09-21 09:26:52 --> Model Class Initialized
DEBUG - 2013-09-21 09:26:52 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 09:26:52 --> Final output sent to browser
DEBUG - 2013-09-21 09:26:52 --> Total execution time: 0.0350
DEBUG - 2013-09-21 09:27:22 --> Config Class Initialized
DEBUG - 2013-09-21 09:27:22 --> Hooks Class Initialized
DEBUG - 2013-09-21 09:27:22 --> Utf8 Class Initialized
DEBUG - 2013-09-21 09:27:22 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 09:27:22 --> URI Class Initialized
DEBUG - 2013-09-21 09:27:22 --> Router Class Initialized
DEBUG - 2013-09-21 09:27:22 --> No URI present. Default controller set.
DEBUG - 2013-09-21 09:27:22 --> Output Class Initialized
DEBUG - 2013-09-21 09:27:22 --> Security Class Initialized
DEBUG - 2013-09-21 09:27:22 --> Input Class Initialized
DEBUG - 2013-09-21 09:27:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 09:27:22 --> Language Class Initialized
DEBUG - 2013-09-21 09:27:22 --> Loader Class Initialized
DEBUG - 2013-09-21 09:27:22 --> Database Driver Class Initialized
DEBUG - 2013-09-21 09:27:22 --> Controller Class Initialized
DEBUG - 2013-09-21 09:27:22 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 09:27:22 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 09:27:22 --> Model Class Initialized
DEBUG - 2013-09-21 09:27:22 --> Helper loaded: date_helper
DEBUG - 2013-09-21 09:27:22 --> Model Class Initialized
DEBUG - 2013-09-21 09:27:22 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 09:27:22 --> Final output sent to browser
DEBUG - 2013-09-21 09:27:22 --> Total execution time: 0.0350
DEBUG - 2013-09-21 09:37:09 --> Config Class Initialized
DEBUG - 2013-09-21 09:37:09 --> Hooks Class Initialized
DEBUG - 2013-09-21 09:37:09 --> Utf8 Class Initialized
DEBUG - 2013-09-21 09:37:09 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 09:37:09 --> URI Class Initialized
DEBUG - 2013-09-21 09:37:09 --> Router Class Initialized
DEBUG - 2013-09-21 09:37:09 --> No URI present. Default controller set.
DEBUG - 2013-09-21 09:37:09 --> Output Class Initialized
DEBUG - 2013-09-21 09:37:09 --> Security Class Initialized
DEBUG - 2013-09-21 09:37:09 --> Input Class Initialized
DEBUG - 2013-09-21 09:37:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 09:37:09 --> Language Class Initialized
DEBUG - 2013-09-21 09:37:09 --> Loader Class Initialized
DEBUG - 2013-09-21 09:37:09 --> Database Driver Class Initialized
DEBUG - 2013-09-21 09:37:09 --> Controller Class Initialized
DEBUG - 2013-09-21 09:37:09 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 09:37:09 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 09:37:09 --> Model Class Initialized
DEBUG - 2013-09-21 09:37:09 --> Helper loaded: date_helper
DEBUG - 2013-09-21 09:37:09 --> Model Class Initialized
DEBUG - 2013-09-21 09:37:09 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 09:37:09 --> Final output sent to browser
DEBUG - 2013-09-21 09:37:09 --> Total execution time: 0.0360
DEBUG - 2013-09-21 09:37:19 --> Config Class Initialized
DEBUG - 2013-09-21 09:37:19 --> Hooks Class Initialized
DEBUG - 2013-09-21 09:37:19 --> Utf8 Class Initialized
DEBUG - 2013-09-21 09:37:19 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 09:37:19 --> URI Class Initialized
DEBUG - 2013-09-21 09:37:19 --> Router Class Initialized
DEBUG - 2013-09-21 09:37:19 --> No URI present. Default controller set.
DEBUG - 2013-09-21 09:37:19 --> Output Class Initialized
DEBUG - 2013-09-21 09:37:19 --> Security Class Initialized
DEBUG - 2013-09-21 09:37:19 --> Input Class Initialized
DEBUG - 2013-09-21 09:37:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 09:37:19 --> Language Class Initialized
DEBUG - 2013-09-21 09:37:19 --> Loader Class Initialized
DEBUG - 2013-09-21 09:37:19 --> Database Driver Class Initialized
DEBUG - 2013-09-21 09:37:19 --> Controller Class Initialized
DEBUG - 2013-09-21 09:37:19 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 09:37:19 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 09:37:19 --> Model Class Initialized
DEBUG - 2013-09-21 09:37:19 --> Helper loaded: date_helper
DEBUG - 2013-09-21 09:37:19 --> Model Class Initialized
DEBUG - 2013-09-21 09:37:19 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 09:37:19 --> Final output sent to browser
DEBUG - 2013-09-21 09:37:19 --> Total execution time: 0.0350
DEBUG - 2013-09-21 09:44:56 --> Config Class Initialized
DEBUG - 2013-09-21 09:44:56 --> Hooks Class Initialized
DEBUG - 2013-09-21 09:44:56 --> Utf8 Class Initialized
DEBUG - 2013-09-21 09:44:56 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 09:44:56 --> URI Class Initialized
DEBUG - 2013-09-21 09:44:56 --> Router Class Initialized
DEBUG - 2013-09-21 09:44:56 --> No URI present. Default controller set.
DEBUG - 2013-09-21 09:44:56 --> Output Class Initialized
DEBUG - 2013-09-21 09:44:56 --> Security Class Initialized
DEBUG - 2013-09-21 09:44:56 --> Input Class Initialized
DEBUG - 2013-09-21 09:44:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 09:44:56 --> Language Class Initialized
DEBUG - 2013-09-21 09:44:56 --> Loader Class Initialized
DEBUG - 2013-09-21 09:44:56 --> Database Driver Class Initialized
DEBUG - 2013-09-21 09:44:56 --> Controller Class Initialized
DEBUG - 2013-09-21 09:44:56 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 09:44:56 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 09:44:56 --> Model Class Initialized
DEBUG - 2013-09-21 09:44:56 --> Helper loaded: date_helper
DEBUG - 2013-09-21 09:44:56 --> Model Class Initialized
DEBUG - 2013-09-21 09:44:56 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 09:44:56 --> Final output sent to browser
DEBUG - 2013-09-21 09:44:56 --> Total execution time: 0.0370
DEBUG - 2013-09-21 09:49:05 --> Config Class Initialized
DEBUG - 2013-09-21 09:49:05 --> Hooks Class Initialized
DEBUG - 2013-09-21 09:49:05 --> Utf8 Class Initialized
DEBUG - 2013-09-21 09:49:05 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 09:49:05 --> URI Class Initialized
DEBUG - 2013-09-21 09:49:05 --> Router Class Initialized
DEBUG - 2013-09-21 09:49:05 --> No URI present. Default controller set.
DEBUG - 2013-09-21 09:49:05 --> Output Class Initialized
DEBUG - 2013-09-21 09:49:05 --> Security Class Initialized
DEBUG - 2013-09-21 09:49:05 --> Input Class Initialized
DEBUG - 2013-09-21 09:49:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 09:49:05 --> Language Class Initialized
DEBUG - 2013-09-21 09:49:05 --> Loader Class Initialized
DEBUG - 2013-09-21 09:49:05 --> Database Driver Class Initialized
DEBUG - 2013-09-21 09:49:05 --> Controller Class Initialized
DEBUG - 2013-09-21 09:49:05 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 09:49:05 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 09:49:05 --> Model Class Initialized
DEBUG - 2013-09-21 09:49:05 --> Helper loaded: date_helper
DEBUG - 2013-09-21 09:49:05 --> Model Class Initialized
DEBUG - 2013-09-21 09:49:05 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 09:49:05 --> Final output sent to browser
DEBUG - 2013-09-21 09:49:05 --> Total execution time: 0.0350
DEBUG - 2013-09-21 09:51:34 --> Config Class Initialized
DEBUG - 2013-09-21 09:51:34 --> Hooks Class Initialized
DEBUG - 2013-09-21 09:51:34 --> Utf8 Class Initialized
DEBUG - 2013-09-21 09:51:34 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 09:51:34 --> URI Class Initialized
DEBUG - 2013-09-21 09:51:34 --> Router Class Initialized
DEBUG - 2013-09-21 09:51:34 --> No URI present. Default controller set.
DEBUG - 2013-09-21 09:51:34 --> Output Class Initialized
DEBUG - 2013-09-21 09:51:34 --> Security Class Initialized
DEBUG - 2013-09-21 09:51:34 --> Input Class Initialized
DEBUG - 2013-09-21 09:51:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 09:51:34 --> Language Class Initialized
DEBUG - 2013-09-21 09:51:34 --> Loader Class Initialized
DEBUG - 2013-09-21 09:51:34 --> Database Driver Class Initialized
DEBUG - 2013-09-21 09:51:34 --> Controller Class Initialized
DEBUG - 2013-09-21 09:51:34 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 09:51:34 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 09:51:34 --> Model Class Initialized
DEBUG - 2013-09-21 09:51:34 --> Helper loaded: date_helper
DEBUG - 2013-09-21 09:51:34 --> Model Class Initialized
DEBUG - 2013-09-21 09:51:34 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 09:51:34 --> Final output sent to browser
DEBUG - 2013-09-21 09:51:34 --> Total execution time: 0.0370
DEBUG - 2013-09-21 09:51:52 --> Config Class Initialized
DEBUG - 2013-09-21 09:51:52 --> Hooks Class Initialized
DEBUG - 2013-09-21 09:51:52 --> Utf8 Class Initialized
DEBUG - 2013-09-21 09:51:52 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 09:51:52 --> URI Class Initialized
DEBUG - 2013-09-21 09:51:52 --> Router Class Initialized
DEBUG - 2013-09-21 09:51:52 --> No URI present. Default controller set.
DEBUG - 2013-09-21 09:51:52 --> Output Class Initialized
DEBUG - 2013-09-21 09:51:52 --> Security Class Initialized
DEBUG - 2013-09-21 09:51:52 --> Input Class Initialized
DEBUG - 2013-09-21 09:51:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 09:51:52 --> Language Class Initialized
DEBUG - 2013-09-21 09:51:52 --> Loader Class Initialized
DEBUG - 2013-09-21 09:51:52 --> Database Driver Class Initialized
DEBUG - 2013-09-21 09:51:52 --> Controller Class Initialized
DEBUG - 2013-09-21 09:51:52 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 09:51:52 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 09:51:52 --> Model Class Initialized
DEBUG - 2013-09-21 09:51:52 --> Helper loaded: date_helper
DEBUG - 2013-09-21 09:51:52 --> Model Class Initialized
DEBUG - 2013-09-21 09:51:52 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 09:51:52 --> Final output sent to browser
DEBUG - 2013-09-21 09:51:52 --> Total execution time: 0.0350
DEBUG - 2013-09-21 09:52:49 --> Config Class Initialized
DEBUG - 2013-09-21 09:52:49 --> Hooks Class Initialized
DEBUG - 2013-09-21 09:52:49 --> Utf8 Class Initialized
DEBUG - 2013-09-21 09:52:49 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 09:52:49 --> URI Class Initialized
DEBUG - 2013-09-21 09:52:49 --> Router Class Initialized
DEBUG - 2013-09-21 09:52:49 --> No URI present. Default controller set.
DEBUG - 2013-09-21 09:52:49 --> Output Class Initialized
DEBUG - 2013-09-21 09:52:49 --> Security Class Initialized
DEBUG - 2013-09-21 09:52:49 --> Input Class Initialized
DEBUG - 2013-09-21 09:52:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 09:52:49 --> Language Class Initialized
DEBUG - 2013-09-21 09:52:49 --> Loader Class Initialized
DEBUG - 2013-09-21 09:52:49 --> Database Driver Class Initialized
DEBUG - 2013-09-21 09:52:49 --> Controller Class Initialized
DEBUG - 2013-09-21 09:52:49 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 09:52:49 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 09:52:49 --> Model Class Initialized
DEBUG - 2013-09-21 09:52:49 --> Helper loaded: date_helper
DEBUG - 2013-09-21 09:52:49 --> Model Class Initialized
DEBUG - 2013-09-21 09:52:49 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 09:52:49 --> Final output sent to browser
DEBUG - 2013-09-21 09:52:49 --> Total execution time: 0.0340
DEBUG - 2013-09-21 09:53:01 --> Config Class Initialized
DEBUG - 2013-09-21 09:53:01 --> Hooks Class Initialized
DEBUG - 2013-09-21 09:53:01 --> Utf8 Class Initialized
DEBUG - 2013-09-21 09:53:01 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 09:53:01 --> URI Class Initialized
DEBUG - 2013-09-21 09:53:01 --> Router Class Initialized
DEBUG - 2013-09-21 09:53:01 --> No URI present. Default controller set.
DEBUG - 2013-09-21 09:53:01 --> Output Class Initialized
DEBUG - 2013-09-21 09:53:01 --> Security Class Initialized
DEBUG - 2013-09-21 09:53:01 --> Input Class Initialized
DEBUG - 2013-09-21 09:53:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 09:53:01 --> Language Class Initialized
DEBUG - 2013-09-21 09:53:01 --> Loader Class Initialized
DEBUG - 2013-09-21 09:53:01 --> Database Driver Class Initialized
DEBUG - 2013-09-21 09:53:01 --> Controller Class Initialized
DEBUG - 2013-09-21 09:53:01 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 09:53:01 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 09:53:01 --> Model Class Initialized
DEBUG - 2013-09-21 09:53:01 --> Helper loaded: date_helper
DEBUG - 2013-09-21 09:53:01 --> Model Class Initialized
DEBUG - 2013-09-21 09:53:01 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 09:53:01 --> Final output sent to browser
DEBUG - 2013-09-21 09:53:01 --> Total execution time: 0.0340
DEBUG - 2013-09-21 09:53:09 --> Config Class Initialized
DEBUG - 2013-09-21 09:53:09 --> Hooks Class Initialized
DEBUG - 2013-09-21 09:53:09 --> Utf8 Class Initialized
DEBUG - 2013-09-21 09:53:09 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 09:53:09 --> URI Class Initialized
DEBUG - 2013-09-21 09:53:09 --> Router Class Initialized
DEBUG - 2013-09-21 09:53:09 --> No URI present. Default controller set.
DEBUG - 2013-09-21 09:53:09 --> Output Class Initialized
DEBUG - 2013-09-21 09:53:09 --> Security Class Initialized
DEBUG - 2013-09-21 09:53:09 --> Input Class Initialized
DEBUG - 2013-09-21 09:53:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 09:53:09 --> Language Class Initialized
DEBUG - 2013-09-21 09:53:09 --> Loader Class Initialized
DEBUG - 2013-09-21 09:53:09 --> Database Driver Class Initialized
DEBUG - 2013-09-21 09:53:09 --> Controller Class Initialized
DEBUG - 2013-09-21 09:53:09 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 09:53:09 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 09:53:09 --> Model Class Initialized
DEBUG - 2013-09-21 09:53:09 --> Helper loaded: date_helper
DEBUG - 2013-09-21 09:53:09 --> Model Class Initialized
DEBUG - 2013-09-21 09:53:09 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 09:53:09 --> Final output sent to browser
DEBUG - 2013-09-21 09:53:09 --> Total execution time: 0.0340
DEBUG - 2013-09-21 10:00:18 --> Config Class Initialized
DEBUG - 2013-09-21 10:00:18 --> Hooks Class Initialized
DEBUG - 2013-09-21 10:00:18 --> Utf8 Class Initialized
DEBUG - 2013-09-21 10:00:18 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 10:00:18 --> URI Class Initialized
DEBUG - 2013-09-21 10:00:18 --> Router Class Initialized
DEBUG - 2013-09-21 10:00:18 --> No URI present. Default controller set.
DEBUG - 2013-09-21 10:00:18 --> Output Class Initialized
DEBUG - 2013-09-21 10:00:18 --> Security Class Initialized
DEBUG - 2013-09-21 10:00:18 --> Input Class Initialized
DEBUG - 2013-09-21 10:00:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 10:00:18 --> Language Class Initialized
DEBUG - 2013-09-21 10:00:18 --> Loader Class Initialized
DEBUG - 2013-09-21 10:00:18 --> Database Driver Class Initialized
DEBUG - 2013-09-21 10:00:18 --> Controller Class Initialized
DEBUG - 2013-09-21 10:00:18 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 10:00:18 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 10:00:18 --> Model Class Initialized
DEBUG - 2013-09-21 10:00:18 --> Helper loaded: date_helper
DEBUG - 2013-09-21 10:00:18 --> Model Class Initialized
DEBUG - 2013-09-21 10:00:18 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 10:00:18 --> Final output sent to browser
DEBUG - 2013-09-21 10:00:18 --> Total execution time: 0.0340
DEBUG - 2013-09-21 10:03:26 --> Config Class Initialized
DEBUG - 2013-09-21 10:03:26 --> Hooks Class Initialized
DEBUG - 2013-09-21 10:03:26 --> Utf8 Class Initialized
DEBUG - 2013-09-21 10:03:26 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 10:03:26 --> URI Class Initialized
DEBUG - 2013-09-21 10:03:26 --> Router Class Initialized
DEBUG - 2013-09-21 10:03:26 --> No URI present. Default controller set.
DEBUG - 2013-09-21 10:03:26 --> Output Class Initialized
DEBUG - 2013-09-21 10:03:26 --> Security Class Initialized
DEBUG - 2013-09-21 10:03:26 --> Input Class Initialized
DEBUG - 2013-09-21 10:03:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 10:03:26 --> Language Class Initialized
DEBUG - 2013-09-21 10:03:26 --> Loader Class Initialized
DEBUG - 2013-09-21 10:03:26 --> Database Driver Class Initialized
DEBUG - 2013-09-21 10:03:26 --> Controller Class Initialized
DEBUG - 2013-09-21 10:03:26 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 10:03:26 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 10:03:26 --> Model Class Initialized
DEBUG - 2013-09-21 10:03:26 --> Helper loaded: date_helper
DEBUG - 2013-09-21 10:03:26 --> Model Class Initialized
DEBUG - 2013-09-21 10:03:27 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 10:03:27 --> Final output sent to browser
DEBUG - 2013-09-21 10:03:27 --> Total execution time: 0.0360
DEBUG - 2013-09-21 10:03:35 --> Config Class Initialized
DEBUG - 2013-09-21 10:03:35 --> Hooks Class Initialized
DEBUG - 2013-09-21 10:03:35 --> Utf8 Class Initialized
DEBUG - 2013-09-21 10:03:35 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 10:03:35 --> URI Class Initialized
DEBUG - 2013-09-21 10:03:35 --> Router Class Initialized
DEBUG - 2013-09-21 10:03:35 --> No URI present. Default controller set.
DEBUG - 2013-09-21 10:03:35 --> Output Class Initialized
DEBUG - 2013-09-21 10:03:35 --> Security Class Initialized
DEBUG - 2013-09-21 10:03:35 --> Input Class Initialized
DEBUG - 2013-09-21 10:03:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 10:03:35 --> Language Class Initialized
DEBUG - 2013-09-21 10:03:35 --> Loader Class Initialized
DEBUG - 2013-09-21 10:03:35 --> Database Driver Class Initialized
DEBUG - 2013-09-21 10:03:35 --> Controller Class Initialized
DEBUG - 2013-09-21 10:03:35 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 10:03:35 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 10:03:35 --> Model Class Initialized
DEBUG - 2013-09-21 10:03:35 --> Helper loaded: date_helper
DEBUG - 2013-09-21 10:03:35 --> Model Class Initialized
DEBUG - 2013-09-21 10:03:35 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 10:03:35 --> Final output sent to browser
DEBUG - 2013-09-21 10:03:35 --> Total execution time: 0.0340
DEBUG - 2013-09-21 10:03:45 --> Config Class Initialized
DEBUG - 2013-09-21 10:03:45 --> Hooks Class Initialized
DEBUG - 2013-09-21 10:03:45 --> Utf8 Class Initialized
DEBUG - 2013-09-21 10:03:45 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 10:03:45 --> URI Class Initialized
DEBUG - 2013-09-21 10:03:45 --> Router Class Initialized
DEBUG - 2013-09-21 10:03:45 --> No URI present. Default controller set.
DEBUG - 2013-09-21 10:03:45 --> Output Class Initialized
DEBUG - 2013-09-21 10:03:45 --> Security Class Initialized
DEBUG - 2013-09-21 10:03:45 --> Input Class Initialized
DEBUG - 2013-09-21 10:03:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 10:03:45 --> Language Class Initialized
DEBUG - 2013-09-21 10:03:45 --> Loader Class Initialized
DEBUG - 2013-09-21 10:03:45 --> Database Driver Class Initialized
DEBUG - 2013-09-21 10:03:45 --> Controller Class Initialized
DEBUG - 2013-09-21 10:03:45 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 10:03:45 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 10:03:45 --> Model Class Initialized
DEBUG - 2013-09-21 10:03:45 --> Helper loaded: date_helper
DEBUG - 2013-09-21 10:03:45 --> Model Class Initialized
DEBUG - 2013-09-21 10:03:45 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 10:03:45 --> Final output sent to browser
DEBUG - 2013-09-21 10:03:45 --> Total execution time: 0.0320
DEBUG - 2013-09-21 10:06:21 --> Config Class Initialized
DEBUG - 2013-09-21 10:06:21 --> Hooks Class Initialized
DEBUG - 2013-09-21 10:06:21 --> Utf8 Class Initialized
DEBUG - 2013-09-21 10:06:21 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 10:06:21 --> URI Class Initialized
DEBUG - 2013-09-21 10:06:21 --> Router Class Initialized
DEBUG - 2013-09-21 10:06:21 --> No URI present. Default controller set.
DEBUG - 2013-09-21 10:06:21 --> Output Class Initialized
DEBUG - 2013-09-21 10:06:21 --> Security Class Initialized
DEBUG - 2013-09-21 10:06:21 --> Input Class Initialized
DEBUG - 2013-09-21 10:06:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 10:06:21 --> Language Class Initialized
DEBUG - 2013-09-21 10:06:21 --> Loader Class Initialized
DEBUG - 2013-09-21 10:06:21 --> Database Driver Class Initialized
DEBUG - 2013-09-21 10:06:21 --> Controller Class Initialized
DEBUG - 2013-09-21 10:06:21 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 10:06:21 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 10:06:21 --> Model Class Initialized
DEBUG - 2013-09-21 10:06:21 --> Helper loaded: date_helper
DEBUG - 2013-09-21 10:06:21 --> Model Class Initialized
DEBUG - 2013-09-21 10:06:21 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 10:06:21 --> Final output sent to browser
DEBUG - 2013-09-21 10:06:21 --> Total execution time: 0.0360
DEBUG - 2013-09-21 10:07:22 --> Config Class Initialized
DEBUG - 2013-09-21 10:07:22 --> Hooks Class Initialized
DEBUG - 2013-09-21 10:07:22 --> Utf8 Class Initialized
DEBUG - 2013-09-21 10:07:22 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 10:07:22 --> URI Class Initialized
DEBUG - 2013-09-21 10:07:22 --> Router Class Initialized
DEBUG - 2013-09-21 10:07:22 --> No URI present. Default controller set.
DEBUG - 2013-09-21 10:07:22 --> Output Class Initialized
DEBUG - 2013-09-21 10:07:22 --> Security Class Initialized
DEBUG - 2013-09-21 10:07:22 --> Input Class Initialized
DEBUG - 2013-09-21 10:07:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 10:07:22 --> Language Class Initialized
DEBUG - 2013-09-21 10:07:22 --> Loader Class Initialized
DEBUG - 2013-09-21 10:07:22 --> Database Driver Class Initialized
DEBUG - 2013-09-21 10:07:22 --> Controller Class Initialized
DEBUG - 2013-09-21 10:07:22 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 10:07:22 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 10:07:22 --> Model Class Initialized
DEBUG - 2013-09-21 10:07:22 --> Helper loaded: date_helper
DEBUG - 2013-09-21 10:07:22 --> Model Class Initialized
DEBUG - 2013-09-21 10:07:22 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 10:07:22 --> Final output sent to browser
DEBUG - 2013-09-21 10:07:22 --> Total execution time: 0.0340
DEBUG - 2013-09-21 10:07:27 --> Config Class Initialized
DEBUG - 2013-09-21 10:07:27 --> Hooks Class Initialized
DEBUG - 2013-09-21 10:07:27 --> Utf8 Class Initialized
DEBUG - 2013-09-21 10:07:27 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 10:07:27 --> URI Class Initialized
DEBUG - 2013-09-21 10:07:27 --> Router Class Initialized
DEBUG - 2013-09-21 10:07:27 --> No URI present. Default controller set.
DEBUG - 2013-09-21 10:07:27 --> Output Class Initialized
DEBUG - 2013-09-21 10:07:27 --> Security Class Initialized
DEBUG - 2013-09-21 10:07:27 --> Input Class Initialized
DEBUG - 2013-09-21 10:07:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 10:07:27 --> Language Class Initialized
DEBUG - 2013-09-21 10:07:27 --> Loader Class Initialized
DEBUG - 2013-09-21 10:07:27 --> Database Driver Class Initialized
DEBUG - 2013-09-21 10:07:27 --> Controller Class Initialized
DEBUG - 2013-09-21 10:07:27 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 10:07:27 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 10:07:27 --> Model Class Initialized
DEBUG - 2013-09-21 10:07:27 --> Helper loaded: date_helper
DEBUG - 2013-09-21 10:07:27 --> Model Class Initialized
DEBUG - 2013-09-21 10:07:27 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 10:07:27 --> Final output sent to browser
DEBUG - 2013-09-21 10:07:27 --> Total execution time: 0.0350
DEBUG - 2013-09-21 10:08:21 --> Config Class Initialized
DEBUG - 2013-09-21 10:08:21 --> Hooks Class Initialized
DEBUG - 2013-09-21 10:08:21 --> Utf8 Class Initialized
DEBUG - 2013-09-21 10:08:21 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 10:08:21 --> URI Class Initialized
DEBUG - 2013-09-21 10:08:21 --> Router Class Initialized
DEBUG - 2013-09-21 10:08:21 --> No URI present. Default controller set.
DEBUG - 2013-09-21 10:08:21 --> Output Class Initialized
DEBUG - 2013-09-21 10:08:21 --> Security Class Initialized
DEBUG - 2013-09-21 10:08:21 --> Input Class Initialized
DEBUG - 2013-09-21 10:08:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 10:08:21 --> Language Class Initialized
DEBUG - 2013-09-21 10:08:21 --> Loader Class Initialized
DEBUG - 2013-09-21 10:08:21 --> Database Driver Class Initialized
DEBUG - 2013-09-21 10:08:21 --> Controller Class Initialized
DEBUG - 2013-09-21 10:08:21 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 10:08:21 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 10:08:21 --> Model Class Initialized
DEBUG - 2013-09-21 10:08:21 --> Helper loaded: date_helper
DEBUG - 2013-09-21 10:08:21 --> Model Class Initialized
DEBUG - 2013-09-21 10:08:21 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 10:08:21 --> Final output sent to browser
DEBUG - 2013-09-21 10:08:21 --> Total execution time: 0.0330
DEBUG - 2013-09-21 10:08:33 --> Config Class Initialized
DEBUG - 2013-09-21 10:08:33 --> Hooks Class Initialized
DEBUG - 2013-09-21 10:08:33 --> Utf8 Class Initialized
DEBUG - 2013-09-21 10:08:33 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 10:08:33 --> URI Class Initialized
DEBUG - 2013-09-21 10:08:33 --> Router Class Initialized
DEBUG - 2013-09-21 10:08:33 --> No URI present. Default controller set.
DEBUG - 2013-09-21 10:08:33 --> Output Class Initialized
DEBUG - 2013-09-21 10:08:33 --> Security Class Initialized
DEBUG - 2013-09-21 10:08:33 --> Input Class Initialized
DEBUG - 2013-09-21 10:08:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 10:08:33 --> Language Class Initialized
DEBUG - 2013-09-21 10:08:33 --> Loader Class Initialized
DEBUG - 2013-09-21 10:08:33 --> Database Driver Class Initialized
DEBUG - 2013-09-21 10:08:33 --> Controller Class Initialized
DEBUG - 2013-09-21 10:08:33 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 10:08:33 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 10:08:33 --> Model Class Initialized
DEBUG - 2013-09-21 10:08:33 --> Helper loaded: date_helper
DEBUG - 2013-09-21 10:08:33 --> Model Class Initialized
DEBUG - 2013-09-21 10:08:33 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 10:08:33 --> Final output sent to browser
DEBUG - 2013-09-21 10:08:33 --> Total execution time: 0.0340
DEBUG - 2013-09-21 11:00:22 --> Config Class Initialized
DEBUG - 2013-09-21 11:00:22 --> Hooks Class Initialized
DEBUG - 2013-09-21 11:00:22 --> Utf8 Class Initialized
DEBUG - 2013-09-21 11:00:22 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 11:00:22 --> URI Class Initialized
DEBUG - 2013-09-21 11:00:22 --> Router Class Initialized
DEBUG - 2013-09-21 11:00:22 --> No URI present. Default controller set.
DEBUG - 2013-09-21 11:00:22 --> Output Class Initialized
DEBUG - 2013-09-21 11:00:22 --> Security Class Initialized
DEBUG - 2013-09-21 11:00:22 --> Input Class Initialized
DEBUG - 2013-09-21 11:00:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 11:00:22 --> Language Class Initialized
DEBUG - 2013-09-21 11:00:22 --> Loader Class Initialized
DEBUG - 2013-09-21 11:00:22 --> Database Driver Class Initialized
DEBUG - 2013-09-21 11:00:22 --> Controller Class Initialized
DEBUG - 2013-09-21 11:00:22 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 11:00:22 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 11:00:22 --> Model Class Initialized
DEBUG - 2013-09-21 11:00:22 --> Helper loaded: date_helper
DEBUG - 2013-09-21 11:00:22 --> Model Class Initialized
DEBUG - 2013-09-21 11:00:22 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 11:00:22 --> Final output sent to browser
DEBUG - 2013-09-21 11:00:22 --> Total execution time: 0.0370
DEBUG - 2013-09-21 11:05:41 --> Config Class Initialized
DEBUG - 2013-09-21 11:05:41 --> Hooks Class Initialized
DEBUG - 2013-09-21 11:05:41 --> Utf8 Class Initialized
DEBUG - 2013-09-21 11:05:41 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 11:05:41 --> URI Class Initialized
DEBUG - 2013-09-21 11:05:41 --> Router Class Initialized
DEBUG - 2013-09-21 11:05:41 --> No URI present. Default controller set.
DEBUG - 2013-09-21 11:05:41 --> Output Class Initialized
DEBUG - 2013-09-21 11:05:41 --> Security Class Initialized
DEBUG - 2013-09-21 11:05:41 --> Input Class Initialized
DEBUG - 2013-09-21 11:05:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 11:05:41 --> Language Class Initialized
DEBUG - 2013-09-21 11:05:41 --> Loader Class Initialized
DEBUG - 2013-09-21 11:05:41 --> Database Driver Class Initialized
DEBUG - 2013-09-21 11:05:41 --> Controller Class Initialized
DEBUG - 2013-09-21 11:05:41 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 11:05:41 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 11:05:41 --> Model Class Initialized
DEBUG - 2013-09-21 11:05:41 --> Helper loaded: date_helper
DEBUG - 2013-09-21 11:05:41 --> Model Class Initialized
DEBUG - 2013-09-21 11:05:41 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 11:05:41 --> Final output sent to browser
DEBUG - 2013-09-21 11:05:41 --> Total execution time: 0.0340
DEBUG - 2013-09-21 11:06:53 --> Config Class Initialized
DEBUG - 2013-09-21 11:06:53 --> Hooks Class Initialized
DEBUG - 2013-09-21 11:06:53 --> Utf8 Class Initialized
DEBUG - 2013-09-21 11:06:53 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 11:06:53 --> URI Class Initialized
DEBUG - 2013-09-21 11:06:53 --> Router Class Initialized
DEBUG - 2013-09-21 11:06:53 --> No URI present. Default controller set.
DEBUG - 2013-09-21 11:06:53 --> Output Class Initialized
DEBUG - 2013-09-21 11:06:53 --> Security Class Initialized
DEBUG - 2013-09-21 11:06:53 --> Input Class Initialized
DEBUG - 2013-09-21 11:06:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 11:06:53 --> Language Class Initialized
DEBUG - 2013-09-21 11:06:53 --> Loader Class Initialized
DEBUG - 2013-09-21 11:06:53 --> Database Driver Class Initialized
DEBUG - 2013-09-21 11:06:53 --> Controller Class Initialized
DEBUG - 2013-09-21 11:06:53 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 11:06:53 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 11:06:53 --> Model Class Initialized
DEBUG - 2013-09-21 11:06:53 --> Helper loaded: date_helper
DEBUG - 2013-09-21 11:06:53 --> Model Class Initialized
DEBUG - 2013-09-21 11:06:53 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 11:06:53 --> Final output sent to browser
DEBUG - 2013-09-21 11:06:53 --> Total execution time: 0.0330
DEBUG - 2013-09-21 11:07:09 --> Config Class Initialized
DEBUG - 2013-09-21 11:07:09 --> Hooks Class Initialized
DEBUG - 2013-09-21 11:07:09 --> Utf8 Class Initialized
DEBUG - 2013-09-21 11:07:09 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 11:07:09 --> URI Class Initialized
DEBUG - 2013-09-21 11:07:09 --> Router Class Initialized
DEBUG - 2013-09-21 11:07:09 --> No URI present. Default controller set.
DEBUG - 2013-09-21 11:07:09 --> Output Class Initialized
DEBUG - 2013-09-21 11:07:09 --> Security Class Initialized
DEBUG - 2013-09-21 11:07:09 --> Input Class Initialized
DEBUG - 2013-09-21 11:07:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 11:07:09 --> Language Class Initialized
DEBUG - 2013-09-21 11:07:09 --> Loader Class Initialized
DEBUG - 2013-09-21 11:07:09 --> Database Driver Class Initialized
DEBUG - 2013-09-21 11:07:09 --> Controller Class Initialized
DEBUG - 2013-09-21 11:07:09 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 11:07:09 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 11:07:09 --> Model Class Initialized
DEBUG - 2013-09-21 11:07:09 --> Helper loaded: date_helper
DEBUG - 2013-09-21 11:07:09 --> Model Class Initialized
DEBUG - 2013-09-21 11:07:09 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 11:07:09 --> Final output sent to browser
DEBUG - 2013-09-21 11:07:09 --> Total execution time: 0.0340
DEBUG - 2013-09-21 11:08:02 --> Config Class Initialized
DEBUG - 2013-09-21 11:08:02 --> Hooks Class Initialized
DEBUG - 2013-09-21 11:08:02 --> Utf8 Class Initialized
DEBUG - 2013-09-21 11:08:02 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 11:08:02 --> URI Class Initialized
DEBUG - 2013-09-21 11:08:02 --> Router Class Initialized
DEBUG - 2013-09-21 11:08:02 --> No URI present. Default controller set.
DEBUG - 2013-09-21 11:08:02 --> Output Class Initialized
DEBUG - 2013-09-21 11:08:02 --> Security Class Initialized
DEBUG - 2013-09-21 11:08:02 --> Input Class Initialized
DEBUG - 2013-09-21 11:08:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 11:08:02 --> Language Class Initialized
DEBUG - 2013-09-21 11:08:02 --> Loader Class Initialized
DEBUG - 2013-09-21 11:08:02 --> Database Driver Class Initialized
DEBUG - 2013-09-21 11:08:02 --> Controller Class Initialized
DEBUG - 2013-09-21 11:08:02 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 11:08:02 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 11:08:02 --> Model Class Initialized
DEBUG - 2013-09-21 11:08:02 --> Helper loaded: date_helper
DEBUG - 2013-09-21 11:08:02 --> Model Class Initialized
DEBUG - 2013-09-21 11:08:02 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 11:08:02 --> Final output sent to browser
DEBUG - 2013-09-21 11:08:02 --> Total execution time: 0.0350
DEBUG - 2013-09-21 11:08:56 --> Config Class Initialized
DEBUG - 2013-09-21 11:08:56 --> Hooks Class Initialized
DEBUG - 2013-09-21 11:08:56 --> Utf8 Class Initialized
DEBUG - 2013-09-21 11:08:56 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 11:08:56 --> URI Class Initialized
DEBUG - 2013-09-21 11:08:56 --> Router Class Initialized
DEBUG - 2013-09-21 11:08:56 --> No URI present. Default controller set.
DEBUG - 2013-09-21 11:08:56 --> Output Class Initialized
DEBUG - 2013-09-21 11:08:56 --> Security Class Initialized
DEBUG - 2013-09-21 11:08:56 --> Input Class Initialized
DEBUG - 2013-09-21 11:08:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 11:08:56 --> Language Class Initialized
DEBUG - 2013-09-21 11:08:56 --> Loader Class Initialized
DEBUG - 2013-09-21 11:08:56 --> Database Driver Class Initialized
DEBUG - 2013-09-21 11:08:56 --> Controller Class Initialized
DEBUG - 2013-09-21 11:08:56 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 11:08:56 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 11:08:56 --> Model Class Initialized
DEBUG - 2013-09-21 11:08:56 --> Helper loaded: date_helper
DEBUG - 2013-09-21 11:08:56 --> Model Class Initialized
DEBUG - 2013-09-21 11:08:56 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 11:08:56 --> Final output sent to browser
DEBUG - 2013-09-21 11:08:56 --> Total execution time: 0.0370
DEBUG - 2013-09-21 11:09:08 --> Config Class Initialized
DEBUG - 2013-09-21 11:09:08 --> Hooks Class Initialized
DEBUG - 2013-09-21 11:09:08 --> Utf8 Class Initialized
DEBUG - 2013-09-21 11:09:08 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 11:09:08 --> URI Class Initialized
DEBUG - 2013-09-21 11:09:08 --> Router Class Initialized
DEBUG - 2013-09-21 11:09:08 --> No URI present. Default controller set.
DEBUG - 2013-09-21 11:09:08 --> Output Class Initialized
DEBUG - 2013-09-21 11:09:08 --> Security Class Initialized
DEBUG - 2013-09-21 11:09:08 --> Input Class Initialized
DEBUG - 2013-09-21 11:09:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 11:09:08 --> Language Class Initialized
DEBUG - 2013-09-21 11:09:08 --> Loader Class Initialized
DEBUG - 2013-09-21 11:09:08 --> Database Driver Class Initialized
DEBUG - 2013-09-21 11:09:08 --> Controller Class Initialized
DEBUG - 2013-09-21 11:09:08 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 11:09:08 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 11:09:08 --> Model Class Initialized
DEBUG - 2013-09-21 11:09:08 --> Helper loaded: date_helper
DEBUG - 2013-09-21 11:09:08 --> Model Class Initialized
DEBUG - 2013-09-21 11:09:08 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 11:09:08 --> Final output sent to browser
DEBUG - 2013-09-21 11:09:08 --> Total execution time: 0.0340
DEBUG - 2013-09-21 11:09:57 --> Config Class Initialized
DEBUG - 2013-09-21 11:09:57 --> Hooks Class Initialized
DEBUG - 2013-09-21 11:09:57 --> Utf8 Class Initialized
DEBUG - 2013-09-21 11:09:57 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 11:09:57 --> URI Class Initialized
DEBUG - 2013-09-21 11:09:57 --> Router Class Initialized
DEBUG - 2013-09-21 11:09:57 --> No URI present. Default controller set.
DEBUG - 2013-09-21 11:09:57 --> Output Class Initialized
DEBUG - 2013-09-21 11:09:57 --> Security Class Initialized
DEBUG - 2013-09-21 11:09:57 --> Input Class Initialized
DEBUG - 2013-09-21 11:09:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 11:09:57 --> Language Class Initialized
DEBUG - 2013-09-21 11:09:57 --> Loader Class Initialized
DEBUG - 2013-09-21 11:09:57 --> Database Driver Class Initialized
DEBUG - 2013-09-21 11:09:57 --> Controller Class Initialized
DEBUG - 2013-09-21 11:09:57 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 11:09:57 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 11:09:57 --> Model Class Initialized
DEBUG - 2013-09-21 11:09:57 --> Helper loaded: date_helper
DEBUG - 2013-09-21 11:09:57 --> Model Class Initialized
DEBUG - 2013-09-21 11:09:57 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 11:09:57 --> Final output sent to browser
DEBUG - 2013-09-21 11:09:57 --> Total execution time: 0.0340
DEBUG - 2013-09-21 11:10:18 --> Config Class Initialized
DEBUG - 2013-09-21 11:10:18 --> Hooks Class Initialized
DEBUG - 2013-09-21 11:10:18 --> Utf8 Class Initialized
DEBUG - 2013-09-21 11:10:18 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 11:10:18 --> URI Class Initialized
DEBUG - 2013-09-21 11:10:18 --> Router Class Initialized
DEBUG - 2013-09-21 11:10:18 --> No URI present. Default controller set.
DEBUG - 2013-09-21 11:10:18 --> Output Class Initialized
DEBUG - 2013-09-21 11:10:18 --> Security Class Initialized
DEBUG - 2013-09-21 11:10:18 --> Input Class Initialized
DEBUG - 2013-09-21 11:10:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 11:10:18 --> Language Class Initialized
DEBUG - 2013-09-21 11:10:18 --> Loader Class Initialized
DEBUG - 2013-09-21 11:10:18 --> Database Driver Class Initialized
DEBUG - 2013-09-21 11:10:18 --> Controller Class Initialized
DEBUG - 2013-09-21 11:10:18 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 11:10:18 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 11:10:18 --> Model Class Initialized
DEBUG - 2013-09-21 11:10:18 --> Helper loaded: date_helper
DEBUG - 2013-09-21 11:10:18 --> Model Class Initialized
DEBUG - 2013-09-21 11:10:18 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 11:10:18 --> Final output sent to browser
DEBUG - 2013-09-21 11:10:18 --> Total execution time: 0.0350
DEBUG - 2013-09-21 11:11:31 --> Config Class Initialized
DEBUG - 2013-09-21 11:11:31 --> Hooks Class Initialized
DEBUG - 2013-09-21 11:11:31 --> Utf8 Class Initialized
DEBUG - 2013-09-21 11:11:31 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 11:11:31 --> URI Class Initialized
DEBUG - 2013-09-21 11:11:31 --> Router Class Initialized
DEBUG - 2013-09-21 11:11:31 --> No URI present. Default controller set.
DEBUG - 2013-09-21 11:11:31 --> Output Class Initialized
DEBUG - 2013-09-21 11:11:31 --> Security Class Initialized
DEBUG - 2013-09-21 11:11:31 --> Input Class Initialized
DEBUG - 2013-09-21 11:11:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 11:11:31 --> Language Class Initialized
DEBUG - 2013-09-21 11:11:31 --> Loader Class Initialized
DEBUG - 2013-09-21 11:11:31 --> Database Driver Class Initialized
DEBUG - 2013-09-21 11:11:31 --> Controller Class Initialized
DEBUG - 2013-09-21 11:11:31 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 11:11:31 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 11:11:31 --> Model Class Initialized
DEBUG - 2013-09-21 11:11:31 --> Helper loaded: date_helper
DEBUG - 2013-09-21 11:11:31 --> Model Class Initialized
DEBUG - 2013-09-21 11:11:31 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 11:11:31 --> Final output sent to browser
DEBUG - 2013-09-21 11:11:31 --> Total execution time: 0.0340
DEBUG - 2013-09-21 11:12:04 --> Config Class Initialized
DEBUG - 2013-09-21 11:12:04 --> Hooks Class Initialized
DEBUG - 2013-09-21 11:12:04 --> Utf8 Class Initialized
DEBUG - 2013-09-21 11:12:04 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 11:12:04 --> URI Class Initialized
DEBUG - 2013-09-21 11:12:04 --> Router Class Initialized
DEBUG - 2013-09-21 11:12:04 --> No URI present. Default controller set.
DEBUG - 2013-09-21 11:12:04 --> Output Class Initialized
DEBUG - 2013-09-21 11:12:04 --> Security Class Initialized
DEBUG - 2013-09-21 11:12:04 --> Input Class Initialized
DEBUG - 2013-09-21 11:12:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 11:12:04 --> Language Class Initialized
DEBUG - 2013-09-21 11:12:04 --> Loader Class Initialized
DEBUG - 2013-09-21 11:12:04 --> Database Driver Class Initialized
DEBUG - 2013-09-21 11:12:04 --> Controller Class Initialized
DEBUG - 2013-09-21 11:12:04 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 11:12:04 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 11:12:04 --> Model Class Initialized
DEBUG - 2013-09-21 11:12:04 --> Helper loaded: date_helper
DEBUG - 2013-09-21 11:12:04 --> Model Class Initialized
DEBUG - 2013-09-21 11:12:04 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 11:12:04 --> Final output sent to browser
DEBUG - 2013-09-21 11:12:04 --> Total execution time: 0.0330
DEBUG - 2013-09-21 11:12:39 --> Config Class Initialized
DEBUG - 2013-09-21 11:12:39 --> Hooks Class Initialized
DEBUG - 2013-09-21 11:12:39 --> Utf8 Class Initialized
DEBUG - 2013-09-21 11:12:39 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 11:12:39 --> URI Class Initialized
DEBUG - 2013-09-21 11:12:39 --> Router Class Initialized
DEBUG - 2013-09-21 11:12:39 --> No URI present. Default controller set.
DEBUG - 2013-09-21 11:12:39 --> Output Class Initialized
DEBUG - 2013-09-21 11:12:39 --> Security Class Initialized
DEBUG - 2013-09-21 11:12:39 --> Input Class Initialized
DEBUG - 2013-09-21 11:12:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 11:12:39 --> Language Class Initialized
DEBUG - 2013-09-21 11:12:39 --> Loader Class Initialized
DEBUG - 2013-09-21 11:12:39 --> Database Driver Class Initialized
DEBUG - 2013-09-21 11:12:39 --> Controller Class Initialized
DEBUG - 2013-09-21 11:12:39 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 11:12:39 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 11:12:39 --> Model Class Initialized
DEBUG - 2013-09-21 11:12:39 --> Helper loaded: date_helper
DEBUG - 2013-09-21 11:12:39 --> Model Class Initialized
DEBUG - 2013-09-21 11:12:39 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 11:12:39 --> Final output sent to browser
DEBUG - 2013-09-21 11:12:39 --> Total execution time: 0.0350
DEBUG - 2013-09-21 11:22:34 --> Config Class Initialized
DEBUG - 2013-09-21 11:22:34 --> Hooks Class Initialized
DEBUG - 2013-09-21 11:22:34 --> Utf8 Class Initialized
DEBUG - 2013-09-21 11:22:34 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 11:22:34 --> URI Class Initialized
DEBUG - 2013-09-21 11:22:34 --> Router Class Initialized
DEBUG - 2013-09-21 11:22:34 --> No URI present. Default controller set.
DEBUG - 2013-09-21 11:22:34 --> Output Class Initialized
DEBUG - 2013-09-21 11:22:34 --> Security Class Initialized
DEBUG - 2013-09-21 11:22:34 --> Input Class Initialized
DEBUG - 2013-09-21 11:22:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 11:22:34 --> Language Class Initialized
DEBUG - 2013-09-21 11:22:34 --> Loader Class Initialized
DEBUG - 2013-09-21 11:22:34 --> Database Driver Class Initialized
DEBUG - 2013-09-21 11:22:34 --> Controller Class Initialized
DEBUG - 2013-09-21 11:22:34 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 11:22:34 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 11:22:34 --> Model Class Initialized
DEBUG - 2013-09-21 11:22:34 --> Helper loaded: date_helper
DEBUG - 2013-09-21 11:22:34 --> Model Class Initialized
DEBUG - 2013-09-21 11:22:34 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 11:22:34 --> Final output sent to browser
DEBUG - 2013-09-21 11:22:34 --> Total execution time: 0.0360
DEBUG - 2013-09-21 11:22:51 --> Config Class Initialized
DEBUG - 2013-09-21 11:22:51 --> Hooks Class Initialized
DEBUG - 2013-09-21 11:22:51 --> Utf8 Class Initialized
DEBUG - 2013-09-21 11:22:51 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 11:22:51 --> URI Class Initialized
DEBUG - 2013-09-21 11:22:51 --> Router Class Initialized
DEBUG - 2013-09-21 11:22:51 --> No URI present. Default controller set.
DEBUG - 2013-09-21 11:22:51 --> Output Class Initialized
DEBUG - 2013-09-21 11:22:51 --> Security Class Initialized
DEBUG - 2013-09-21 11:22:51 --> Input Class Initialized
DEBUG - 2013-09-21 11:22:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 11:22:51 --> Language Class Initialized
DEBUG - 2013-09-21 11:22:51 --> Loader Class Initialized
DEBUG - 2013-09-21 11:22:51 --> Database Driver Class Initialized
DEBUG - 2013-09-21 11:22:51 --> Controller Class Initialized
DEBUG - 2013-09-21 11:22:51 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 11:22:51 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 11:22:51 --> Model Class Initialized
DEBUG - 2013-09-21 11:22:51 --> Helper loaded: date_helper
DEBUG - 2013-09-21 11:22:51 --> Model Class Initialized
DEBUG - 2013-09-21 11:22:51 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 11:22:51 --> Final output sent to browser
DEBUG - 2013-09-21 11:22:51 --> Total execution time: 0.0350
DEBUG - 2013-09-21 11:48:14 --> Config Class Initialized
DEBUG - 2013-09-21 11:48:14 --> Hooks Class Initialized
DEBUG - 2013-09-21 11:48:14 --> Utf8 Class Initialized
DEBUG - 2013-09-21 11:48:14 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 11:48:14 --> URI Class Initialized
DEBUG - 2013-09-21 11:48:14 --> Router Class Initialized
DEBUG - 2013-09-21 11:48:14 --> Output Class Initialized
DEBUG - 2013-09-21 11:48:14 --> Security Class Initialized
DEBUG - 2013-09-21 11:48:14 --> Input Class Initialized
DEBUG - 2013-09-21 11:48:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 11:48:14 --> Language Class Initialized
DEBUG - 2013-09-21 11:48:14 --> Loader Class Initialized
DEBUG - 2013-09-21 11:48:14 --> Database Driver Class Initialized
DEBUG - 2013-09-21 11:48:14 --> Controller Class Initialized
DEBUG - 2013-09-21 11:48:14 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 11:48:14 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 11:48:14 --> Model Class Initialized
DEBUG - 2013-09-21 11:48:14 --> Helper loaded: date_helper
DEBUG - 2013-09-21 11:48:14 --> Model Class Initialized
DEBUG - 2013-09-21 11:48:14 --> File loaded: application/views/admin.php
DEBUG - 2013-09-21 11:48:14 --> Final output sent to browser
DEBUG - 2013-09-21 11:48:14 --> Total execution time: 0.0350
DEBUG - 2013-09-21 11:48:55 --> Config Class Initialized
DEBUG - 2013-09-21 11:48:55 --> Hooks Class Initialized
DEBUG - 2013-09-21 11:48:55 --> Utf8 Class Initialized
DEBUG - 2013-09-21 11:48:55 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 11:48:55 --> URI Class Initialized
DEBUG - 2013-09-21 11:48:55 --> Router Class Initialized
DEBUG - 2013-09-21 11:49:12 --> Config Class Initialized
DEBUG - 2013-09-21 11:49:12 --> Hooks Class Initialized
DEBUG - 2013-09-21 11:49:12 --> Utf8 Class Initialized
DEBUG - 2013-09-21 11:49:12 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 11:49:12 --> URI Class Initialized
DEBUG - 2013-09-21 11:49:12 --> Router Class Initialized
DEBUG - 2013-09-21 11:49:13 --> Config Class Initialized
DEBUG - 2013-09-21 11:49:13 --> Hooks Class Initialized
DEBUG - 2013-09-21 11:49:13 --> Utf8 Class Initialized
DEBUG - 2013-09-21 11:49:13 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 11:49:13 --> URI Class Initialized
DEBUG - 2013-09-21 11:49:13 --> Router Class Initialized
DEBUG - 2013-09-21 11:49:13 --> No URI present. Default controller set.
DEBUG - 2013-09-21 11:49:13 --> Output Class Initialized
DEBUG - 2013-09-21 11:49:13 --> Security Class Initialized
DEBUG - 2013-09-21 11:49:13 --> Input Class Initialized
DEBUG - 2013-09-21 11:49:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 11:49:13 --> Language Class Initialized
DEBUG - 2013-09-21 11:49:13 --> Loader Class Initialized
DEBUG - 2013-09-21 11:49:13 --> Database Driver Class Initialized
DEBUG - 2013-09-21 11:49:13 --> Controller Class Initialized
DEBUG - 2013-09-21 11:49:13 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 11:49:13 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 11:49:13 --> Model Class Initialized
DEBUG - 2013-09-21 11:49:13 --> Helper loaded: date_helper
DEBUG - 2013-09-21 11:49:13 --> Model Class Initialized
DEBUG - 2013-09-21 11:49:13 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 11:49:13 --> Final output sent to browser
DEBUG - 2013-09-21 11:49:13 --> Total execution time: 0.0330
DEBUG - 2013-09-21 11:49:13 --> Config Class Initialized
DEBUG - 2013-09-21 11:49:13 --> Hooks Class Initialized
DEBUG - 2013-09-21 11:49:13 --> Utf8 Class Initialized
DEBUG - 2013-09-21 11:49:13 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 11:49:13 --> URI Class Initialized
DEBUG - 2013-09-21 11:49:13 --> Router Class Initialized
DEBUG - 2013-09-21 11:49:13 --> No URI present. Default controller set.
DEBUG - 2013-09-21 11:49:13 --> Output Class Initialized
DEBUG - 2013-09-21 11:49:13 --> Security Class Initialized
DEBUG - 2013-09-21 11:49:13 --> Input Class Initialized
DEBUG - 2013-09-21 11:49:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 11:49:13 --> Language Class Initialized
DEBUG - 2013-09-21 11:49:13 --> Loader Class Initialized
DEBUG - 2013-09-21 11:49:13 --> Database Driver Class Initialized
DEBUG - 2013-09-21 11:49:13 --> Controller Class Initialized
DEBUG - 2013-09-21 11:49:13 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 11:49:13 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 11:49:13 --> Model Class Initialized
DEBUG - 2013-09-21 11:49:13 --> Helper loaded: date_helper
DEBUG - 2013-09-21 11:49:13 --> Model Class Initialized
DEBUG - 2013-09-21 11:49:13 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 11:49:13 --> Final output sent to browser
DEBUG - 2013-09-21 11:49:13 --> Total execution time: 0.1610
DEBUG - 2013-09-21 11:49:16 --> Config Class Initialized
DEBUG - 2013-09-21 11:49:16 --> Hooks Class Initialized
DEBUG - 2013-09-21 11:49:16 --> Utf8 Class Initialized
DEBUG - 2013-09-21 11:49:16 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 11:49:16 --> URI Class Initialized
DEBUG - 2013-09-21 11:49:16 --> Router Class Initialized
DEBUG - 2013-09-21 11:49:16 --> No URI present. Default controller set.
DEBUG - 2013-09-21 11:49:16 --> Output Class Initialized
DEBUG - 2013-09-21 11:49:16 --> Security Class Initialized
DEBUG - 2013-09-21 11:49:16 --> Input Class Initialized
DEBUG - 2013-09-21 11:49:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 11:49:16 --> Language Class Initialized
DEBUG - 2013-09-21 11:49:16 --> Loader Class Initialized
DEBUG - 2013-09-21 11:49:16 --> Database Driver Class Initialized
DEBUG - 2013-09-21 11:49:16 --> Controller Class Initialized
DEBUG - 2013-09-21 11:49:16 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 11:49:16 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 11:49:16 --> Model Class Initialized
DEBUG - 2013-09-21 11:49:16 --> Helper loaded: date_helper
DEBUG - 2013-09-21 11:49:16 --> Model Class Initialized
DEBUG - 2013-09-21 11:49:16 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 11:49:16 --> Final output sent to browser
DEBUG - 2013-09-21 11:49:16 --> Total execution time: 0.0330
DEBUG - 2013-09-21 11:49:22 --> Config Class Initialized
DEBUG - 2013-09-21 11:49:22 --> Hooks Class Initialized
DEBUG - 2013-09-21 11:49:22 --> Utf8 Class Initialized
DEBUG - 2013-09-21 11:49:22 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 11:49:22 --> URI Class Initialized
DEBUG - 2013-09-21 11:49:22 --> Router Class Initialized
DEBUG - 2013-09-21 11:49:22 --> No URI present. Default controller set.
DEBUG - 2013-09-21 11:49:22 --> Output Class Initialized
DEBUG - 2013-09-21 11:49:22 --> Security Class Initialized
DEBUG - 2013-09-21 11:49:22 --> Input Class Initialized
DEBUG - 2013-09-21 11:49:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 11:49:22 --> Language Class Initialized
DEBUG - 2013-09-21 11:49:22 --> Loader Class Initialized
DEBUG - 2013-09-21 11:49:22 --> Database Driver Class Initialized
DEBUG - 2013-09-21 11:49:22 --> Controller Class Initialized
DEBUG - 2013-09-21 11:49:22 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 11:49:22 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 11:49:22 --> Model Class Initialized
DEBUG - 2013-09-21 11:49:22 --> Helper loaded: date_helper
DEBUG - 2013-09-21 11:49:22 --> Model Class Initialized
DEBUG - 2013-09-21 11:49:22 --> File loaded: application/views/index.php
DEBUG - 2013-09-21 11:49:22 --> Final output sent to browser
DEBUG - 2013-09-21 11:49:22 --> Total execution time: 0.0340
DEBUG - 2013-09-21 12:50:09 --> Config Class Initialized
DEBUG - 2013-09-21 12:50:09 --> Hooks Class Initialized
DEBUG - 2013-09-21 12:50:09 --> Utf8 Class Initialized
DEBUG - 2013-09-21 12:50:09 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 12:50:09 --> URI Class Initialized
DEBUG - 2013-09-21 12:50:09 --> Router Class Initialized
DEBUG - 2013-09-21 12:50:09 --> Output Class Initialized
DEBUG - 2013-09-21 12:50:09 --> Security Class Initialized
DEBUG - 2013-09-21 12:50:09 --> Input Class Initialized
DEBUG - 2013-09-21 12:50:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 12:50:09 --> Language Class Initialized
DEBUG - 2013-09-21 12:50:36 --> Config Class Initialized
DEBUG - 2013-09-21 12:50:36 --> Hooks Class Initialized
DEBUG - 2013-09-21 12:50:36 --> Utf8 Class Initialized
DEBUG - 2013-09-21 12:50:36 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 12:50:36 --> URI Class Initialized
DEBUG - 2013-09-21 12:50:36 --> Router Class Initialized
DEBUG - 2013-09-21 12:50:36 --> Output Class Initialized
DEBUG - 2013-09-21 12:50:36 --> Security Class Initialized
DEBUG - 2013-09-21 12:50:36 --> Input Class Initialized
DEBUG - 2013-09-21 12:50:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 12:50:36 --> Language Class Initialized
DEBUG - 2013-09-21 12:51:03 --> Config Class Initialized
DEBUG - 2013-09-21 12:51:03 --> Hooks Class Initialized
DEBUG - 2013-09-21 12:51:03 --> Utf8 Class Initialized
DEBUG - 2013-09-21 12:51:03 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 12:51:03 --> URI Class Initialized
DEBUG - 2013-09-21 12:51:03 --> Router Class Initialized
DEBUG - 2013-09-21 12:51:03 --> Output Class Initialized
DEBUG - 2013-09-21 12:51:03 --> Security Class Initialized
DEBUG - 2013-09-21 12:51:03 --> Input Class Initialized
DEBUG - 2013-09-21 12:51:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 12:51:03 --> Language Class Initialized
DEBUG - 2013-09-21 12:51:03 --> Loader Class Initialized
DEBUG - 2013-09-21 12:51:03 --> Database Driver Class Initialized
DEBUG - 2013-09-21 12:51:03 --> Controller Class Initialized
DEBUG - 2013-09-21 12:51:03 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 12:51:03 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 12:51:03 --> Model Class Initialized
DEBUG - 2013-09-21 12:51:03 --> Helper loaded: date_helper
DEBUG - 2013-09-21 12:51:03 --> Model Class Initialized
DEBUG - 2013-09-21 12:51:03 --> Model Class Initialized
ERROR - 2013-09-21 12:51:03 --> Severity: Notice  --> Undefined variable: arguments C:\xampp2\htdocs\stratovate\application\controllers\callback.php 22
ERROR - 2013-09-21 12:51:03 --> Severity: Notice  --> Undefined offset: 1 C:\xampp2\htdocs\stratovate\application\controllers\callback.php 24
ERROR - 2013-09-21 12:51:03 --> Severity: Notice  --> Use of undefined constant ON_KEYWORD - assumed 'ON_KEYWORD' C:\xampp2\htdocs\stratovate\application\controllers\callback.php 33
ERROR - 2013-09-21 12:51:03 --> Severity: Notice  --> Undefined offset: 2 C:\xampp2\htdocs\stratovate\application\controllers\callback.php 37
ERROR - 2013-09-21 12:51:03 --> Severity: Notice  --> Undefined offset: 3 C:\xampp2\htdocs\stratovate\application\controllers\callback.php 37
ERROR - 2013-09-21 12:51:03 --> Severity: Warning  --> Missing argument 2 for REST_Controller::curl(), called in C:\xampp2\htdocs\stratovate\application\controllers\callback.php on line 125 and defined C:\xampp2\htdocs\stratovate\application\core\REST_Controller.php 988
ERROR - 2013-09-21 12:51:04 --> Severity: Notice  --> Undefined variable: url C:\xampp2\htdocs\stratovate\application\core\REST_Controller.php 997
ERROR - 2013-09-21 12:51:04 --> Severity: Warning  --> Illegal string offset 'method' C:\xampp2\htdocs\stratovate\application\core\REST_Controller.php 338
ERROR - 2013-09-21 12:51:04 --> Severity: Warning  --> Illegal string offset 'memory_usage' C:\xampp2\htdocs\stratovate\application\core\REST_Controller.php 339
ERROR - 2013-09-21 12:51:04 --> Severity: Warning  --> Illegal string offset 'response_time' C:\xampp2\htdocs\stratovate\application\core\REST_Controller.php 343
DEBUG - 2013-09-21 12:51:20 --> Config Class Initialized
DEBUG - 2013-09-21 12:51:20 --> Hooks Class Initialized
DEBUG - 2013-09-21 12:51:20 --> Utf8 Class Initialized
DEBUG - 2013-09-21 12:51:20 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 12:51:20 --> URI Class Initialized
DEBUG - 2013-09-21 12:51:20 --> Router Class Initialized
DEBUG - 2013-09-21 12:51:20 --> Output Class Initialized
DEBUG - 2013-09-21 12:51:20 --> Security Class Initialized
DEBUG - 2013-09-21 12:51:20 --> Input Class Initialized
DEBUG - 2013-09-21 12:51:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 12:51:20 --> Language Class Initialized
DEBUG - 2013-09-21 12:51:20 --> Loader Class Initialized
DEBUG - 2013-09-21 12:51:20 --> Database Driver Class Initialized
DEBUG - 2013-09-21 12:51:20 --> Controller Class Initialized
DEBUG - 2013-09-21 12:51:20 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 12:51:20 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 12:51:20 --> Model Class Initialized
DEBUG - 2013-09-21 12:51:20 --> Helper loaded: date_helper
DEBUG - 2013-09-21 12:51:20 --> Model Class Initialized
DEBUG - 2013-09-21 12:51:20 --> Model Class Initialized
ERROR - 2013-09-21 12:51:20 --> Severity: Notice  --> Use of undefined constant ON_KEYWORD - assumed 'ON_KEYWORD' C:\xampp2\htdocs\stratovate\application\controllers\callback.php 33
ERROR - 2013-09-21 12:51:20 --> Severity: Notice  --> Undefined offset: 2 C:\xampp2\htdocs\stratovate\application\controllers\callback.php 37
ERROR - 2013-09-21 12:51:20 --> Severity: Notice  --> Undefined offset: 3 C:\xampp2\htdocs\stratovate\application\controllers\callback.php 37
ERROR - 2013-09-21 12:51:20 --> Severity: Warning  --> Missing argument 2 for REST_Controller::curl(), called in C:\xampp2\htdocs\stratovate\application\controllers\callback.php on line 125 and defined C:\xampp2\htdocs\stratovate\application\core\REST_Controller.php 988
ERROR - 2013-09-21 12:51:20 --> Severity: Notice  --> Undefined variable: url C:\xampp2\htdocs\stratovate\application\core\REST_Controller.php 997
ERROR - 2013-09-21 12:51:20 --> Severity: Warning  --> Illegal string offset 'method' C:\xampp2\htdocs\stratovate\application\core\REST_Controller.php 338
ERROR - 2013-09-21 12:51:20 --> Severity: Warning  --> Illegal string offset 'memory_usage' C:\xampp2\htdocs\stratovate\application\core\REST_Controller.php 339
ERROR - 2013-09-21 12:51:20 --> Severity: Warning  --> Illegal string offset 'response_time' C:\xampp2\htdocs\stratovate\application\core\REST_Controller.php 343
DEBUG - 2013-09-21 12:52:02 --> Config Class Initialized
DEBUG - 2013-09-21 12:52:02 --> Hooks Class Initialized
DEBUG - 2013-09-21 12:52:02 --> Utf8 Class Initialized
DEBUG - 2013-09-21 12:52:02 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 12:52:02 --> URI Class Initialized
DEBUG - 2013-09-21 12:52:02 --> Router Class Initialized
DEBUG - 2013-09-21 12:52:02 --> Output Class Initialized
DEBUG - 2013-09-21 12:52:02 --> Security Class Initialized
DEBUG - 2013-09-21 12:52:02 --> Input Class Initialized
DEBUG - 2013-09-21 12:52:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 12:52:02 --> Language Class Initialized
DEBUG - 2013-09-21 12:52:02 --> Loader Class Initialized
DEBUG - 2013-09-21 12:52:02 --> Database Driver Class Initialized
DEBUG - 2013-09-21 12:52:02 --> Controller Class Initialized
DEBUG - 2013-09-21 12:52:02 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 12:52:02 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 12:52:02 --> Model Class Initialized
DEBUG - 2013-09-21 12:52:02 --> Helper loaded: date_helper
DEBUG - 2013-09-21 12:52:02 --> Model Class Initialized
DEBUG - 2013-09-21 12:52:02 --> Model Class Initialized
DEBUG - 2013-09-21 12:52:55 --> Config Class Initialized
DEBUG - 2013-09-21 12:52:55 --> Hooks Class Initialized
DEBUG - 2013-09-21 12:52:55 --> Utf8 Class Initialized
DEBUG - 2013-09-21 12:52:55 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 12:52:55 --> URI Class Initialized
DEBUG - 2013-09-21 12:52:55 --> Router Class Initialized
DEBUG - 2013-09-21 12:52:55 --> Output Class Initialized
DEBUG - 2013-09-21 12:52:55 --> Security Class Initialized
DEBUG - 2013-09-21 12:52:55 --> Input Class Initialized
DEBUG - 2013-09-21 12:52:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 12:52:55 --> Language Class Initialized
DEBUG - 2013-09-21 12:52:55 --> Loader Class Initialized
DEBUG - 2013-09-21 12:52:55 --> Database Driver Class Initialized
DEBUG - 2013-09-21 12:52:55 --> Controller Class Initialized
DEBUG - 2013-09-21 12:52:55 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 12:52:55 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 12:52:55 --> Model Class Initialized
DEBUG - 2013-09-21 12:52:55 --> Helper loaded: date_helper
DEBUG - 2013-09-21 12:52:55 --> Model Class Initialized
DEBUG - 2013-09-21 12:52:55 --> Model Class Initialized
DEBUG - 2013-09-21 12:52:55 --> Model Class Initialized
ERROR - 2013-09-21 12:52:55 --> Severity: Notice  --> Undefined index: name C:\xampp2\htdocs\stratovate\application\controllers\callback.php 77
ERROR - 2013-09-21 12:52:55 --> Severity: Notice  --> Undefined index: id C:\xampp2\htdocs\stratovate\application\controllers\callback.php 77
ERROR - 2013-09-21 12:52:55 --> Severity: Warning  --> Illegal string offset 'name' C:\xampp2\htdocs\stratovate\application\controllers\callback.php 77
ERROR - 2013-09-21 12:52:55 --> Severity: Warning  --> Illegal string offset 'id' C:\xampp2\htdocs\stratovate\application\controllers\callback.php 77
ERROR - 2013-09-21 12:52:55 --> Severity: Notice  --> Undefined variable: message C:\xampp2\htdocs\stratovate\application\controllers\callback.php 80
ERROR - 2013-09-21 12:52:55 --> Severity: Warning  --> Missing argument 2 for REST_Controller::curl(), called in C:\xampp2\htdocs\stratovate\application\controllers\callback.php on line 125 and defined C:\xampp2\htdocs\stratovate\application\core\REST_Controller.php 988
ERROR - 2013-09-21 12:52:55 --> Severity: Notice  --> Undefined variable: url C:\xampp2\htdocs\stratovate\application\core\REST_Controller.php 997
ERROR - 2013-09-21 12:52:55 --> Severity: Warning  --> Illegal string offset 'method' C:\xampp2\htdocs\stratovate\application\core\REST_Controller.php 338
ERROR - 2013-09-21 12:52:55 --> Severity: Warning  --> Illegal string offset 'memory_usage' C:\xampp2\htdocs\stratovate\application\core\REST_Controller.php 339
ERROR - 2013-09-21 12:52:55 --> Severity: Warning  --> Illegal string offset 'response_time' C:\xampp2\htdocs\stratovate\application\core\REST_Controller.php 343
DEBUG - 2013-09-21 12:53:22 --> Config Class Initialized
DEBUG - 2013-09-21 12:53:22 --> Hooks Class Initialized
DEBUG - 2013-09-21 12:53:22 --> Utf8 Class Initialized
DEBUG - 2013-09-21 12:53:22 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 12:53:22 --> URI Class Initialized
DEBUG - 2013-09-21 12:53:22 --> Router Class Initialized
DEBUG - 2013-09-21 12:53:22 --> Output Class Initialized
DEBUG - 2013-09-21 12:53:22 --> Security Class Initialized
DEBUG - 2013-09-21 12:53:22 --> Input Class Initialized
DEBUG - 2013-09-21 12:53:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 12:53:22 --> Language Class Initialized
DEBUG - 2013-09-21 12:53:22 --> Loader Class Initialized
DEBUG - 2013-09-21 12:53:22 --> Database Driver Class Initialized
DEBUG - 2013-09-21 12:53:22 --> Controller Class Initialized
DEBUG - 2013-09-21 12:53:22 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 12:53:22 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 12:53:22 --> Model Class Initialized
DEBUG - 2013-09-21 12:53:22 --> Helper loaded: date_helper
DEBUG - 2013-09-21 12:53:22 --> Model Class Initialized
DEBUG - 2013-09-21 12:53:22 --> Model Class Initialized
DEBUG - 2013-09-21 12:53:22 --> Model Class Initialized
DEBUG - 2013-09-21 12:54:26 --> Config Class Initialized
DEBUG - 2013-09-21 12:54:26 --> Hooks Class Initialized
DEBUG - 2013-09-21 12:54:26 --> Utf8 Class Initialized
DEBUG - 2013-09-21 12:54:26 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 12:54:26 --> URI Class Initialized
DEBUG - 2013-09-21 12:54:26 --> Router Class Initialized
DEBUG - 2013-09-21 12:54:26 --> Output Class Initialized
DEBUG - 2013-09-21 12:54:26 --> Security Class Initialized
DEBUG - 2013-09-21 12:54:26 --> Input Class Initialized
DEBUG - 2013-09-21 12:54:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 12:54:26 --> Language Class Initialized
DEBUG - 2013-09-21 12:54:26 --> Loader Class Initialized
DEBUG - 2013-09-21 12:54:26 --> Database Driver Class Initialized
DEBUG - 2013-09-21 12:54:26 --> Controller Class Initialized
DEBUG - 2013-09-21 12:54:26 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 12:54:26 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 12:54:26 --> Model Class Initialized
DEBUG - 2013-09-21 12:54:26 --> Helper loaded: date_helper
DEBUG - 2013-09-21 12:54:26 --> Model Class Initialized
DEBUG - 2013-09-21 12:54:26 --> Model Class Initialized
DEBUG - 2013-09-21 12:54:26 --> Model Class Initialized
ERROR - 2013-09-21 12:54:26 --> Severity: Notice  --> Undefined variable: message C:\xampp2\htdocs\stratovate\application\controllers\callback.php 80
ERROR - 2013-09-21 12:54:26 --> Severity: Warning  --> Missing argument 2 for REST_Controller::curl(), called in C:\xampp2\htdocs\stratovate\application\controllers\callback.php on line 125 and defined C:\xampp2\htdocs\stratovate\application\core\REST_Controller.php 988
ERROR - 2013-09-21 12:54:26 --> Severity: Notice  --> Undefined variable: url C:\xampp2\htdocs\stratovate\application\core\REST_Controller.php 997
ERROR - 2013-09-21 12:54:26 --> Severity: Warning  --> Illegal string offset 'method' C:\xampp2\htdocs\stratovate\application\core\REST_Controller.php 338
ERROR - 2013-09-21 12:54:26 --> Severity: Warning  --> Illegal string offset 'memory_usage' C:\xampp2\htdocs\stratovate\application\core\REST_Controller.php 339
ERROR - 2013-09-21 12:54:26 --> Severity: Warning  --> Illegal string offset 'response_time' C:\xampp2\htdocs\stratovate\application\core\REST_Controller.php 343
DEBUG - 2013-09-21 12:54:38 --> Config Class Initialized
DEBUG - 2013-09-21 12:54:38 --> Hooks Class Initialized
DEBUG - 2013-09-21 12:54:38 --> Utf8 Class Initialized
DEBUG - 2013-09-21 12:54:38 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 12:54:38 --> URI Class Initialized
DEBUG - 2013-09-21 12:54:38 --> Router Class Initialized
DEBUG - 2013-09-21 12:54:38 --> Output Class Initialized
DEBUG - 2013-09-21 12:54:38 --> Security Class Initialized
DEBUG - 2013-09-21 12:54:38 --> Input Class Initialized
DEBUG - 2013-09-21 12:54:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 12:54:38 --> Language Class Initialized
DEBUG - 2013-09-21 12:54:38 --> Loader Class Initialized
DEBUG - 2013-09-21 12:54:38 --> Database Driver Class Initialized
DEBUG - 2013-09-21 12:54:38 --> Controller Class Initialized
DEBUG - 2013-09-21 12:54:38 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 12:54:38 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 12:54:38 --> Model Class Initialized
DEBUG - 2013-09-21 12:54:38 --> Helper loaded: date_helper
DEBUG - 2013-09-21 12:54:38 --> Model Class Initialized
DEBUG - 2013-09-21 12:54:38 --> Model Class Initialized
DEBUG - 2013-09-21 12:54:38 --> Model Class Initialized
ERROR - 2013-09-21 12:54:38 --> Severity: Warning  --> Missing argument 2 for REST_Controller::curl(), called in C:\xampp2\htdocs\stratovate\application\controllers\callback.php on line 125 and defined C:\xampp2\htdocs\stratovate\application\core\REST_Controller.php 988
ERROR - 2013-09-21 12:54:38 --> Severity: Notice  --> Undefined variable: url C:\xampp2\htdocs\stratovate\application\core\REST_Controller.php 997
ERROR - 2013-09-21 12:54:38 --> Severity: Warning  --> Illegal string offset 'method' C:\xampp2\htdocs\stratovate\application\core\REST_Controller.php 338
ERROR - 2013-09-21 12:54:38 --> Severity: Warning  --> Illegal string offset 'memory_usage' C:\xampp2\htdocs\stratovate\application\core\REST_Controller.php 339
ERROR - 2013-09-21 12:54:38 --> Severity: Warning  --> Illegal string offset 'response_time' C:\xampp2\htdocs\stratovate\application\core\REST_Controller.php 343
DEBUG - 2013-09-21 12:54:52 --> Config Class Initialized
DEBUG - 2013-09-21 12:54:52 --> Hooks Class Initialized
DEBUG - 2013-09-21 12:54:52 --> Utf8 Class Initialized
DEBUG - 2013-09-21 12:54:52 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 12:54:52 --> URI Class Initialized
DEBUG - 2013-09-21 12:54:52 --> Router Class Initialized
DEBUG - 2013-09-21 12:54:52 --> Output Class Initialized
DEBUG - 2013-09-21 12:54:52 --> Security Class Initialized
DEBUG - 2013-09-21 12:54:52 --> Input Class Initialized
DEBUG - 2013-09-21 12:54:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 12:54:52 --> Language Class Initialized
DEBUG - 2013-09-21 12:54:52 --> Loader Class Initialized
DEBUG - 2013-09-21 12:54:52 --> Database Driver Class Initialized
DEBUG - 2013-09-21 12:54:52 --> Controller Class Initialized
DEBUG - 2013-09-21 12:54:52 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 12:54:52 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 12:54:52 --> Model Class Initialized
DEBUG - 2013-09-21 12:54:52 --> Helper loaded: date_helper
DEBUG - 2013-09-21 12:54:52 --> Model Class Initialized
DEBUG - 2013-09-21 12:54:52 --> Model Class Initialized
DEBUG - 2013-09-21 12:54:52 --> Model Class Initialized
ERROR - 2013-09-21 12:54:52 --> Severity: Warning  --> Illegal string offset 'method' C:\xampp2\htdocs\stratovate\application\core\REST_Controller.php 338
ERROR - 2013-09-21 12:54:52 --> Severity: Warning  --> Illegal string offset 'memory_usage' C:\xampp2\htdocs\stratovate\application\core\REST_Controller.php 339
ERROR - 2013-09-21 12:54:52 --> Severity: Warning  --> Illegal string offset 'response_time' C:\xampp2\htdocs\stratovate\application\core\REST_Controller.php 343
DEBUG - 2013-09-21 12:55:31 --> Config Class Initialized
DEBUG - 2013-09-21 12:55:31 --> Hooks Class Initialized
DEBUG - 2013-09-21 12:55:31 --> Utf8 Class Initialized
DEBUG - 2013-09-21 12:55:31 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 12:55:31 --> URI Class Initialized
DEBUG - 2013-09-21 12:55:31 --> Router Class Initialized
DEBUG - 2013-09-21 12:55:31 --> Output Class Initialized
DEBUG - 2013-09-21 12:55:31 --> Security Class Initialized
DEBUG - 2013-09-21 12:55:31 --> Input Class Initialized
DEBUG - 2013-09-21 12:55:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 12:55:31 --> Language Class Initialized
DEBUG - 2013-09-21 12:55:31 --> Loader Class Initialized
DEBUG - 2013-09-21 12:55:31 --> Database Driver Class Initialized
DEBUG - 2013-09-21 12:55:31 --> Controller Class Initialized
DEBUG - 2013-09-21 12:55:31 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 12:55:31 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 12:55:31 --> Model Class Initialized
DEBUG - 2013-09-21 12:55:31 --> Helper loaded: date_helper
DEBUG - 2013-09-21 12:55:31 --> Model Class Initialized
DEBUG - 2013-09-21 12:55:31 --> Model Class Initialized
DEBUG - 2013-09-21 12:55:31 --> Model Class Initialized
ERROR - 2013-09-21 12:55:31 --> Severity: Warning  --> Illegal string offset 'method' C:\xampp2\htdocs\stratovate\application\core\REST_Controller.php 338
ERROR - 2013-09-21 12:55:31 --> Severity: Warning  --> Illegal string offset 'memory_usage' C:\xampp2\htdocs\stratovate\application\core\REST_Controller.php 339
ERROR - 2013-09-21 12:55:31 --> Severity: Warning  --> Illegal string offset 'response_time' C:\xampp2\htdocs\stratovate\application\core\REST_Controller.php 343
DEBUG - 2013-09-21 12:56:22 --> Config Class Initialized
DEBUG - 2013-09-21 12:56:22 --> Hooks Class Initialized
DEBUG - 2013-09-21 12:56:22 --> Utf8 Class Initialized
DEBUG - 2013-09-21 12:56:22 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 12:56:22 --> URI Class Initialized
DEBUG - 2013-09-21 12:56:22 --> Router Class Initialized
DEBUG - 2013-09-21 12:56:22 --> Output Class Initialized
DEBUG - 2013-09-21 12:56:22 --> Security Class Initialized
DEBUG - 2013-09-21 12:56:22 --> Input Class Initialized
DEBUG - 2013-09-21 12:56:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 12:56:23 --> Language Class Initialized
DEBUG - 2013-09-21 12:56:23 --> Loader Class Initialized
DEBUG - 2013-09-21 12:56:23 --> Database Driver Class Initialized
DEBUG - 2013-09-21 12:56:23 --> Controller Class Initialized
DEBUG - 2013-09-21 12:56:23 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 12:56:23 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 12:56:23 --> Model Class Initialized
DEBUG - 2013-09-21 12:56:23 --> Helper loaded: date_helper
DEBUG - 2013-09-21 12:56:23 --> Model Class Initialized
DEBUG - 2013-09-21 12:56:23 --> Model Class Initialized
DEBUG - 2013-09-21 12:56:23 --> Model Class Initialized
DEBUG - 2013-09-21 12:56:51 --> Config Class Initialized
DEBUG - 2013-09-21 12:56:51 --> Hooks Class Initialized
DEBUG - 2013-09-21 12:56:51 --> Utf8 Class Initialized
DEBUG - 2013-09-21 12:56:51 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 12:56:51 --> URI Class Initialized
DEBUG - 2013-09-21 12:56:51 --> Router Class Initialized
DEBUG - 2013-09-21 12:56:51 --> Output Class Initialized
DEBUG - 2013-09-21 12:56:51 --> Security Class Initialized
DEBUG - 2013-09-21 12:56:51 --> Input Class Initialized
DEBUG - 2013-09-21 12:56:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 12:56:51 --> Language Class Initialized
DEBUG - 2013-09-21 12:56:51 --> Loader Class Initialized
DEBUG - 2013-09-21 12:56:51 --> Database Driver Class Initialized
DEBUG - 2013-09-21 12:56:51 --> Controller Class Initialized
DEBUG - 2013-09-21 12:56:51 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 12:56:51 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 12:56:51 --> Model Class Initialized
DEBUG - 2013-09-21 12:56:51 --> Helper loaded: date_helper
DEBUG - 2013-09-21 12:56:51 --> Model Class Initialized
DEBUG - 2013-09-21 12:56:51 --> Model Class Initialized
DEBUG - 2013-09-21 12:57:38 --> Config Class Initialized
DEBUG - 2013-09-21 12:57:38 --> Hooks Class Initialized
DEBUG - 2013-09-21 12:57:38 --> Utf8 Class Initialized
DEBUG - 2013-09-21 12:57:38 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 12:57:38 --> URI Class Initialized
DEBUG - 2013-09-21 12:57:38 --> Router Class Initialized
DEBUG - 2013-09-21 12:57:38 --> Output Class Initialized
DEBUG - 2013-09-21 12:57:38 --> Security Class Initialized
DEBUG - 2013-09-21 12:57:38 --> Input Class Initialized
DEBUG - 2013-09-21 12:57:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 12:57:38 --> Language Class Initialized
DEBUG - 2013-09-21 12:57:38 --> Loader Class Initialized
DEBUG - 2013-09-21 12:57:38 --> Database Driver Class Initialized
DEBUG - 2013-09-21 12:57:38 --> Controller Class Initialized
DEBUG - 2013-09-21 12:57:38 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 12:57:38 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 12:57:38 --> Model Class Initialized
DEBUG - 2013-09-21 12:57:38 --> Helper loaded: date_helper
DEBUG - 2013-09-21 12:57:38 --> Model Class Initialized
DEBUG - 2013-09-21 12:57:38 --> Model Class Initialized
DEBUG - 2013-09-21 12:57:38 --> Model Class Initialized
DEBUG - 2013-09-21 12:58:11 --> Config Class Initialized
DEBUG - 2013-09-21 12:58:11 --> Hooks Class Initialized
DEBUG - 2013-09-21 12:58:11 --> Utf8 Class Initialized
DEBUG - 2013-09-21 12:58:11 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 12:58:11 --> URI Class Initialized
DEBUG - 2013-09-21 12:58:11 --> Router Class Initialized
DEBUG - 2013-09-21 12:58:11 --> Output Class Initialized
DEBUG - 2013-09-21 12:58:11 --> Security Class Initialized
DEBUG - 2013-09-21 12:58:11 --> Input Class Initialized
DEBUG - 2013-09-21 12:58:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 12:58:11 --> Language Class Initialized
DEBUG - 2013-09-21 12:58:11 --> Loader Class Initialized
DEBUG - 2013-09-21 12:58:11 --> Database Driver Class Initialized
DEBUG - 2013-09-21 12:58:11 --> Controller Class Initialized
DEBUG - 2013-09-21 12:58:11 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 12:58:11 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 12:58:11 --> Model Class Initialized
DEBUG - 2013-09-21 12:58:11 --> Helper loaded: date_helper
DEBUG - 2013-09-21 12:58:11 --> Model Class Initialized
DEBUG - 2013-09-21 12:58:11 --> Model Class Initialized
DEBUG - 2013-09-21 12:58:11 --> Model Class Initialized
DEBUG - 2013-09-21 12:58:35 --> Config Class Initialized
DEBUG - 2013-09-21 12:58:35 --> Hooks Class Initialized
DEBUG - 2013-09-21 12:58:35 --> Utf8 Class Initialized
DEBUG - 2013-09-21 12:58:35 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 12:58:35 --> URI Class Initialized
DEBUG - 2013-09-21 12:58:35 --> Router Class Initialized
DEBUG - 2013-09-21 12:58:35 --> Output Class Initialized
DEBUG - 2013-09-21 12:58:35 --> Security Class Initialized
DEBUG - 2013-09-21 12:58:35 --> Input Class Initialized
DEBUG - 2013-09-21 12:58:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 12:58:35 --> Language Class Initialized
DEBUG - 2013-09-21 12:58:35 --> Loader Class Initialized
DEBUG - 2013-09-21 12:58:35 --> Database Driver Class Initialized
DEBUG - 2013-09-21 12:58:35 --> Controller Class Initialized
DEBUG - 2013-09-21 12:58:35 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 12:58:35 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 12:58:35 --> Model Class Initialized
DEBUG - 2013-09-21 12:58:35 --> Helper loaded: date_helper
DEBUG - 2013-09-21 12:58:35 --> Model Class Initialized
DEBUG - 2013-09-21 12:58:35 --> Model Class Initialized
DEBUG - 2013-09-21 12:58:35 --> Model Class Initialized
DEBUG - 2013-09-21 12:58:54 --> Config Class Initialized
DEBUG - 2013-09-21 12:58:54 --> Hooks Class Initialized
DEBUG - 2013-09-21 12:58:54 --> Utf8 Class Initialized
DEBUG - 2013-09-21 12:58:54 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 12:58:54 --> URI Class Initialized
DEBUG - 2013-09-21 12:58:54 --> Router Class Initialized
DEBUG - 2013-09-21 12:58:54 --> Output Class Initialized
DEBUG - 2013-09-21 12:58:54 --> Security Class Initialized
DEBUG - 2013-09-21 12:58:54 --> Input Class Initialized
DEBUG - 2013-09-21 12:58:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 12:58:54 --> Language Class Initialized
DEBUG - 2013-09-21 12:58:54 --> Loader Class Initialized
DEBUG - 2013-09-21 12:58:54 --> Database Driver Class Initialized
DEBUG - 2013-09-21 12:58:54 --> Controller Class Initialized
DEBUG - 2013-09-21 12:58:54 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 12:58:54 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 12:58:54 --> Model Class Initialized
DEBUG - 2013-09-21 12:58:54 --> Helper loaded: date_helper
DEBUG - 2013-09-21 12:58:54 --> Model Class Initialized
DEBUG - 2013-09-21 12:58:54 --> Model Class Initialized
DEBUG - 2013-09-21 12:58:54 --> Model Class Initialized
DEBUG - 2013-09-21 12:59:22 --> Config Class Initialized
DEBUG - 2013-09-21 12:59:22 --> Hooks Class Initialized
DEBUG - 2013-09-21 12:59:22 --> Utf8 Class Initialized
DEBUG - 2013-09-21 12:59:22 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 12:59:22 --> URI Class Initialized
DEBUG - 2013-09-21 12:59:22 --> Router Class Initialized
DEBUG - 2013-09-21 12:59:22 --> Output Class Initialized
DEBUG - 2013-09-21 12:59:22 --> Security Class Initialized
DEBUG - 2013-09-21 12:59:22 --> Input Class Initialized
DEBUG - 2013-09-21 12:59:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 12:59:22 --> Language Class Initialized
DEBUG - 2013-09-21 12:59:22 --> Loader Class Initialized
DEBUG - 2013-09-21 12:59:22 --> Database Driver Class Initialized
DEBUG - 2013-09-21 12:59:22 --> Controller Class Initialized
DEBUG - 2013-09-21 12:59:22 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 12:59:22 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 12:59:22 --> Model Class Initialized
DEBUG - 2013-09-21 12:59:22 --> Helper loaded: date_helper
DEBUG - 2013-09-21 12:59:22 --> Model Class Initialized
DEBUG - 2013-09-21 12:59:22 --> Model Class Initialized
DEBUG - 2013-09-21 12:59:22 --> Model Class Initialized
ERROR - 2013-09-21 12:59:22 --> Severity: Warning  --> file_get_contents(http%3A%2F%2F121.58.235.156%2Fsms%2Fsms_out.php%3Fusername%3Dravenjohn%26password%3Dravenjohn%26to%3D60802%26msisdn%3D9288517353%26text%3Dravens+%3D+11%2C+%26rrn%3D%7B+RRN+%7D%26binfo%3D3294%26on%3D1%26dlrurl%3Dhttp%253A%252F%252Fyouphoriclabs.com%252FSMSApps%252Fdailybal%252Fcheckbal.php): failed to open stream: Invalid argument C:\xampp2\htdocs\stratovate\application\controllers\callback.php 127
DEBUG - 2013-09-21 12:59:35 --> Config Class Initialized
DEBUG - 2013-09-21 12:59:35 --> Hooks Class Initialized
DEBUG - 2013-09-21 12:59:35 --> Utf8 Class Initialized
DEBUG - 2013-09-21 12:59:35 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 12:59:35 --> URI Class Initialized
DEBUG - 2013-09-21 12:59:35 --> Router Class Initialized
DEBUG - 2013-09-21 12:59:35 --> Output Class Initialized
DEBUG - 2013-09-21 12:59:35 --> Security Class Initialized
DEBUG - 2013-09-21 12:59:35 --> Input Class Initialized
DEBUG - 2013-09-21 12:59:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 12:59:35 --> Language Class Initialized
DEBUG - 2013-09-21 12:59:35 --> Loader Class Initialized
DEBUG - 2013-09-21 12:59:35 --> Database Driver Class Initialized
DEBUG - 2013-09-21 12:59:35 --> Controller Class Initialized
DEBUG - 2013-09-21 12:59:35 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 12:59:35 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 12:59:35 --> Model Class Initialized
DEBUG - 2013-09-21 12:59:35 --> Helper loaded: date_helper
DEBUG - 2013-09-21 12:59:35 --> Model Class Initialized
DEBUG - 2013-09-21 12:59:35 --> Model Class Initialized
DEBUG - 2013-09-21 12:59:35 --> Model Class Initialized
DEBUG - 2013-09-21 12:59:48 --> Config Class Initialized
DEBUG - 2013-09-21 12:59:48 --> Hooks Class Initialized
DEBUG - 2013-09-21 12:59:48 --> Utf8 Class Initialized
DEBUG - 2013-09-21 12:59:48 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 12:59:48 --> URI Class Initialized
DEBUG - 2013-09-21 12:59:48 --> Router Class Initialized
DEBUG - 2013-09-21 12:59:48 --> Output Class Initialized
DEBUG - 2013-09-21 12:59:48 --> Security Class Initialized
DEBUG - 2013-09-21 12:59:48 --> Input Class Initialized
DEBUG - 2013-09-21 12:59:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 12:59:48 --> Language Class Initialized
DEBUG - 2013-09-21 12:59:48 --> Loader Class Initialized
DEBUG - 2013-09-21 12:59:48 --> Database Driver Class Initialized
DEBUG - 2013-09-21 12:59:48 --> Controller Class Initialized
DEBUG - 2013-09-21 12:59:48 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 12:59:48 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 12:59:48 --> Model Class Initialized
DEBUG - 2013-09-21 12:59:48 --> Helper loaded: date_helper
DEBUG - 2013-09-21 12:59:48 --> Model Class Initialized
DEBUG - 2013-09-21 12:59:48 --> Model Class Initialized
DEBUG - 2013-09-21 12:59:48 --> Model Class Initialized
DEBUG - 2013-09-21 13:01:45 --> Config Class Initialized
DEBUG - 2013-09-21 13:01:45 --> Hooks Class Initialized
DEBUG - 2013-09-21 13:01:45 --> Utf8 Class Initialized
DEBUG - 2013-09-21 13:01:45 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 13:01:45 --> URI Class Initialized
DEBUG - 2013-09-21 13:01:45 --> Router Class Initialized
DEBUG - 2013-09-21 13:01:46 --> Output Class Initialized
DEBUG - 2013-09-21 13:01:46 --> Security Class Initialized
DEBUG - 2013-09-21 13:01:46 --> Input Class Initialized
DEBUG - 2013-09-21 13:01:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 13:01:46 --> Language Class Initialized
DEBUG - 2013-09-21 13:01:46 --> Loader Class Initialized
DEBUG - 2013-09-21 13:01:46 --> Database Driver Class Initialized
DEBUG - 2013-09-21 13:01:46 --> Controller Class Initialized
DEBUG - 2013-09-21 13:01:46 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 13:01:46 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 13:01:46 --> Model Class Initialized
DEBUG - 2013-09-21 13:01:46 --> Helper loaded: date_helper
DEBUG - 2013-09-21 13:01:46 --> Model Class Initialized
DEBUG - 2013-09-21 13:01:46 --> Model Class Initialized
DEBUG - 2013-09-21 13:01:46 --> Model Class Initialized
DEBUG - 2013-09-21 13:02:00 --> Config Class Initialized
DEBUG - 2013-09-21 13:02:00 --> Hooks Class Initialized
DEBUG - 2013-09-21 13:02:00 --> Utf8 Class Initialized
DEBUG - 2013-09-21 13:02:00 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 13:02:00 --> URI Class Initialized
DEBUG - 2013-09-21 13:02:00 --> Router Class Initialized
DEBUG - 2013-09-21 13:02:00 --> Output Class Initialized
DEBUG - 2013-09-21 13:02:00 --> Security Class Initialized
DEBUG - 2013-09-21 13:02:00 --> Input Class Initialized
DEBUG - 2013-09-21 13:02:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 13:02:00 --> Language Class Initialized
DEBUG - 2013-09-21 13:02:00 --> Loader Class Initialized
DEBUG - 2013-09-21 13:02:00 --> Database Driver Class Initialized
DEBUG - 2013-09-21 13:02:00 --> Controller Class Initialized
DEBUG - 2013-09-21 13:02:00 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 13:02:00 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 13:02:00 --> Model Class Initialized
DEBUG - 2013-09-21 13:02:00 --> Helper loaded: date_helper
DEBUG - 2013-09-21 13:02:00 --> Model Class Initialized
DEBUG - 2013-09-21 13:02:00 --> Model Class Initialized
DEBUG - 2013-09-21 13:02:00 --> Model Class Initialized
DEBUG - 2013-09-21 13:02:39 --> Config Class Initialized
DEBUG - 2013-09-21 13:02:39 --> Hooks Class Initialized
DEBUG - 2013-09-21 13:02:39 --> Utf8 Class Initialized
DEBUG - 2013-09-21 13:02:39 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 13:02:39 --> URI Class Initialized
DEBUG - 2013-09-21 13:02:39 --> Router Class Initialized
DEBUG - 2013-09-21 13:02:39 --> Output Class Initialized
DEBUG - 2013-09-21 13:02:39 --> Security Class Initialized
DEBUG - 2013-09-21 13:02:39 --> Input Class Initialized
DEBUG - 2013-09-21 13:02:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 13:02:39 --> Language Class Initialized
DEBUG - 2013-09-21 13:02:39 --> Loader Class Initialized
DEBUG - 2013-09-21 13:02:39 --> Database Driver Class Initialized
DEBUG - 2013-09-21 13:02:39 --> Controller Class Initialized
DEBUG - 2013-09-21 13:02:39 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 13:02:39 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 13:02:39 --> Model Class Initialized
DEBUG - 2013-09-21 13:02:39 --> Helper loaded: date_helper
DEBUG - 2013-09-21 13:02:39 --> Model Class Initialized
DEBUG - 2013-09-21 13:02:39 --> Model Class Initialized
DEBUG - 2013-09-21 13:02:39 --> Model Class Initialized
DEBUG - 2013-09-21 13:02:44 --> Config Class Initialized
DEBUG - 2013-09-21 13:02:44 --> Hooks Class Initialized
DEBUG - 2013-09-21 13:02:44 --> Utf8 Class Initialized
DEBUG - 2013-09-21 13:02:44 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 13:02:44 --> URI Class Initialized
DEBUG - 2013-09-21 13:02:44 --> Router Class Initialized
DEBUG - 2013-09-21 13:02:44 --> Output Class Initialized
DEBUG - 2013-09-21 13:02:44 --> Security Class Initialized
DEBUG - 2013-09-21 13:02:44 --> Input Class Initialized
DEBUG - 2013-09-21 13:02:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 13:02:44 --> Language Class Initialized
DEBUG - 2013-09-21 13:02:44 --> Loader Class Initialized
DEBUG - 2013-09-21 13:02:44 --> Database Driver Class Initialized
DEBUG - 2013-09-21 13:02:44 --> Controller Class Initialized
DEBUG - 2013-09-21 13:02:44 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 13:02:44 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 13:02:44 --> Model Class Initialized
DEBUG - 2013-09-21 13:02:44 --> Helper loaded: date_helper
DEBUG - 2013-09-21 13:02:44 --> Model Class Initialized
DEBUG - 2013-09-21 13:02:44 --> Model Class Initialized
DEBUG - 2013-09-21 13:02:44 --> Model Class Initialized
DEBUG - 2013-09-21 13:02:56 --> Config Class Initialized
DEBUG - 2013-09-21 13:02:56 --> Hooks Class Initialized
DEBUG - 2013-09-21 13:02:56 --> Utf8 Class Initialized
DEBUG - 2013-09-21 13:02:56 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 13:02:56 --> URI Class Initialized
DEBUG - 2013-09-21 13:02:56 --> Router Class Initialized
DEBUG - 2013-09-21 13:02:56 --> Output Class Initialized
DEBUG - 2013-09-21 13:02:56 --> Security Class Initialized
DEBUG - 2013-09-21 13:02:56 --> Input Class Initialized
DEBUG - 2013-09-21 13:02:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 13:02:56 --> Language Class Initialized
DEBUG - 2013-09-21 13:02:56 --> Loader Class Initialized
DEBUG - 2013-09-21 13:02:56 --> Database Driver Class Initialized
DEBUG - 2013-09-21 13:02:56 --> Controller Class Initialized
DEBUG - 2013-09-21 13:02:56 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 13:02:56 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 13:02:56 --> Model Class Initialized
DEBUG - 2013-09-21 13:02:56 --> Helper loaded: date_helper
DEBUG - 2013-09-21 13:02:56 --> Model Class Initialized
DEBUG - 2013-09-21 13:02:56 --> Model Class Initialized
DEBUG - 2013-09-21 13:02:56 --> Model Class Initialized
DEBUG - 2013-09-21 13:03:03 --> Config Class Initialized
DEBUG - 2013-09-21 13:03:03 --> Hooks Class Initialized
DEBUG - 2013-09-21 13:03:03 --> Utf8 Class Initialized
DEBUG - 2013-09-21 13:03:03 --> UTF-8 Support Enabled
DEBUG - 2013-09-21 13:03:03 --> URI Class Initialized
DEBUG - 2013-09-21 13:03:03 --> Router Class Initialized
DEBUG - 2013-09-21 13:03:03 --> Output Class Initialized
DEBUG - 2013-09-21 13:03:03 --> Security Class Initialized
DEBUG - 2013-09-21 13:03:03 --> Input Class Initialized
DEBUG - 2013-09-21 13:03:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-09-21 13:03:03 --> Language Class Initialized
DEBUG - 2013-09-21 13:03:03 --> Loader Class Initialized
DEBUG - 2013-09-21 13:03:03 --> Database Driver Class Initialized
DEBUG - 2013-09-21 13:03:03 --> Controller Class Initialized
DEBUG - 2013-09-21 13:03:03 --> Config file loaded: application/config/rest.php
DEBUG - 2013-09-21 13:03:03 --> Helper loaded: inflector_helper
DEBUG - 2013-09-21 13:03:03 --> Model Class Initialized
DEBUG - 2013-09-21 13:03:03 --> Helper loaded: date_helper
DEBUG - 2013-09-21 13:03:03 --> Model Class Initialized
DEBUG - 2013-09-21 13:03:03 --> Model Class Initialized
DEBUG - 2013-09-21 13:03:03 --> Model Class Initialized
